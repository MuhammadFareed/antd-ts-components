import * as Yup from "yup";

export const loginFormSchema = Yup.object().shape({
  email: Yup?.string()?.email("Email is invalid.")?.trim()?.required("Email is required."),
  password: Yup?.string()?.min(8, "Minimum 8 characters are required.")?.required("Password is required."),
});

export const forgotPasswordFormSchema = Yup.object().shape({
  email: Yup?.string()?.email("Email is invalid.")?.trim()?.required("Email is required."),
});
