import avatars01 from "src/assets/avatars/avatars-01.png";
import avatars02 from "src/assets/avatars/avatars-02.png";
import avatars03 from "src/assets/avatars/avatars-03.png";
import avatars04 from "src/assets/avatars/avatars-04.png";
import avatars05 from "src/assets/avatars/avatars-05.png";
import avatars06 from "src/assets/avatars/avatars-06.png";
import avatars07 from "src/assets/avatars/avatars-07.png";
import avatars08 from "src/assets/avatars/avatars-08.png";
import avatars09 from "src/assets/avatars/avatars-09.png";
import { AgeLimitType, ChildAvatar, PriceTableType, ResourceType, SlotTimeType } from "@type/index";
import { ColumnsType } from "antd/es/table";

export const textLimitForReviewReadMore = 120;
export const dateFormat = "YYYY-MM-DD";
export const timeFormat = "HH:mm";
export const dotAndLineMainDomain = "https://dotandlinelearning.com";
export const imageDomainUrl = "https://literacy.s3.ap-south-1.amazonaws.com";

export const testCountries = [
  {
    id: 1,
    label: "Pakistan",
    value: "Pakistan",
  },
  {
    id: 2,
    label: "India",
    value: "India",
  },
  {
    id: 3,
    label: "Iran",
    value: "Iran",
  },
  {
    id: 4,
    label: "Afghanistan",
    value: "Afghanistan",
  },
  {
    id: 5,
    label: "Pakistan",
    value: "Pakistan",
  },
  {
    id: 6,
    label: "India",
    value: "India",
  },
  {
    id: 7,
    label: "Iran",
    value: "Iran",
  },
  {
    id: 8,
    label: "Afghanistan",
    value: "Afghanistan",
  },
  {
    id: 9,
    label: "Pakistan",
    value: "Pakistan",
  },
  {
    id: 10,
    label: "India",
    value: "India",
  },
  {
    id: 11,
    label: "Iran",
    value: "Iran",
  },
  {
    id: 12,
    label: "Afghanistan",
    value: "Afghanistan",
  },
];

export const grades = [
  {
    id: 1,
    label: "Nursery",
    value: "12",
  },
  {
    id: 2,
    label: "KG",
    value: "13",
  },
  {
    id: 3,
    label: "Grade 1",
    value: "1",
  },
  {
    id: 4,
    label: "Grade 2",
    value: "2",
  },
  {
    id: 5,
    label: "Grade 3",
    value: "3",
  },
  {
    id: 6,
    label: "Grade 4",
    value: "4",
  },
  {
    id: 7,
    label: "Grade 5",
    value: "5",
  },
  {
    id: 8,
    label: "Grade 6",
    value: "6",
  },
  {
    id: 9,
    label: "Grade 7",
    value: "7",
  },
  {
    id: 10,
    label: "Grade 8",
    value: "8",
  },
  {
    id: 11,
    label: "Grade 9",
    value: "9",
  },
  {
    id: 12,
    label: "Grade 10",
    value: "10",
  },
  {
    id: 13,
    label: "Grade 11",
    value: "11",
  },
  {
    id: 14,
    label: "Grade 12",
    value: "14",
  },
  {
    id: 15,
    label: "Professional Courses",
    value: "15",
  },
];

export const ageLimitForGrade: AgeLimitType[] = [
  {
    id: 1,
    value: "12",
    name: "Nursery",
    min: 2,
    max: 5,
  },
  {
    id: 2,
    value: "13",
    name: "KG",
    min: 4,
    max: 6,
  },
  {
    id: 3,
    value: "1",
    name: "Grade 1",
    min: 5,
    max: 7,
  },
  {
    id: 4,
    value: "2",
    name: "Grade 2",
    min: 6,
    max: 8,
  },
  {
    id: 5,
    value: "3",
    name: "Grade 3",
    min: 7,
    max: 9,
  },
  {
    id: 6,
    value: "4",
    name: "Grade 4",
    min: 8,
    max: 10,
  },
  {
    id: 7,
    value: "5",
    name: "Grade 5",
    min: 9,
    max: 11,
  },
  {
    id: 8,
    value: "6",
    name: "Grade 6",
    min: 10,
    max: 12,
  },
  {
    id: 9,
    value: "7",
    name: "Grade 7",
    min: 11,
    max: 13,
  },
  {
    id: 10,
    value: "8",
    name: "Grade 8",
    min: 12,
    max: 14,
  },
  {
    id: 11,
    value: "9",
    name: "Grade 9",
    min: 13,
    max: 15,
  },
  {
    id: 12,
    value: "10",
    name: "Grade 10",
    min: 14,
    max: 16,
  },
  {
    id: 13,
    value: "11",
    name: "Grade 11",
    min: 15,
    max: 17,
  },
  {
    id: 14,
    value: "14",
    name: "Grade 12",
    min: 16,
    max: 18,
  },
  {
    id: 15,
    value: "15",
    name: "Professional Courses",
    min: 12,
    max: 50,
  },
];

export const boards = [
  {
    id: 1,
    label: "Cambridge",
    value: "Cambridge",
  },
  {
    id: 2,
    label: "Matric",
    value: "Matric",
  },
  {
    id: 3,
    label: "IB",
    value: "IB",
  },
  {
    id: 4,
    label: "Other",
    value: "Other",
  },
];

export const whyJoinedOptions = [
  {
    id: 1,
    label: "Remedial: The student was struggling to keep up with peer groups and the school curriculum.",
    value: "Remedial",
  },
  {
    id: 2,
    label: "Enrichment: Looking for fun classes to keep the child engaged or learn a new skill.",
    value: "Enrichment",
  },
  {
    id: 3,
    label: "Core Concepts: The student is looking to build a strong conceptual foundation in core subjects.",
    value: "Core Concepts",
  },
  {
    id: 4,
    label: "Reinforcement & Practice: The student is looking to enhance knowledge and do rigorous revision.",
    value: "Reinforcement & Practice",
  },
];

export const studentPersonalities = [
  {
    id: 1,
    label: "Introvert: Reserved and Shy",
    value: "Introvert",
  },
  {
    id: 2,
    label: "Extrovert: Confident and friendly",
    value: "Extrovert",
  },
  {
    id: 3,
    label: "Ambivert: Neither an introvert nor an extrovert",
    value: "Ambivert",
  },
];

export const gradeLevels = [
  {
    id: 1,
    label: "Exceptional/A+",
    value: "Exceptional/A+",
  },
  {
    id: 2,
    label: "A -",
    value: "A -",
  },
  {
    id: 3,
    label: "B",
    value: "B",
  },
  {
    id: 4,
    label: "C- Need for improvement",
    value: "C- Need for improvement",
  },
  {
    id: 5,
    label: "D",
    value: "D",
  },
];

export const behaviouralGoals = [
  {
    label: "Expand Focus",
    value: "Expand Focus",
  },
  {
    label: "Build Confidence",
    value: "Build Confidence",
  },
  {
    label: "Working Independently",
    value: "Working Independently",
  },
  {
    label: "Social Skills(Stronger communication and interaction)",
    value: "Social Skills(Stronger communication and interaction)",
  },
  {
    label: "Learn timeliness",
    value: "Learn timeliness",
  },
  {
    label: "Develop effective study habits",
    value: "Develop effective study habits",
  },
];

export const academicGoals = [
  {
    label: "Fluent Reading",
    value: "Fluent Reading",
  },
  {
    label: "Problem Solving",
    value: "Problem Solving",
  },
  {
    label: "Clear Concepts",
    value: "Clear Concepts",
  },
  {
    label: "Master Basic Skills",
    value: "Master Basic Skills",
  },
  {
    label: "Build Critical Thinking",
    value: "Build Critical Thinking",
  },
  {
    label: "Taking on Challenges",
    value: "Taking on Challenges",
  },
];

export const testPatterns = [
  {
    label: "Monthly",
    value: "Monthly",
  },
  {
    label: "Every 3 to 4 months",
    value: "Every 3 to 4 months",
  },
  {
    label: "Annual",
    value: "Annual",
  },
];

export const classTimes = [
  {
    label: "30 minutes",
    value: "30 minutes",
  },
  {
    label: "45 minutes",
    value: "45 minutes",
  },
  {
    label: "60 minutes",
    value: "60 minutes",
  },
];

export const teachingStyles = [
  {
    label: "Disciplined and Goal Oriented",
    value: "Disciplined and Goal Oriented",
  },
  {
    label: "Friendly",
    value: "Friendly",
  },
  {
    label: "Both",
    value: "Both",
  },
];

export const weekDays = [
  {
    id: 1,
    label: "Monday",
    value: "mon",
  },
  {
    id: 2,
    label: "Tuesday",
    value: "tue",
  },
  {
    id: 3,
    label: "Wednesday",
    value: "wed",
  },
  {
    id: 4,
    label: "Thursday",
    value: "thu",
  },
  {
    id: 5,
    label: "Friday",
    value: "fri",
  },
  {
    id: 6,
    label: "Saturday",
    value: "sat",
  },
  {
    id: 7,
    label: "Sunday",
    value: "sun",
  },
];

export const shifts = [
  {
    id: 1,
    label: "Morning",
    value: "morning",
  },
  {
    id: 2,
    label: "Afternoon",
    value: "afternoon",
  },
  {
    id: 3,
    label: "Evening",
    value: "evening",
  },
  {
    id: 4,
    label: "Night",
    value: "night",
  },
];

export const premiumCourses = [
  {
    id: 1,
    label: "Math",
    value: "Math",
  },
  {
    id: 2,
    label: "English",
    value: "English",
  },
  {
    id: 3,
    label: "Coding",
    value: "Coding",
  },
];

export const inspirationalQuotes: string[] = [
  "Keep calm, you were born to be a teacher!",
  "It takes a big heart to teach little minds!",
  "There is no limit to what you, as a woman, can accomplish!",
  "There is good in each day, if you just take the time to look!",
  "There is good in each day, if you just take the time to look!",
];

export const profilePictureGuidelines = [
  "Professional Portrait with a plain background (grey or white)",
  "Profile Picture should not be cropped from top or side",
  "Photograph should be a square size",
  "Selfies are not accepted",
  "Photograph must be of high quality with no ink marks or creases",
  "Black and white photographs are not accepted",
  "Make sure that photograph is taken with appropriate brightness and contrast",
  "Photograph must be original and not altered in any way (should not have filters/ should not be cropped)",
];

export const packageModes = [
  {
    id: 1,
    label: "Online",
    value: "online",
  },
  {
    id: 2,
    label: "Teacher Home",
    value: "teacher_home",
  },
  {
    id: 3,
    label: "Student Home",
    value: "student_home",
  },
];

export const enrollmentModes = [
  {
    id: 1,
    label: "Batch",
    value: "batch",
  },
  {
    id: 2,
    label: "One to one",
    value: "one_to_one",
  },
];

export const recurringOptions = [
  {
    id: 1,
    label: "Yes",
    value: "yes",
  },
  {
    id: 2,
    label: "No",
    value: "no",
  },
];

export const accessModes = [
  {
    id: 1,
    label: "Private",
    value: "private",
  },
  {
    id: 2,
    label: "Public",
    value: "public",
  },
];

export const timeLimitForShift = [
  {
    id: 1,
    name: "morning",
    min: 5,
    max: 12,
  },
  {
    id: 2,
    name: "afternoon",
    min: 12,
    max: 17,
  },
  {
    id: 3,
    name: "evening",
    min: 17,
    max: 21,
  },
  {
    id: 4,
    name: "night",
    min: 21,
    max: 5,
  },
];

export const openForDemoOptions = [
  {
    id: 1,
    label: "Yes",
    value: "1",
  },
  {
    id: 2,
    label: "No",
    value: "0",
  },
];

export const slotTimes: Record<string, SlotTimeType[]> = {
  morning: [
    {
      id: 10,
      label: "05:00 AM",
      value: "05:00",
      disabled: false,
    },
    {
      id: 11,
      label: "05:30 AM",
      value: "05:30",
      disabled: false,
    },
    {
      id: 12,
      label: "06:00 AM",
      value: "06:00",
      disabled: false,
    },
    {
      id: 13,
      label: "06:30 AM",
      value: "06:30",
      disabled: false,
    },
    {
      id: 14,
      label: "07:00 AM",
      value: "07:00",
      disabled: false,
    },
    {
      id: 15,
      label: "07:30 AM",
      value: "07:30",
      disabled: false,
    },
    {
      id: 16,
      label: "08:00 AM",
      value: "08:00",
      disabled: false,
    },
    {
      id: 17,
      label: "08:30 AM",
      value: "08:30",
      disabled: false,
    },
    {
      id: 18,
      label: "09:00 AM",
      value: "09:00",
      disabled: false,
    },
    {
      id: 19,
      label: "09:30 AM",
      value: "09:30",
      disabled: false,
    },
    {
      id: 20,
      label: "10:00 AM",
      value: "10:00",
      disabled: false,
    },
    {
      id: 21,
      label: "10:30 AM",
      value: "10:30",
      disabled: false,
    },
    {
      id: 22,
      label: "11:00 AM",
      value: "11:00",
      disabled: false,
    },
    {
      id: 23,
      label: "11:30 AM",
      value: "11:30",
      disabled: false,
    },
    {
      id: 24,
      label: "12:00 PM",
      value: "12:00",
      disabled: false,
    },
  ],
  afternoon: [
    {
      id: 24,
      label: "12:00 PM",
      value: "12:00",
      disabled: false,
    },
    {
      id: 25,
      label: "12:30 PM",
      value: "12:30",
      disabled: false,
    },
    {
      id: 26,
      label: "01:00 PM",
      value: "13:00",
      disabled: false,
    },
    {
      id: 27,
      label: "01:30 PM",
      value: "13:30",
      disabled: false,
    },
    {
      id: 28,
      label: "02:00 PM",
      value: "14:00",
      disabled: false,
    },
    {
      id: 29,
      label: "02:30 PM",
      value: "14:30",
      disabled: false,
    },
    {
      id: 30,
      label: "03:00 PM",
      value: "15:00",
      disabled: false,
    },
    {
      id: 31,
      label: "03:30 PM",
      value: "15:30",
      disabled: false,
    },
    {
      id: 32,
      label: "04:00 PM",
      value: "16:00",
      disabled: false,
    },
    {
      id: 33,
      label: "04:30 PM",
      value: "16:30",
      disabled: false,
    },
    {
      id: 34,
      label: "05:00 PM",
      value: "17:00",
      disabled: false,
    },
  ],
  evening: [
    {
      id: 34,
      label: "05:00 PM",
      value: "17:00",
      disabled: false,
    },
    {
      id: 35,
      label: "05:30 PM",
      value: "17:30",
      disabled: false,
    },
    {
      id: 36,
      label: "06:00 PM",
      value: "18:00",
      disabled: false,
    },
    {
      id: 37,
      label: "06:30 PM",
      value: "18:30",
      disabled: false,
    },
    {
      id: 38,
      label: "07:00 PM",
      value: "19:00",
      disabled: false,
    },
    {
      id: 39,
      label: "07:30 PM",
      value: "19:30",
      disabled: false,
    },
    {
      id: 40,
      label: "08:00 PM",
      value: "20:00",
      disabled: false,
    },
    {
      id: 41,
      label: "08:30 PM",
      value: "20:30",
      disabled: false,
    },
    {
      id: 42,
      label: "09:00 PM",
      value: "21:00",
      disabled: false,
    },
  ],
  night: [
    {
      id: 42,
      label: "09:00 PM",
      value: "21:00",
      disabled: false,
    },
    {
      id: 43,
      label: "09:30 PM",
      value: "21:30",
      disabled: false,
    },
    {
      id: 44,
      label: "10:00 PM",
      value: "22:00",
      disabled: false,
    },
    {
      id: 45,
      label: "10:30 PM",
      value: "22:30",
      disabled: false,
    },
    {
      id: 46,
      label: "11:00 PM",
      value: "23:00",
      disabled: false,
    },
    {
      id: 47,
      label: "11:30 PM",
      value: "23:30",
      disabled: false,
    },
    {
      id: 0,
      label: "12:00 AM",
      value: "00:00",
      disabled: false,
    },
    {
      id: 1,
      label: "12:30 AM",
      value: "00:30",
      disabled: false,
    },
    {
      id: 2,
      label: "01:00 AM",
      value: "01:00",
      disabled: false,
    },
    {
      id: 3,
      label: "01:30 AM",
      value: "01:30",
      disabled: false,
    },
    {
      id: 4,
      label: "02:00 AM",
      value: "02:00",
      disabled: false,
    },
    {
      id: 5,
      label: "02:30 AM",
      value: "02:30",
      disabled: false,
    },
    {
      id: 6,
      label: "03:00 AM",
      value: "03:00",
      disabled: false,
    },
    {
      id: 7,
      label: "03:30 AM",
      value: "03:30",
      disabled: false,
    },
    {
      id: 8,
      label: "04:00 AM",
      value: "04:00",
      disabled: false,
    },
    {
      id: 9,
      label: "04:30 AM",
      value: "04:30",
      disabled: false,
    },
    {
      id: 10,
      label: "05:00 AM",
      value: "05:00",
      disabled: false,
    },
  ],
};

export const dataForLocalStudents: PriceTableType[] = [
  {
    id: 1,
    tutorType: "Regular Tutor",
    programType: "Batch",
    for8Months: "4,500",
    for12Months: "5,172",
    for16Months: "6,896",
    for20Months: "8,620",
    for24Months: "10,344",
  },
  {
    id: 2,
    tutorType: "Regular Tutor",
    programType: "One to One",
    for8Months: "6,440",
    for12Months: "9,660",
    for16Months: "12,880",
    for20Months: "16,100",
    for24Months: "19,320",
  },
];

export const columnsForLocalStudents: ColumnsType<PriceTableType> = [
  {
    title: "Local Students PKR",
    dataIndex: "tutorType",
  },
  {
    title: "Program Type",
    dataIndex: "programType",
  },
  {
    title: "8 / MONTH",
    dataIndex: "for8Months",
  },
  {
    title: "12 / MONTH",
    dataIndex: "for12Months",
  },
  {
    title: "16 / MONTH",
    dataIndex: "for16Months",
  },
  {
    title: "20 / MONTH",
    dataIndex: "for20Months",
  },
  {
    title: "24 / MONTH",
    dataIndex: "for24Months",
  },
];

export const dataForInternationalStudents = [
  {
    id: 1,
    tutorType: "Regular Tutor",
    programType: "Batch",
    for8Months: "$32",
    for12Months: "$48",
    for16Months: "$64",
    for20Months: "$80",
    for24Months: "$96",
  },
  {
    id: 2,
    tutorType: "Regular Tutor",
    programType: "One to One",
    for8Months: "$52",
    for12Months: "$78",
    for16Months: "$104",
    for20Months: "$130",
    for24Months: "$156",
  },
];

export const columnsForInternationalStudents: ColumnsType<PriceTableType> = [
  {
    title: "International Students USD",
    dataIndex: "tutorType",
  },
  {
    title: "Program Type",
    dataIndex: "programType",
  },
  {
    title: "8 / MONTH",
    dataIndex: "for8Months",
  },
  {
    title: "12 / MONTH",
    dataIndex: "for12Months",
  },
  {
    title: "16 / MONTH",
    dataIndex: "for16Months",
  },
  {
    title: "20 / MONTH",
    dataIndex: "for20Months",
  },
  {
    title: "24 / MONTH",
    dataIndex: "for24Months",
  },
];

export const packageFilterOptions = [
  {
    id: 1,
    label: "All",
    value: "All",
  },
  // {
  //   id: 2,
  //   label: "Pre-Primary",
  //   value: "Pre-Primary",
  // },
  {
    id: 3,
    label: "Primary",
    value: "Primary",
  },
  {
    id: 4,
    label: "Secondary",
    value: "Secondary",
  },
  {
    id: 5,
    label: "Intermediate",
    value: "Intermediate",
  },
];

export const avatarList: Record<string, Record<"image", any>> = {
  avatars01: {
    image: avatars01,
  },
  avatars02: {
    image: avatars02,
  },
  avatars03: {
    image: avatars03,
  },
  avatars04: {
    image: avatars04,
  },
  avatars05: {
    image: avatars05,
  },
  avatars06: {
    image: avatars06,
  },
  avatars07: {
    image: avatars07,
  },
  avatars08: {
    image: avatars08,
  },
  avatars09: {
    image: avatars09,
  },
};

export const avatarArray: ChildAvatar[] = [
  {
    id: "0",
    name: "avatars01",
    icon: avatars01,
  },
  {
    id: "1",
    name: "avatars02",
    icon: avatars02,
  },
  {
    id: "2",
    name: "avatars03",
    icon: avatars03,
  },
  {
    id: "3",
    name: "avatars04",
    icon: avatars04,
  },
  {
    id: "4",
    name: "avatars05",
    icon: avatars05,
  },
  {
    id: "5",
    name: "avatars06",
    icon: avatars06,
  },
  {
    id: "6",
    name: "avatars07",
    icon: avatars07,
  },
  {
    id: "7",
    name: "avatars08",
    icon: avatars08,
  },
  {
    id: "8",
    name: "avatars09",
    icon: avatars09,
  },
];

export const enrollStatuses: Record<string, string> = {
  alumni: "alumni",
  transfer: "transfer",
  student: "active",
  archive: "potential",
  break: "onbreak",
};

export const enrollStatusColor: Record<string, string> = {
  alumni: "red",
  transfer: "pink",
  student: "green",
  archive: "orange",
  break: "sky",
};

export const enrollStatusOptions = [
  {
    id: 1,
    label: "Alumni",
    value: "alumni",
  },
  {
    id: 1,
    label: "Potential",
    value: "archive",
  },
  {
    id: 1,
    label: "On Break",
    value: "break",
  },
];

export const primaryGrades = ["KG", "Nursery", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5"];

export const resourceTypes: Record<ResourceType, string> = {
  student: "Student Resource",
  teacher: "Teacher Resource",
  both: "Both Resources",
};
