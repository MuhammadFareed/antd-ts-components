import ignite_image from "src/assets/images/ignite.png";
import ignite_image_mobile from "src/assets/images/ignite_mobile.png";
import certificate_banner_for_web from "src/assets/images/certificate_banner.png";
import certificate_banner_for_mobile from "src/assets/images/certificate_banner_for_mobile.png";
import certificate_pdf from "src/assets/pdfs/Guideline for Certificates.pdf";
import sales_guide_web from "src/assets/images/sales_guide_web.png";
import sales_guide_mobile from "src/assets/images/sales_guide_mobile.png";
import sales_guide_pdf from "src/assets/pdfs/The-Sales-Guide-Dot-&-line.pdf";

const whatsNewData = [
  {
    id: 1,
    imageWeb: sales_guide_web,
    imageMobile: sales_guide_mobile,
    link: sales_guide_pdf,
  },
  {
    id: 2,
    imageWeb: certificate_banner_for_web,
    imageMobile: certificate_banner_for_mobile,
    link: certificate_pdf,
  },
  {
    id: 3,
    imageWeb: ignite_image,
    imageMobile: ignite_image_mobile,
    link: "https://dotandlinelearning.com/ignite",
  },
];

export default whatsNewData;
