export const homeCarousel = {
  large: {
    breakpoint: { min: 500, max: 6000 },
    items: 1,
  },
  small: {
    breakpoint: { min: 0, max: 499 },
    items: 1,
  },
};

export const demoStudent = {
  large: {
    breakpoint: { min: 500, max: 6000 },
    items: 2,
  },
  small: {
    breakpoint: { min: 0, max: 499 },
    items: 2,
  },
};

export const packageCarousel = {
  xxxl: {
    breakpoint: { min: 2500, max: 6000 },
    items: 7,
  },
  xxl: {
    breakpoint: { min: 2200, max: 2499 },
    items: 6,
  },
  xl: {
    breakpoint: { min: 1800, max: 2199 },
    items: 5,
  },
  lg: {
    breakpoint: { min: 1500, max: 1799 },
    items: 4,
  },
  m: {
    breakpoint: { min: 1100, max: 1499 },
    items: 3,
  },
  s: {
    breakpoint: { min: 650, max: 1099 },
    items: 2,
  },
  xs: {
    breakpoint: { min: 0, max: 649 },
    items: 1,
  },
};

export const packageProfileCarousel = {
  xxxl: {
    breakpoint: { min: 2500, max: 6000 },
    items: 4,
  },
  xxl: {
    breakpoint: { min: 2200, max: 2499 },
    items: 3,
  },
  xl: {
    breakpoint: { min: 1800, max: 2199 },
    items: 3,
  },
  lg: {
    breakpoint: { min: 1500, max: 1799 },
    items: 2,
  },
  m: {
    breakpoint: { min: 1100, max: 1499 },
    items: 2,
  },
  s: {
    breakpoint: { min: 650, max: 1099 },
    items: 2,
  },
  xs: {
    breakpoint: { min: 0, max: 649 },
    items: 1,
  },
};

export const reviewCarousel = {
  xl: {
    breakpoint: { min: 1900, max: 5000 },
    items: 6,
  },
  lg: {
    breakpoint: { min: 1450, max: 1899 },
    items: 4,
  },
  m: {
    breakpoint: { min: 1000, max: 1449 },
    items: 3,
  },
  s: {
    breakpoint: { min: 650, max: 999 },
    items: 2,
  },
  xs: {
    breakpoint: { min: 0, max: 649 },
    items: 1,
  },
};
