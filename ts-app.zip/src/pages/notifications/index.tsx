import React from "react";

import { Space, Col } from "antd";
import Header from "src/components/header";
import Text from "src/components/text";
import Button from "src/components/button";
import bell from "src/assets/svgs/bell.svg";

import styles from "./styles.module.css";
import { uniqueId } from "lodash";

const Notifications = () => {
  return (
    <div>
      <Header />

      <div className="container py-35">
        <Text title={"Notifications"} font={"SEMIBOLD"} size={"XL"} color={"HEADING"} />

        <div className="mt-50">
          {["1", "2", "3", "4", "5", "6"].map(() => (
            <Col key={uniqueId()} span={24} className={"mt-20"}>
              <Space className={styles.notification} size={"middle"}>
                <img src={bell} className={styles.total_packages_icon} alt="" />

                <Text
                  title="Announcement: January payment has been transferred"
                  font="LIGHTER"
                  color="BLACK"
                  lHeight="S"
                  size="S"
                />
              </Space>
            </Col>
          ))}
        </div>

        <div className={"justify-center mt-30"}>
          <Button type="tertiary">Load More</Button>
        </div>
      </div>
    </div>
  );
};

export default Notifications;
