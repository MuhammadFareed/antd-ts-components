import React, { FC } from "react";
import ProgramDetails from "../program-details";
import Description from "../description";
import TimeSlots from "../time-slots";
import Fee from "../fee";
import { CourseTopic, CreatePackageFormData, LearningOutcome, TimeSlot } from "@type/index";

type Props = {
  activeStep: number;
  setActiveStep: (value: number) => void;
  values: CreatePackageFormData;
  setFieldValue: (
    name: string,
    value: string | string[] | number | File | TimeSlot[] | CourseTopic[] | LearningOutcome[],
  ) => void;
  setErrorInitialized: (value: boolean) => void;
  errorInitialized: boolean;
  handleSubmit: () => void;
  isSubmitting: boolean;
  edit?: boolean;
};

const StepComponent: FC<Props> = props => {
  const {
    activeStep,
    setActiveStep,
    values,
    setFieldValue,
    setErrorInitialized,
    errorInitialized,
    handleSubmit,
    isSubmitting,
    edit,
  } = props;

  switch (activeStep) {
    case 0: {
      return (
        <ProgramDetails
          values={values}
          setActiveStep={setActiveStep}
          setFieldValue={setFieldValue}
          errorInitialized={errorInitialized}
          setErrorInitialized={setErrorInitialized}
        />
      );
    }
    case 1: {
      return (
        <Description
          edit={edit}
          values={values}
          setActiveStep={setActiveStep}
          setFieldValue={setFieldValue}
          errorInitialized={errorInitialized}
          setErrorInitialized={setErrorInitialized}
        />
      );
    }
    case 2: {
      return (
        <TimeSlots
          edit={edit}
          values={values}
          setActiveStep={setActiveStep}
          setFieldValue={setFieldValue}
          errorInitialized={errorInitialized}
          setErrorInitialized={setErrorInitialized}
        />
      );
    }
    case 3: {
      return (
        <Fee
          edit={edit}
          values={values}
          setActiveStep={setActiveStep}
          setFieldValue={setFieldValue}
          errorInitialized={errorInitialized}
          setErrorInitialized={setErrorInitialized}
          handleSubmit={handleSubmit}
          isSubmitting={isSubmitting}
        />
      );
    }
    default: {
      return <></>;
    }
  }
};

export default StepComponent;
