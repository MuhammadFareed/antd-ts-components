import React, { FC } from "react";
import { Col, Row, Space, message } from "antd";
import Text from "src/components/text";
import TextInput from "src/components/input";
import Button from "src/components/button";
import { LeftOutlined } from "@ant-design/icons";
import { Table } from "antd";
import { CreatePackageFormData } from "@type/index";
import {
  columnsForInternationalStudents,
  columnsForLocalStudents,
  dataForInternationalStudents,
  dataForLocalStudents,
} from "src/constant";

type Props = {
  setActiveStep: (value: number) => void;
  values: CreatePackageFormData;
  setFieldValue: (name: string, value: string) => void;
  setErrorInitialized: (value: boolean) => void;
  errorInitialized: boolean;
  handleSubmit: () => void;
  isSubmitting: boolean;
  edit?: boolean;
};

const Fee: FC<Props> = props => {
  const {
    setActiveStep,
    values,
    setFieldValue,
    errorInitialized,
    setErrorInitialized,
    handleSubmit,
    isSubmitting,
    edit,
  } = props;

  const createPackage = () => {
    if (values?.localMonthlyFee && values?.internationalMonthlyFee) {
      handleSubmit();
    } else {
      message.warning("Please fill all required fields.");
      setErrorInitialized(true);
    }
  };

  return (
    <div className="white_box p-25">
      <Row gutter={[0, 20]}>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-6" size="S">
            Local Monthly Fee<span className="red">*</span>
          </Text>
          <Text size="XS" font="LIGHTEST" className="mb-10">
            (Fee to be charged to a local student in PKR)
          </Text>
          <TextInput
            allowClear
            type="number"
            placeholder="eg: 8000 / month "
            value={values?.localMonthlyFee}
            onChange={value => setFieldValue("localMonthlyFee", value)}
            error={errorInitialized && !values?.localMonthlyFee ? "Please enter local monthly fee" : ""}
            prefix={"PKR"}
          />
        </Col>
        <Col span={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Local Student Fee Suggestions
          </Text>
          <Table
            bordered
            size="small"
            scroll={{ x: 890 }}
            columns={columnsForLocalStudents}
            dataSource={dataForLocalStudents}
            pagination={{ hideOnSinglePage: true }}
          />
        </Col>
        <Col className="mt-20" xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-6" size="S">
            International Monthly Fee<span className="red">*</span>
          </Text>
          <Text size="XS" font="LIGHTEST" className="mb-10">
            (Fee to be charged to an international student in USD)
          </Text>
          <TextInput
            allowClear
            type="number"
            placeholder="eg: 150 / month"
            value={values?.internationalMonthlyFee}
            onChange={value => setFieldValue("internationalMonthlyFee", value)}
            error={errorInitialized && !values?.internationalMonthlyFee ? "Please enter international monthly fee" : ""}
            prefix={"USD"}
          />
        </Col>
        <Col span={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            International Student Fee Suggestions
          </Text>
          <Table
            bordered
            size="small"
            scroll={{ x: 890 }}
            columns={columnsForInternationalStudents}
            dataSource={dataForInternationalStudents}
            pagination={{ hideOnSinglePage: true }}
          />
        </Col>
        <Col span={24} className={"justify-end mt-10"}>
          <Space size={"middle"}>
            <Button onClick={() => setActiveStep(2)} type="tertiary">
              <LeftOutlined /> Back
            </Button>
            <Button onClick={createPackage} type="tertiary" loading={isSubmitting}>
              {edit ? "Submit Changes" : "Create Package"}
            </Button>
          </Space>
        </Col>
      </Row>
    </div>
  );
};

export default Fee;
