import React, { ChangeEvent, FC, useRef } from "react";
import { Col, Row, Space, message } from "antd";
import Text from "src/components/text";
import TextInput from "src/components/input";
import Button from "src/components/button";
import { CloseOutlined, DeleteOutlined, FilePdfOutlined, LeftOutlined, RightOutlined } from "@ant-design/icons";
import { CourseTopic, CreatePackageFormData, LearningOutcome } from "@type/index";
import styles from "./../styles.module.css";
import validUrl from "valid-url";
import { getRandomString, openLinkInNewTab } from "src/utils";

type Props = {
  setActiveStep: (value: number) => void;
  values: CreatePackageFormData;
  setFieldValue: (name: string, value: string | File | CourseTopic[] | LearningOutcome[]) => void;
  setErrorInitialized: (value: boolean) => void;
  errorInitialized: boolean;
  edit?: boolean;
};

const Description: FC<Props> = props => {
  const courseOutlinePDFInputRef = useRef<HTMLInputElement>(null);
  const packageCoverImageInputRef = useRef<HTMLInputElement>(null);
  const { edit, setActiveStep, setFieldValue, values, errorInitialized, setErrorInitialized } = props;
  const isOnline = values?.packageMode === "online";

  const gotoNextStep = () => {
    let topicsFilled = true;
    for (let i = 0; i < values?.topics?.length; i++) {
      const element: CourseTopic = values?.topics[i];
      if (i < 4 && (!element?.topicName || !element?.topicDescription)) {
        topicsFilled = false;
        break;
      }
    }
    let learningOutcomesFilled = true;
    for (let i = 0; i < values?.learningOutcomes?.length; i++) {
      const element: LearningOutcome = values?.learningOutcomes[i];
      if (i < 4 && !element?.value) {
        learningOutcomesFilled = false;
        break;
      }
    }
    if (
      values?.packageTitle &&
      values?.teacherIntro &&
      values?.description &&
      values?.courseOutlinePDF &&
      values?.packageCoverImage &&
      topicsFilled &&
      learningOutcomesFilled
    ) {
      if (isOnline && (!values?.zoomLink || !validUrl?.isUri(values?.zoomLink))) {
        message.warning("Please fill all required fields.");
        setErrorInitialized(true);
      } else {
        setErrorInitialized(false);
        setActiveStep(2);
      }
    } else {
      message.warning("Please fill all required fields.");
      setErrorInitialized(true);
    }
  };

  const getUrlErrorMessage = () => {
    if (errorInitialized) {
      if (!values?.zoomLink) {
        return "Please enter class link";
      } else if (!validUrl?.isUri(values?.zoomLink)) {
        return "Please enter a valid zoom link";
      }
    }
    return "";
  };

  const updateTopics = (key: string, value: any, topicId: string) => {
    const updated: CourseTopic[] = values.topics?.map((el: CourseTopic) => {
      return el?.id === topicId ? { ...el, [key]: value } : el;
    });
    setFieldValue("topics", updated);
  };

  const updateLearningOutcomes = (key: string, value: any, loId: string) => {
    const updated: LearningOutcome[] = values.learningOutcomes?.map(el => {
      return el?.id === loId ? { ...el, [key]: value } : el;
    });
    setFieldValue("learningOutcomes", updated);
  };

  return (
    <div className="white_box p-25">
      <Row gutter={[20, 30]}>
        <Col span={24}>
          <div className="d-row">
            <Text font="SEMIBOLD" className="mb-10" size="S">
              Package Title<span className="red">*</span>
            </Text>
            <Text font="LIGHTEST" size="XS" color="GREY03" className="ml-6">
              (Max: 150 characters)
            </Text>
          </div>
          <TextInput
            showCount
            allowClear
            maxLength={150}
            disabled={edit}
            value={values?.packageTitle}
            onChange={(value: any) => setFieldValue("packageTitle", value)}
            placeholder="eg: French Basics"
            error={errorInitialized && !values?.packageTitle ? "Please enter package title" : ""}
          />
        </Col>
        <Col span={24}>
          <div className="d-row">
            <Text font="SEMIBOLD" className="mb-10" size="S">
              Teacher Intro<span className="red">*</span>
            </Text>
            <Text font="LIGHTEST" size="XS" color="GREY03" className="ml-6">
              (Max: 250 characters)
            </Text>
          </div>
          <TextInput
            multiline
            showCount
            allowClear
            maxLength={250}
            placeholder="Tell your students about yourself, your expertise and interests."
            value={values?.teacherIntro}
            onChange={(value: any) => setFieldValue("teacherIntro", value)}
            error={errorInitialized && !values?.teacherIntro ? "Please enter teacher intro" : ""}
          />
        </Col>
        <Col span={24}>
          <div className="d-row">
            <Text font="SEMIBOLD" className="mb-10" size="S">
              Description<span className="red">*</span>
            </Text>
            <Text font="LIGHTEST" size="XS" color="GREY03" className="ml-6">
              (Max: 250 characters)
            </Text>
          </div>
          <TextInput
            multiline
            showCount
            allowClear
            maxLength={250}
            placeholder="Tell your students about this course and how it could help them"
            value={values?.description}
            onChange={(value: any) => setFieldValue("description", value)}
            error={errorInitialized && !values?.description ? "Please enter package description" : ""}
          />
        </Col>
        <Col span={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Add Multiple Topics for your Course
          </Text>
          {values?.topics?.map((topic: CourseTopic, index: number) => {
            return (
              <Space
                className="w-100 mb-20"
                size={"middle"}
                direction="vertical"
                key={topic.id}
                style={{ border: "1px solid #cccccc80", padding: "15px 15px 22px 15px", borderRadius: 8 }}>
                <div className="d-row justify-between">
                  <div className="w-100">
                    <Text font="NORMAL" size="XS" className="mb-8">
                      Topic Name{index > 3 ? null : <span className="red">*</span>}
                    </Text>
                    <TextInput
                      allowClear
                      showCount
                      maxLength={50}
                      style={{ width: "100%", maxWidth: 650 }}
                      placeholder="Enter topic name"
                      value={topic.topicName}
                      onChange={value => updateTopics("topicName", value, topic.id)}
                      error={index < 4 && errorInitialized && !topic?.topicName ? "Please enter topic name" : ""}
                    />
                  </div>
                  {index > 3 && (
                    <div className="d-row justify-end">
                      <Button
                        onClick={() => {
                          const temp = [...values.topics];
                          const filtered = temp?.filter((el: CourseTopic) => el.id !== topic.id);
                          setFieldValue("topics", filtered);
                        }}
                        icon={<DeleteOutlined style={{ fontSize: 18 }} />}
                        type="secondary"
                        className="mt-20s">
                        Delete
                      </Button>
                    </div>
                  )}
                </div>
                <Space className="w-100" direction="vertical">
                  <Text font="NORMAL" size="XS">
                    Topic Description{index > 3 ? null : <span className="red">*</span>}
                  </Text>
                  <TextInput
                    multiline
                    showCount
                    allowClear
                    maxLength={250}
                    value={topic.topicDescription}
                    placeholder="Enter topic description"
                    onChange={value => updateTopics("topicDescription", value, topic.id)}
                    error={
                      index < 4 && errorInitialized && !topic?.topicDescription ? "Please enter topic description" : ""
                    }
                  />
                </Space>
              </Space>
            );
          })}
          <Button
            onClick={() => {
              setFieldValue("topics", [
                ...values.topics,
                { id: getRandomString(), topicName: "", topicDescription: "" },
              ]);
            }}
            type="tertiary">
            + Add More Topics
          </Button>
        </Col>
        <Col span={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Add Learning Outcomes for your Course
          </Text>
          {values?.learningOutcomes?.map((learningOutcome: LearningOutcome, index: number) => {
            return (
              <Space
                className="w-100 mb-20"
                size={"small"}
                direction="vertical"
                key={learningOutcome.id}
                style={{ border: "1px solid #cccccc80", padding: "14px", borderRadius: 8 }}>
                {index > 3 && (
                  <div className="d-row justify-end">
                    <Button
                      onClick={() => {
                        const temp = [...values.learningOutcomes];
                        const filtered = temp?.filter(el => el.id !== learningOutcome.id);
                        setFieldValue("learningOutcomes", filtered);
                      }}
                      icon={<DeleteOutlined style={{ fontSize: 18 }} />}
                      type="secondary"
                      className="mt-20s">
                      Delete
                    </Button>
                  </div>
                )}
                <Space className="w-100" direction="vertical">
                  <Text font="NORMAL" size="XS">
                    Learning Outcome {index + 1}
                    {index > 3 ? null : <span className="red">*</span>}
                  </Text>
                  <TextInput
                    showCount
                    allowClear
                    maxLength={160}
                    value={learningOutcome.value}
                    placeholder="Enter learning outcome"
                    onChange={(value: any) => updateLearningOutcomes("value", value, learningOutcome.id)}
                    error={
                      index < 4 && errorInitialized && !learningOutcome?.value ? "Please enter learning outcome" : ""
                    }
                  />
                </Space>
              </Space>
            );
          })}
          {values?.learningOutcomes?.length < 8 && (
            <Button
              onClick={() => {
                setFieldValue("learningOutcomes", [...values.learningOutcomes, { id: getRandomString(), value: "" }]);
              }}
              type="tertiary">
              + Add More Learning Outcomes
            </Button>
          )}
        </Col>
        {isOnline && (
          <Col span={24}>
            <Text font="SEMIBOLD" className="mb-10" size="S">
              Class Link<span className="red">*</span>
            </Text>
            <TextInput
              allowClear
              placeholder="Link to your zoom meeting room goes here"
              value={values?.zoomLink}
              onChange={value => setFieldValue("zoomLink", value)}
              error={getUrlErrorMessage()}
            />
          </Col>
        )}
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Course Outline PDF<span className="red">*</span>
          </Text>
          <input
            type="file"
            className="d-none-imp"
            accept="application/pdf"
            ref={courseOutlinePDFInputRef}
            onChange={(event: ChangeEvent<HTMLInputElement>) => {
              const inputFile = event?.target?.files;
              if (inputFile && inputFile?.length !== 0) {
                if (inputFile[0]?.size > 5120000) {
                  message.error("The PDF file size may not be greater than 5120 kb.");
                } else {
                  setFieldValue("courseOutlinePDF", inputFile[0]);
                }
              }
            }}
          />
          {values?.courseOutlinePDF ? (
            <Space
              className={styles.outline_pdf_space}
              onClick={() => {
                if (values?.courseOutlinePDF?.name) {
                  openLinkInNewTab(URL.createObjectURL(values?.courseOutlinePDF));
                } else {
                  openLinkInNewTab(values?.courseOutlinePDF);
                }
              }}>
              <div className="red">
                <FilePdfOutlined className={styles.pdf_icon} />
              </div>
              <Text font="LIGHTER" size="S" className={["overflow-wrap-anywhere", styles.file_name].join(" ")}>
                {values?.courseOutlinePDF?.name || "course_outline.pdf"}
              </Text>
              <div
                className={styles.cancel_demo_video_button}
                onClick={e => {
                  e?.stopPropagation();
                  setFieldValue("courseOutlinePDF", "");
                }}>
                <CloseOutlined />
              </div>
            </Space>
          ) : (
            <Button className="mt-5" type="secondary" onClick={() => courseOutlinePDFInputRef?.current?.click()}>
              Upload
            </Button>
          )}
          {errorInitialized && !values?.courseOutlinePDF && (
            <Text className="mt-8" color="RED" size="XS">
              Please upload course outline PDF
            </Text>
          )}
        </Col>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Package Cover Image<span className="red">*</span>
          </Text>
          <input
            type="file"
            className="d-none-imp"
            accept="image/*"
            ref={packageCoverImageInputRef}
            onChange={(event: ChangeEvent<HTMLInputElement>) => {
              const inputFile = event?.target?.files;
              if (inputFile && inputFile?.length !== 0) {
                if (inputFile[0]?.size > 5120000) {
                  message.error("The image size may not be greater than 5120 kb.");
                } else {
                  setFieldValue("packageCoverImage", inputFile[0]);
                }
              }
            }}
          />
          {values?.packageCoverImage ? (
            <div>
              <Space className="mt-5 mb-5">
                {values?.packageCoverImage?.name && (
                  <Text font="LIGHTER" size="S" className="overflow-wrap-anywhere">
                    {values?.packageCoverImage?.name}
                  </Text>
                )}
                <div className={styles.cancel_demo_video_button} onClick={() => setFieldValue("packageCoverImage", "")}>
                  <CloseOutlined />
                </div>
              </Space>
              <div className={styles.cover_image_preview}>
                <img
                  alt=""
                  src={
                    values?.packageCoverImage?.name
                      ? URL.createObjectURL(values?.packageCoverImage)
                      : values?.packageCoverImage
                  }
                />
              </div>
            </div>
          ) : (
            <Button className="mt-5" type="secondary" onClick={() => packageCoverImageInputRef?.current?.click()}>
              Upload
            </Button>
          )}
          {errorInitialized && !values?.packageCoverImage && (
            <Text className="mt-8" color="RED" size="XS">
              Please upload package cover image
            </Text>
          )}
        </Col>
        <Col span={24} className={"justify-end mt-20"}>
          <Space size={"middle"}>
            <Button onClick={() => setActiveStep(0)} type="tertiary">
              <LeftOutlined /> Back
            </Button>
            <Button onClick={gotoNextStep} type="tertiary">
              Next <RightOutlined />
            </Button>
          </Space>
        </Col>
      </Row>
    </div>
  );
};

export default Description;
