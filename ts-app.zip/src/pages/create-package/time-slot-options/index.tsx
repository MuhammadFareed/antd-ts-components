/* eslint-disable react-hooks/exhaustive-deps */
import React, { FC, useEffect, useState } from "react";
import Text from "src/components/text";
import { Col, Row, message } from "antd";
import SelectInput from "src/components/select-input";
import { openForDemoOptions, shifts, slotTimes, weekDays } from "src/constant";
import { CreatePackageFormData, SlotTimeType, TimeSlot } from "@type/index";
import styles from "./../styles.module.css";
import Button from "src/components/button";
import { DeleteOutlined, MinusOutlined, PlusOutlined } from "@ant-design/icons";
import TextInput from "src/components/input";
import RadioGroupButton from "src/components/radio-group-button";

type Props = {
  index: number;
  item: TimeSlot;
  values: CreatePackageFormData;
  setFieldValue: (name: string, value: string | TimeSlot[]) => void;
  updateTimeSlots: (key: string, value: any, item: TimeSlot) => void;
  errorInitialized: boolean;
};

const TimeSlotOptions: FC<Props> = props => {
  const { item, values, setFieldValue, index, updateTimeSlots, errorInitialized } = props;
  const isBatch = values?.enrolmentMode === "batch";
  const [endTimeOptions, setEndTimeOptions] = useState<SlotTimeType[]>([]);

  useEffect(() => {
    if (item?.timeSlot && item?.startTime) {
      let isReached = false;
      const tempOptions = slotTimes[item?.timeSlot]?.reduce((acc: SlotTimeType[], curr: SlotTimeType) => {
        if (isReached) {
          acc.push({ ...curr });
        } else {
          acc.push({ ...curr, disabled: true });
        }
        if (curr?.value === item?.startTime) {
          isReached = true;
        }
        return acc;
      }, []);
      setEndTimeOptions(tempOptions);
    }
  }, []);

  return (
    <div className={["white_box p-25 my-25", styles.dark_white_box].join(" ")} key={item?.id}>
      {index !== 0 && (
        <div className="d-row justify-end">
          <Button
            onClick={() => {
              const temp = [...values.timeSlots];
              const filtered = temp?.filter((el: TimeSlot) => el.id !== item.id);
              setFieldValue("timeSlots", filtered);
            }}
            icon={<DeleteOutlined style={{ fontSize: 18 }} />}
            type="secondary"
            className="mb-15">
            Delete this Slot
          </Button>
        </div>
      )}
      <Row gutter={[20, 20]}>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Days<span className="red">*</span>
          </Text>
          <SelectInput
            mode="multiple"
            placeholder="Select days"
            options={weekDays}
            allowClear
            value={item?.days}
            onChange={(value: any) => updateTimeSlots("days", value, item)}
            error={errorInitialized && !item?.days?.length ? "Please select days" : ""}
          />
        </Col>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Time Slot<span className="red">*</span>
          </Text>
          <SelectInput
            allowClear
            placeholder="Select time slots"
            options={shifts}
            value={item?.timeSlot || undefined}
            error={errorInitialized && !item?.timeSlot ? "Please select a time slot" : ""}
            onChange={(value: any) => {
              const updatedTimeSlots: TimeSlot[] = values.timeSlots?.map((el: TimeSlot) => {
                return el?.id === item?.id ? { ...el, timeSlot: value, startTime: "", endTime: "" } : el;
              });
              setFieldValue("timeSlots", updatedTimeSlots);
            }}
          />
        </Col>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Start Time<span className="red">*</span>
          </Text>
          <SelectInput
            allowClear
            placeholder="Select start time"
            options={item?.timeSlot ? slotTimes[item?.timeSlot] : []}
            value={item?.startTime || undefined}
            onFocus={() => {
              if (!item?.timeSlot) {
                message.warning("Please select time slot first!");
              }
            }}
            onChange={(value: any) => {
              const updatedTimeSlots: TimeSlot[] = values.timeSlots?.map((el: TimeSlot) => {
                return el?.id === item?.id ? { ...el, startTime: value, endTime: "" } : el;
              });
              setFieldValue("timeSlots", updatedTimeSlots);
              let isReached = false;
              const tempOptions = slotTimes[item?.timeSlot]?.reduce((acc: SlotTimeType[], curr: SlotTimeType) => {
                if (isReached) {
                  acc.push({ ...curr });
                } else {
                  acc.push({ ...curr, disabled: true });
                }
                if (curr?.value === value) {
                  isReached = true;
                }
                return acc;
              }, []);
              setEndTimeOptions(tempOptions);
            }}
            error={errorInitialized && !item?.startTime ? "Please select start time" : ""}
          />
        </Col>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            End Time<span className="red">*</span>
          </Text>
          <SelectInput
            allowClear
            placeholder="Select end time"
            options={item?.startTime ? endTimeOptions : []}
            value={item?.endTime || undefined}
            onChange={value => updateTimeSlots("endTime", value, item)}
            error={errorInitialized && !item?.endTime ? "Please select end time" : ""}
            onFocus={() => {
              if (!item?.startTime) {
                message.warning("Please select start time first.");
              }
            }}
          />
        </Col>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Seats<span className="red">*</span>
          </Text>
          <TextInput
            type="number"
            placeholder="Enter seats"
            className={styles.seats}
            disabled={!isBatch}
            error={errorInitialized && !item?.totalSeats ? "Please select total seats" : ""}
            value={item?.totalSeats}
            onChange={value => {
              if (isBatch && value && Number(value) >= 6) {
                updateTimeSlots("totalSeats", value, item);
              }
            }}
            prefix={
              <Button
                icon={<MinusOutlined />}
                onClick={() => {
                  if (isBatch) {
                    const updatedTimeSlots: TimeSlot[] = values.timeSlots?.map((el: TimeSlot) => {
                      if (el?.id === item?.id && el?.totalSeats && Number(el?.totalSeats) > 6) {
                        return {
                          ...el,
                          totalSeats: String(Number(el.totalSeats) - 1),
                        };
                      }
                      return el;
                    });
                    setFieldValue("timeSlots", updatedTimeSlots);
                  }
                }}
              />
            }
            suffix={
              <Button
                icon={<PlusOutlined />}
                onClick={() => {
                  if (isBatch) {
                    const updatedTimeSlots: TimeSlot[] = values.timeSlots?.map((el: TimeSlot) => {
                      if (el?.id === item?.id && el?.totalSeats && Number(el?.totalSeats) >= 6) {
                        return {
                          ...el,
                          totalSeats: String(Number(el.totalSeats) + 1),
                        };
                      }
                      return el;
                    });
                    setFieldValue("timeSlots", updatedTimeSlots);
                  }
                }}
              />
            }
          />
        </Col>
        <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
          <Text size="S" font="SEMIBOLD" className="mb-10">
            Open for Demos<span className="red">*</span>
          </Text>
          <RadioGroupButton
            value={item?.openForDemo}
            options={openForDemoOptions}
            onChange={e => updateTimeSlots("openForDemo", e?.target?.value, item)}
          />
        </Col>
      </Row>
    </div>
  );
};
export default TimeSlotOptions;
