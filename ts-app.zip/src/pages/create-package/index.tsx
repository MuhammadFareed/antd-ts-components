/* eslint-disable react-hooks/exhaustive-deps */
import React, { FC, useCallback, useEffect, useRef, useState } from "react";
import Header from "src/components/header";
import Steps from "src/components/steps";
import { Formik, FormikHelpers, FormikProps } from "formik";
import { Form, message } from "antd";
import { CreatePackageFormData, Package, PackageTimeSlot } from "@type/index";
import StepComponent from "./step-component";
import { packageServices } from "src/services";
import { useNavigate, useParams } from "react-router-dom";
import Loader from "src/components/loader";
import { hasHtmlTags } from "src/utils";

type Props = {
  edit?: boolean;
};

const CreatePackage: FC<Props> = props => {
  const { edit } = props;
  const { id } = useParams();
  const formikRef = useRef<FormikProps<CreatePackageFormData>>(null);
  const navigate = useNavigate();
  const steps = ["Program Details", "Description", "Time Slots", "Fee"];
  const [activeStep, setActiveStep] = useState<number>(0);
  const [errorInitialized, setErrorInitialized] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [packageDetails, setPackageDetails] = useState<Package | null>(null);

  const getPackageDetails = useCallback(async () => {
    try {
      setLoading(true);
      const data = await packageServices.fetchPackageDetails(id);
      setPackageDetails(data);
      setLoading(false);
    } catch (err) {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    if (edit) {
      getPackageDetails();
    }
  }, []);

  useEffect(() => {
    if (edit && formikRef && formikRef.current && packageDetails) {
      formikRef.current.setFieldValue("program", packageDetails?.program?.id);
      formikRef.current.setFieldValue("packageMode", packageDetails?.package_mode);
      formikRef.current.setFieldValue("enrolmentMode", packageDetails?.enrollment_mode);
      // formikRef.current.setFieldValue("recurring", packageDetails?.is_recurring);
      formikRef.current.setFieldValue("accessMode", packageDetails?.access_mode);
      formikRef.current.setFieldValue(
        "subjects",
        packageDetails?.subjects?.map(e => e?.id),
      );
      formikRef.current.setFieldValue("startDate", packageDetails?.start_date);
      formikRef.current.setFieldValue("endDate", packageDetails?.endDate);
      formikRef.current.setFieldValue(
        "grades",
        packageDetails?.grades?.map(e => String(e?.id)),
      );
      formikRef.current.setFieldValue("minAge", packageDetails?.min_age);
      formikRef.current.setFieldValue("maxAge", packageDetails?.max_age);
      formikRef.current.setFieldValue("packageTitle", packageDetails?.title);
      formikRef.current.setFieldValue("teacherIntro", packageDetails?.teacher_intro);
      if (!hasHtmlTags(packageDetails?.description)) {
        formikRef.current.setFieldValue("description", packageDetails?.description);
      }
      if (packageDetails?.learning_outcome && !hasHtmlTags(packageDetails?.learning_outcome)) {
        try {
          formikRef.current.setFieldValue(
            "learningOutcomes",
            JSON.parse(packageDetails?.learning_outcome)?.map((el: any, index: number) => {
              return {
                value: el,
                id: String(index),
              };
            }),
          );
        } catch (e) {
          // nothing to do inside catch
        }
      }
      if (packageDetails?.about_the_course && !hasHtmlTags(packageDetails?.about_the_course)) {
        try {
          formikRef.current.setFieldValue(
            "topics",
            JSON.parse(packageDetails?.about_the_course)?.map((e: any, index: number) => {
              return {
                id: String(index),
                topicName: e?.topic_name,
                topicDescription: e?.topic_description,
              };
            }),
          );
        } catch (e) {
          // nothing to do inside catch
        }
      }
      formikRef.current.setFieldValue("zoomLink", packageDetails?.time_slot[0]?.zoom_link);
      formikRef.current.setFieldValue("zoomLink", packageDetails?.time_slot[0]?.zoom_link);
      formikRef.current.setFieldValue("courseOutlinePDF", packageDetails?.course_outline_pdf);
      formikRef.current.setFieldValue("packageCoverImage", packageDetails?.image);
      formikRef.current.setFieldValue("timeZone", packageDetails?.time_slot[0]?.time_zone);
      formikRef.current.setFieldValue("timeZone", packageDetails?.time_slot[0]?.time_zone);
      formikRef.current.setFieldValue("localMonthlyFee", packageDetails?.amount);
      formikRef.current.setFieldValue("internationalMonthlyFee", packageDetails?.int_amount);
      formikRef.current.setFieldValue(
        "timeSlots",
        packageDetails?.time_slot?.map((slot: PackageTimeSlot) => {
          return {
            id: slot?.id,
            days: slot?.days,
            timeSlot: slot?.time_slot,
            startTime: slot?.start_time,
            endTime: slot?.end_time,
            totalSeats: slot?.seats,
            openForDemo: String(slot?.demo_status),
          };
        }),
      );
    }
  }, [packageDetails]);

  // const initialValues: CreatePackageFormData = {
  //   program: 1,
  //   packageMode: "online",
  //   enrolmentMode: "one_to_one",
  //   recurring: "yes",
  //   accessMode: "public",
  //   subjects: [1, 2],
  //   startDate: "2023-12-12",
  //   endDate: "",
  //   grades: ["4", "5", "6"],
  //   minAge: "11",
  //   maxAge: "11",
  //   packageTitle: "Fareed Test 3",
  //   teacherIntro: "Test test",
  //   description: "Test test",
  //   topics: [
  //     {
  //       id: "1",
  //       topicName: "Test",
  //       topicDescription: "Test",
  //     },
  //     {
  //       id: "2",
  //       topicName: "Test",
  //       topicDescription: "Test",
  //     },
  //     {
  //       id: "3",
  //       topicName: "Test",
  //       topicDescription: "Test",
  //     },
  //     {
  //       id: "4",
  //       topicName: "Test",
  //       topicDescription: "Test",
  //     },
  //   ],
  //   learningOutcomes: [
  //     {
  //       id: "1",
  //       value: "Test",
  //     },
  //     {
  //       id: "2",
  //       value: "Test",
  //     },
  //     {
  //       id: "3",
  //       value: "Test",
  //     },
  //     {
  //       id: "4",
  //       value: "Test",
  //     },
  //   ],
  //   zoomLink: "http://localhost:3000/packages/create-package",
  //   courseOutlinePDF: "",
  //   packageCoverImage: "",
  //   timeZone: "Asia/Karachi",
  //   timeSlots: [
  //     {
  //       id: "1",
  //       days: ["mon", "tue"],
  //       timeSlot: "afternoon",
  //       startTime: "13:00",
  //       endTime: "14:30",
  //       totalSeats: "1",
  //       openForDemo: "1",
  //     },
  //   ],
  //   localMonthlyFee: "18000",
  //   internationalMonthlyFee: "250",
  // };

  const initialValues: CreatePackageFormData = {
    program: 1,
    packageMode: "online",
    enrolmentMode: "one_to_one",
    // recurring: "yes",
    accessMode: "public",
    subjects: [],
    startDate: "",
    endDate: "",
    grades: [],
    minAge: "",
    maxAge: "",
    packageTitle: "",
    teacherIntro: "",
    description: "",
    topics: [
      {
        id: "1",
        topicName: "",
        topicDescription: "",
      },
      {
        id: "2",
        topicName: "",
        topicDescription: "",
      },
      {
        id: "3",
        topicName: "",
        topicDescription: "",
      },
      {
        id: "4",
        topicName: "",
        topicDescription: "",
      },
    ],
    learningOutcomes: [
      {
        id: "1",
        value: "",
      },
      {
        id: "2",
        value: "",
      },
      {
        id: "3",
        value: "",
      },
      {
        id: "4",
        value: "",
      },
    ],
    zoomLink: "",
    courseOutlinePDF: "",
    packageCoverImage: "",
    timeZone: "Asia/Karachi",
    timeSlots: [
      {
        id: "1",
        days: [],
        timeSlot: "",
        startTime: "",
        endTime: "",
        totalSeats: "1",
        openForDemo: "1",
      },
    ],
    localMonthlyFee: "",
    internationalMonthlyFee: "",
  };

  const createHandler = (values: CreatePackageFormData, { setSubmitting }: FormikHelpers<CreatePackageFormData>) => {
    packageServices
      .createPackage(values, edit, id)
      .then((redirectTo: string) => {
        setSubmitting(false);
        message.success(`Package has been ${edit ? "updated" : "created"} successfully!`);
        navigate(redirectTo);
      })
      .catch(() => setSubmitting(false));
  };

  return (
    <div className="create_package">
      {loading && <Loader fullPage />}
      <Header />
      <div className="container py-50">
        <Formik innerRef={formikRef} initialValues={initialValues} onSubmit={createHandler}>
          {({ values, setFieldValue, handleSubmit, isSubmitting }) => (
            <Form>
              <Steps items={steps} active={activeStep} />
              <StepComponent
                edit={edit}
                values={values}
                activeStep={activeStep}
                setActiveStep={setActiveStep}
                setFieldValue={setFieldValue}
                setErrorInitialized={setErrorInitialized}
                errorInitialized={errorInitialized}
                handleSubmit={handleSubmit}
                isSubmitting={isSubmitting}
              />
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default CreatePackage;
