/* eslint-disable react-hooks/exhaustive-deps */
import React, { FC, useCallback, useEffect, useState } from "react";
import { Col, Row, Space, message } from "antd";
import Text from "src/components/text";
import Button from "src/components/button";
import { LeftOutlined, PlusOutlined, RightOutlined } from "@ant-design/icons";
import SelectInput from "src/components/select-input";
import { CreatePackageFormData, TimeSlot } from "@type/index";
import moment from "moment-timezone";
import { SelectInputData } from "@type/index";
import { getRandomString } from "src/utils";
import TimeSlotOptions from "../time-slot-options";
import styles from "./../styles.module.css";

type Props = {
  setActiveStep: (value: number) => void;
  values: CreatePackageFormData;
  setFieldValue: (name: string, value: string | TimeSlot[]) => void;
  errorInitialized: boolean;
  setErrorInitialized: (value: boolean) => void;
  edit?: boolean;
};

const TimeSlots: FC<Props> = props => {
  const { setActiveStep, values, setFieldValue, errorInitialized, setErrorInitialized, edit } = props;
  const [timezones, setTimezones] = useState<SelectInputData[]>([]);

  const addMoreTimeSlot = () => {
    const initialTimeSlot = {
      days: [],
      timeSlot: "",
      startTime: "",
      endTime: "",
      totalSeats: values?.enrolmentMode === "one_to_one" ? "1" : "6",
      openForDemo: "1",
    };

    // const initialTimeSlot = {
    //   days: ["mon", "wed", "sat"],
    //   timeSlot: "evening",
    //   startTime: "14:00",
    //   endTime: "15:00",
    //   totalSeats: values?.enrolmentMode === "one_to_one" ? "1" : "6",
    //   openForDemo: "1",
    // };

    const newTimeSlots = [...values.timeSlots, { ...initialTimeSlot, id: getRandomString() }];
    setFieldValue("timeSlots", newTimeSlots);
  };

  const getTimeZones = useCallback(() => {
    const temp: SelectInputData[] = moment.tz.names().map((timezone: string, index: number) => {
      return { id: index + 1, label: timezone, value: timezone };
    });
    setTimezones(temp);
  }, []);

  useEffect(() => {
    getTimeZones();
  }, []);

  const updateTimeSlots = (key: string, value: any, item: TimeSlot) => {
    const updatedTimeSlots: TimeSlot[] = values.timeSlots?.map((el: TimeSlot) => {
      return el?.id === item?.id ? { ...el, [key]: value } : el;
    });
    setFieldValue("timeSlots", updatedTimeSlots);
  };

  const gotoNextStep = () => {
    let valuesFilled = true;
    for (let i = 0; i < values?.timeSlots?.length; i++) {
      const element = values?.timeSlots[i];
      if (
        element?.days?.length === 0 ||
        !element?.endTime ||
        !element?.startTime ||
        !element?.openForDemo ||
        !element?.timeSlot ||
        !element?.totalSeats
      ) {
        valuesFilled = false;
      }
    }
    if (values?.timeZone && valuesFilled) {
      setErrorInitialized(false);
      setActiveStep(3);
    } else {
      message.warning("Please fill all required fields.");
      setErrorInitialized(true);
    }
  };

  return (
    <div className="white_box p-25">
      <div className="p-relative">
        {edit && <div title="Time slots can not be updated!" className={styles.time_slot_overlay}></div>}
        <Text font="SEMIBOLD" className="mb-20">
          Add Package Time Slots
        </Text>
        <Row gutter={[20, 20]}>
          <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
            <Text font="SEMIBOLD" className="mb-10" size="S">
              Time Zone<span className="red">*</span>
            </Text>
            <SelectInput
              allowClear
              showSearch
              placeholder="Select time zone"
              options={timezones}
              value={values?.timeZone}
              onChange={(value: any) => setFieldValue("timeZone", value)}
              error={errorInitialized && !values?.timeZone ? "Please select a time zone" : ""}
            />
          </Col>
        </Row>
        {values.timeSlots.map((item: TimeSlot, index: number) => (
          <TimeSlotOptions
            index={index}
            item={item}
            setFieldValue={setFieldValue}
            updateTimeSlots={updateTimeSlots}
            values={values}
            errorInitialized={errorInitialized}
          />
        ))}
        <div className="d-row w-100 justify-end mt-20">
          <Button onClick={addMoreTimeSlot}>
            Add more time slot <PlusOutlined />
          </Button>
        </div>
      </div>
      <div className={"justify-end mt-40"}>
        <Space size={"middle"}>
          <Button onClick={() => setActiveStep(1)} type="tertiary">
            <LeftOutlined /> Back
          </Button>
          <Button onClick={gotoNextStep} type="tertiary">
            Next <RightOutlined />
          </Button>
        </Space>
      </div>
    </div>
  );
};

export default TimeSlots;
