/* eslint-disable react-hooks/exhaustive-deps */
import Text from "src/components/text";
import React, { FC, useEffect, useState } from "react";
import { Col, Row, message } from "antd";
import { RightOutlined } from "@ant-design/icons";
import RadioGroupButton from "src/components/radio-group-button";
import SelectInput from "src/components/select-input";
import { accessModes, ageLimitForGrade, dateFormat, enrollmentModes, grades, packageModes } from "src/constant";
import DatePicker from "src/components/date-picker";
import Button from "src/components/button";
import styles from "./../styles.module.css";
import { AgeLimitType, CreatePackageFormData, PersistedGeneralState, SelectItemType, TimeSlot } from "@type/index";
import { RootState } from "@store/reducers";
import { useSelector } from "react-redux";
import dayjs from "dayjs";
import type { Dayjs } from "dayjs";
import { find } from "lodash";

const courseTypes = [
  {
    id: 1,
    title: "Premium",
    description:
      "Never taught before? Teach with ease and confidence using Dot & Line’s specialised curriculum in English & Math designed by global experts. All lesson plans included!",
  },
  {
    id: 2,
    title: "Express",
    description: (
      <span>
        Specialise in a particular subject? Or want to customise your student’s course to include Exam/Test Prep or HW
        Help? <br /> Create your own Express course using Dot & Line’s learning library full of resources.
      </span>
    ),
  },
  {
    id: 3,
    title: "Short Course",
    description: "Create 1-2 month short courses that focus on enrichment, skill-building or seasonal camps!",
  },
];

type Props = {
  setActiveStep: (value: number) => void;
  values: CreatePackageFormData;
  setFieldValue: (name: string, value: string | string[] | number | TimeSlot[]) => void;
  setErrorInitialized: (value: boolean) => void;
  errorInitialized: boolean;
};

const ProgramDetails: FC<Props> = props => {
  const { setActiveStep, setFieldValue, values, setErrorInitialized, errorInitialized } = props;
  const { subjects }: PersistedGeneralState = useSelector((state: RootState) => state.persistedGeneral);
  const [ageLimit, setAgeLimit] = useState([]);
  const [subjectOptions, setSubjectOptions] = useState<SelectItemType[]>([]);

  useEffect(() => {
    if (subjects) {
      switch (values?.program) {
        case 1: {
          setSubjectOptions(subjects?.premium);
          break;
        }
        case 2: {
          setSubjectOptions(subjects?.express);
          break;
        }
        case 3: {
          setSubjectOptions(subjects?.short_courses);
          break;
        }
        default: {
          setSubjectOptions([]);
        }
      }
    }
  }, [values?.program]);

  const onFocusAgeInput = () => {
    if (values?.grades?.length === 0) {
      message.warning("Please select grade first!");
    }
  };

  const gotoNextStep = () => {
    const isShortCourse = values?.program === 3;
    if (
      values?.program &&
      values?.packageMode &&
      values?.enrolmentMode &&
      // values?.recurring &&
      values?.accessMode &&
      values?.subjects &&
      ((Number(values?.program) !== 3 && typeof values?.subjects === "object" && values?.subjects?.length !== 0) ||
        (typeof values?.subjects === "number" && values?.subjects)) &&
      values?.startDate &&
      values?.grades &&
      values?.grades?.length !== 0 &&
      values?.minAge &&
      values?.maxAge &&
      values?.minAge <= values?.maxAge
    ) {
      if (isShortCourse && !values?.endDate) {
        message.warning("Please fill all required fields.");
        setErrorInitialized(true);
      } else {
        setErrorInitialized(false);
        setActiveStep(1);
      }
    } else {
      message.warning("Please fill all required fields.");
      setErrorInitialized(true);
    }
  };

  const disableDate = (currentDate: Dayjs): boolean => {
    const minDate: Dayjs = dayjs()?.startOf("day");
    const maxDate: Dayjs = dayjs()?.add(2, "months")?.startOf("day");
    if (values?.program === 3) {
      return currentDate?.isBefore(minDate) || currentDate?.isAfter(maxDate);
    } else {
      return currentDate?.isBefore(minDate);
    }
  };

  const updateAgeLimitArray = (value: string[]) => {
    const selectedAges = value?.map((grade: string) => {
      return find(ageLimitForGrade, { value: grade });
    });
    const minAges: number[] = [];
    selectedAges?.forEach((item?: AgeLimitType) => {
      if (item) {
        new Array(item?.max - item?.min + 1).fill(0).forEach((_, index: number) => {
          minAges.push(item?.min + index);
        });
      }
    });
    const formattedMinAges = [...new Set(minAges)].sort((a, b) => a - b);
    const ageLimitArray: any = formattedMinAges.map((item: number, index: number) => {
      return {
        id: index + 1,
        label: `${item} Years Old`,
        value: item,
      };
    });
    setAgeLimit(ageLimitArray);
  };

  useEffect(() => {
    if (values?.grades && values?.grades?.length !== 0) {
      updateAgeLimitArray(values?.grades);
    }
  }, []);

  const onChangeGrade = (value: any) => {
    if (value && values && values?.grades && (values?.grades?.length < 3 || value?.length < values?.grades?.length)) {
      setFieldValue("grades", value);
      updateAgeLimitArray(value);
      if (value && value?.length === 0) {
        setFieldValue("minAge", "");
        setFieldValue("maxAge", "");
      }
    } else {
      message.error("You can select up to 3 grades at a time.");
    }
  };

  const getMinAgeErrorMessage = (): string => {
    if (errorInitialized && !values?.minAge) {
      return "Please select min age";
    } else if (values?.minAge && values?.maxAge && values?.minAge > values?.maxAge) {
      return "Min age can not be more than the max age";
    }
    return "";
  };

  const updateTotalSeats = (value: number) => {
    const updatedTimeSlots: TimeSlot[] = values.timeSlots?.map((el: TimeSlot) => {
      return {
        ...el,
        totalSeats: String(value),
      };
    });
    setFieldValue("timeSlots", updatedTimeSlots);
  };

  return (
    <div>
      <div className="white_box p-25">
        <div className="d-row">
          <Text font="SEMIBOLD" className="mb-10" size="S">
            Program
          </Text>
          <span style={{ width: 4 }} />
          <Text font="LIGHTER" size="S">
            (Select your Program)<span className="red">*</span>
          </Text>
        </div>
        <div className={styles.program_input}>
          <Row gutter={[20, 20]} className={styles.program_input_row}>
            {courseTypes.map(item => (
              <Col span={8} key={item.id}>
                <div
                  className={styles.type_box}
                  style={{ border: values?.program === item.id ? "2px solid var(--pink)" : "2px solid #dedede" }}
                  onClick={() => {
                    setFieldValue("program", item.id);
                    setFieldValue("subjects", []);
                  }}>
                  {values?.program === item.id ? (
                    <div className={styles.pink_circle}>
                      <div className={styles.filled_pink_circle} />
                    </div>
                  ) : (
                    <div className={styles.grey_circle} />
                  )}
                  <Text font="SEMIBOLD" className="mt-12 mb-8" color={values?.program === item.id ? "PINK" : "BLACK"}>
                    {item.title}
                  </Text>
                  <Text size="S" font="LIGHTER" className={styles.type_description}>
                    {item.description}
                  </Text>
                </div>
              </Col>
            ))}
          </Row>
        </div>
        <div className="mt-15 pt-10">
          <Row gutter={[25, 25]}>
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text size="S" font="SEMIBOLD" className="mb-10">
                Package Mode<span className="red">*</span>
              </Text>
              <RadioGroupButton
                value={values?.packageMode}
                onChange={e => setFieldValue("packageMode", e.target.value)}
                options={packageModes}
                error={errorInitialized && !values?.packageMode ? "Please select package mode" : ""}
              />
            </Col>
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text size="S" font="SEMIBOLD" className="mb-10">
                Enrolment Mode<span className="red">*</span>
              </Text>
              <RadioGroupButton
                options={enrollmentModes}
                value={values?.enrolmentMode}
                onChange={e => {
                  if (e?.target?.value === "batch") {
                    updateTotalSeats(6);
                  } else {
                    updateTotalSeats(1);
                  }
                  setFieldValue("enrolmentMode", e.target.value);
                }}
                error={errorInitialized && !values?.enrolmentMode ? "Please select enrolment mode" : ""}
              />
            </Col>
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text size="S" font="SEMIBOLD" className="mb-10">
                Access Mode<span className="red">*</span>
              </Text>
              <RadioGroupButton
                value={values?.accessMode}
                onChange={e => setFieldValue("accessMode", e.target.value)}
                options={accessModes}
                error={errorInitialized && !values?.accessMode ? "Please select access mode" : ""}
              />
            </Col>
            {/* {Number(values?.program) !== 3 && (
              <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
                <Text size="S" font="SEMIBOLD" className="mb-10">
                  Recurring<span className="red">*</span>
                </Text>
                <RadioGroupButton
                  value={values?.recurring}
                  onChange={e => setFieldValue("recurring", e.target.value)}
                  options={recurringOptions}
                  error={errorInitialized && !values?.recurring ? "Please select one option" : ""}
                />
              </Col>
            )} */}
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text font="SEMIBOLD" className="mb-10" size="S">
                Subject<span className="red">*</span>
              </Text>
              <SelectInput
                allowClear
                mode={Number(values?.program) === 3 ? undefined : "multiple"}
                placeholder="Enter your subjects"
                options={subjectOptions}
                value={values?.subjects}
                error={
                  (errorInitialized && typeof values?.subjects === "object" && values?.subjects?.length === 0) ||
                  (typeof values?.subjects === "number" && !values?.subjects)
                    ? "Please select subject"
                    : ""
                }
                onChange={(value: any) => {
                  if (Number(values?.program) !== 3 && typeof values?.subjects == "object") {
                    if (
                      values &&
                      values?.subjects &&
                      (values?.subjects?.length < 4 || value?.length < values?.subjects?.length)
                    ) {
                      setFieldValue("subjects", value);
                    } else {
                      message.error("You can select up to 4 subjects at a time");
                    }
                  } else {
                    setFieldValue("subjects", value);
                  }
                }}
              />
            </Col>
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text size="S" font="SEMIBOLD" className="mb-10">
                Start Date<span className="red">*</span>
              </Text>
              <DatePicker
                placeholder="Enter start date"
                format={dateFormat}
                error={errorInitialized && !values?.startDate ? "Please select start date" : ""}
                // value={dayjs(values?.startDate, dateFormat)?.isValid() ? dayjs(values?.startDate, dateFormat) : null}
                onChange={(_, dateString: string) => setFieldValue("startDate", dateString)}
                disabledDate={disableDate}
              />
            </Col>
            {values?.program === 3 && (
              <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
                <Text size="S" font="SEMIBOLD" className="mb-10">
                  End Date<span className="red">*</span>
                </Text>
                <DatePicker
                  placeholder="Enter start date"
                  format={dateFormat}
                  // value={dayjs(values?.endDate, dateFormat)?.isValid() ? dayjs(values?.endDate, dateFormat) : null}
                  error={values?.program === 3 && errorInitialized && !values?.endDate ? "Please select end date" : ""}
                  onChange={(_, dateString: string) => setFieldValue("endDate", dateString)}
                  disabledDate={disableDate}
                />
              </Col>
            )}
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text font="SEMIBOLD" className="mb-10" size="S">
                Grade<span className="red">*</span>
              </Text>
              <SelectInput
                placeholder="Select grade"
                options={grades}
                allowClear
                mode="multiple"
                value={values?.grades}
                error={errorInitialized && values?.grades?.length === 0 ? "Please select grade" : ""}
                onChange={onChangeGrade}
              />
            </Col>
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text font="SEMIBOLD" className="mb-10" size="S">
                Min Age<span className="red">*</span>
              </Text>
              <SelectInput
                allowClear
                placeholder="Select min age of the student"
                options={ageLimit}
                value={values?.minAge || undefined}
                onChange={(value: any) => setFieldValue("minAge", value)}
                onFocus={onFocusAgeInput}
                error={getMinAgeErrorMessage()}
              />
            </Col>
            <Col xxl={8} xl={12} lg={12} md={12} sm={24} xs={24}>
              <Text font="SEMIBOLD" className="mb-10" size="S">
                Max Age<span className="red">*</span>
              </Text>
              <SelectInput
                allowClear
                placeholder="Select max age of the student"
                options={ageLimit}
                value={values?.maxAge || undefined}
                onChange={(value: any) => setFieldValue("maxAge", value)}
                onFocus={onFocusAgeInput}
                error={errorInitialized && !values?.maxAge ? "Please select max age" : ""}
              />
            </Col>
            <Col span={24} className={"justify-end mt-10"}>
              <Button onClick={gotoNextStep} type="tertiary">
                Next <RightOutlined />
              </Button>
            </Col>
          </Row>
        </div>
      </div>
    </div>
  );
};

export default ProgramDetails;
