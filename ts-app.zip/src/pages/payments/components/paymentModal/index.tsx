import React, { useEffect, useMemo, useState } from "react";
import { Modal as AntdModal, Col, Row } from "antd";
import Text from "src/components/text";
import { Color } from "@type/index";
import styles from "../../styles.module.css";
import { IInvoice } from "@type/payments";
import moment from "moment-timezone";
import { getPenaltyAmount } from "src/utils";

interface IPaymentModal {
  showModal: boolean;
  handleClose: () => void;
  data: IInvoice;
}

interface IValue {
  title: string;
  color?: Color;
}
interface IItems {
  key: string;
  title: string;
  value: string | IValue[];
  color?: Color;
}

const invoiceDetail: IItems[] = [
  {
    key: "number",
    title: "Invoice Number",
    value: "",
  },
  {
    key: "date",
    title: "Invoice Date",
    value: "",
  },
  {
    key: "dueDate",
    title: "Due Date",
    value: "",
  },
  {
    key: "name",
    title: "Student Name",
    value: "",
  },
  {
    key: "amount",
    title: "Amount",
    value: "",
  },
  {
    key: "amountAfter",
    title: "Amount After Due Date",
    value: "",
  },
  {
    key: "discount",
    title: "Discount",
    value: "",
  },
  {
    key: "status",
    title: "Share Status",
    value: "",
    color: "GREEN02",
  },
  {
    key: "paymentStatus",
    title: "Payment Status",
    value: [
      {
        title: "Paid",
        color: "DARK_GREEN",
      },
      {
        title: "09 Mar 2022",
      },
    ],
  },
];

const PaymentModal: React.FC<IPaymentModal> = ({ data, showModal, handleClose }) => {
  const [invoiceData, setInvoiceData] = useState<IItems[]>([]);

  useEffect(() => {
    if (data) {
      setData(data);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  const getPaidStatus: IValue[] = useMemo(() => {
    return [
      {
        title: "Paid",
        color: "DARK_GREEN",
      },
      {
        title: moment(data.paid_at).format("DD MMM YYYY"),
      },
    ];
  }, [data]);

  const getUnPaidStatus: IValue[] = useMemo(() => {
    return [
      {
        title: "Unpaid",
        color: "RED",
      },
      {
        title: "",
      },
    ];
  }, []);

  const setData = (item: IInvoice) => {
    const updatedData = invoiceDetail.map(i => {
      let value: string | IValue[] = "";
      let color: Color = "BLACK02";

      switch (i.key) {
        case "number":
          value = `INV${item.id}`;
          break;

        case "date":
          value = moment(item.invoice_date).format("DD MMM YYYY");
          break;

        case "dueDate":
          value = moment(item.due_date).format("DD MMM YYYY");
          break;

        case "name":
          value = item.student.name;
          break;

        case "amount":
          value = item.currency === "PKR" ? `PKR ${item.amount}` : `USD ${item.amount}`;
          break;

        case "amountAfter":
          value = getPenaltyAmount(item);
          break;

        case "discount":
          value = item.currency === "PKR" ? `PKR ${item.discount}` : `USD ${item.discount}`;
          break;

        case "status":
          value = item.share_transfer_at ? "Transfered" : "Pending Transfer";
          color = item.share_transfer_at ? "DARK_GREEN" : "GREEN02";
          break;

        case "paymentStatus":
          value = item.payment_status === "paid" ? getPaidStatus : getUnPaidStatus;
          break;

        default:
          break;
      }

      return {
        ...i,
        color,
        value: value,
      };
    });

    setInvoiceData(updatedData);
  };

  // const getDnlShare = useMemo(() => {
  //   if (data.currency === "USD") {
  //     return `USD ${data.payments[0].dnl_share}`;
  //   }

  //   return `PKR ${data.payments[0].dnl_share}`;
  // }, [data]);

  const getTeacherShare = useMemo(() => {
    if (data.currency === "USD") {
      return `USD ${data.payments[0].teacher_share}`;
    }

    return `PKR ${data.payments[0].teacher_share}`;
  }, [data]);

  const getConversionAmount = useMemo(() => {
    if (data && data.conversion_rate) {
      const rate = data.conversion_rate * data.payments[0].teacher_share;
      const formatted = rate.toFixed(2);

      return parseFloat(formatted).toString();
    }
  }, [data]);

  return (
    <AntdModal open={showModal} onCancel={handleClose} footer={false}>
      <div>
        <Row className={styles.row}>
          <Col span={24}>
            <Text title={"Payment Information"} font={"SEMIBOLD"} size={"M"} color={"HEADING"} />
          </Col>
        </Row>

        <div className={styles.modalBody}>
          <Row gutter={[10, 10]}>
            {invoiceData.map((i, index) => (
              <Col span={24} key={index} className={styles.modalItems}>
                <Text title={i.title} font={"LIGHTER"} size={"S"} color={"BLACK02"} />

                {typeof i.value === "string" ? (
                  <Text title={i.value} font={"NORMAL"} size={"S"} color={i.color ? i.color : "BLACK02"} />
                ) : (
                  <div className={styles.status}>
                    {i.value.map(j => (
                      <Text
                        key={`${i.title}-${j.title}`}
                        title={j.title}
                        font={"SEMIBOLD"}
                        lHeight={"S"}
                        size={"S"}
                        color={j.color ? j.color : "BLACK02"}
                      />
                    ))}
                  </div>
                )}
              </Col>
            ))}
          </Row>
        </div>

        <Row className={styles.row}>
          <Col span={24}>
            <Text title={"Share Info"} font={"SEMIBOLD"} size={"S"} color={"HEADING"} />
          </Col>
        </Row>

        <div className={styles.modalFooter}>
          {/* <div className={styles.modalItems}>
            <Text title={"DNL Share"} font={"LIGHTER"} size={"S"} color={"BLACK02"} />

            <Text title={getDnlShare} font={"SEMIBOLD"} size={"S"} color={"BLACK02"} />
          </div> */}

          <div className={styles.modalItems}>
            <Text title={"Teacher Share"} font={"LIGHTER"} size={"S"} color={"BLACK02"} />

            <Text title={getTeacherShare} font={"SEMIBOLD"} size={"S"} color={"BLACK02"} />
          </div>

          {data.currency === "USD" && (
            <>
              <div className={styles.modalItems}>
                <Text title={"Conversion Rate"} font={"LIGHTER"} size={"S"} color={"BLACK02"} />

                <Text title={`PKR ${data.conversion_rate.toString()}`} font={"SEMIBOLD"} size={"S"} color={"BLACK02"} />
              </div>

              <div className={styles.modalItems}>
                <Text title={"Amount"} font={"LIGHTER"} size={"S"} color={"BLACK02"} />

                <Text
                  title={`${getTeacherShare} = PKR ${getConversionAmount}`}
                  font={"SEMIBOLD"}
                  size={"S"}
                  color={"BLACK02"}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </AntdModal>
  );
};

export default PaymentModal;
