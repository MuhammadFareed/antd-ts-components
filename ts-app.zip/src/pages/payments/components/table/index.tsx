import React, { MouseEvent, useMemo, useState } from "react";

import { Table, Upload, Button, Col, Row, message } from "antd";
import type { UploadFile, UploadProps } from "antd/es/upload/interface";
import { UploadOutlined, EyeOutlined } from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import { DataType, DefaultPagination } from "@type/index";
import { IInvoice } from "@type/payments";
import styles from "../../styles.module.css";
import Modal from "src/components/modal";
import { capitilizeFirstLetter } from "src/utils";
import moment from "moment-timezone";
import { uploadReceipt } from "src/store/actions";
import { MEDIA_BASE_URL } from "src/config/api-constants";
import checkmark from "src/assets/svgs/checkmark.svg";

type PaymentStatus = "paid" | "unpaid" | "pending";

interface SelectedFilesState {
  [key: string]: UploadFile<any> | undefined;
}

interface ITableComponent {
  data: DefaultPagination<IInvoice[]> | undefined;
  handleRowClick: (record: DataType, event?: MouseEvent<HTMLTableRowElement>) => void;
  isLoading: boolean;
  handleChange: (page: number, pageSize: number) => void;
  paymentStatus: PaymentStatus;
}

const TableComponent: React.FC<ITableComponent> = ({
  data,
  handleRowClick,
  isLoading,
  handleChange,
  paymentStatus,
}) => {
  const [selectedFiles, setSelectedFiles] = useState<SelectedFilesState>({});
  const [invoiceId, setInvoiceId] = useState<string>("");
  const [uploadLoading, setUploadLoading] = useState<boolean>(false);
  const [uploadModal, setUploadModal] = useState<boolean>(false);

  const handleOk = () => {
    setUploadLoading(true);

    if (!selectedFiles[invoiceId]) {
      message.error("Please select a file to upload.");
      setUploadLoading(false);
      return;
    }

    uploadReceipt({ invoice_id: invoiceId, receipt: selectedFiles[invoiceId] as never })
      .then(response => {
        const msg = response as string;
        message.success(msg);
        setSelectedFiles(prevState => ({
          ...prevState,
          [invoiceId]: undefined,
        }));
        setInvoiceId("");
        setUploadLoading(false);
        setUploadModal(false);
      })
      .catch(err => {
        message.error(err?.response?.data?.message);
        setUploadLoading(false);
      });
  };

  const handleCancel = () => {
    setSelectedFiles(prevState => ({
      ...prevState,
      [invoiceId]: undefined,
    }));
    setUploadModal(false);
  };

  const getColumns = useMemo(() => {
    const columns: ColumnsType<DataType> = [
      {
        title: "Invoice No.",
        dataIndex: "id",
        key: "id",
        render: (text, item: DataType) => (
          <div onClick={() => handleRowClick(item)} className={styles.link}>{`INV${text}`}</div>
        ),
      },
      {
        title: "Student Name",
        dataIndex: "studentName",
        key: "name",
        render: (text, item) => item.student.name,
      },
      {
        title: "Amount",
        dataIndex: "amount",
        key: "amount",
        render: (text, item) => (item.currency === "PKR" ? `PKR ${text}` : `USD ${text}`),
      },
      {
        title: "Payment Status",
        dataIndex: "payment_status",
        key: "payment_status",
        render: text => capitilizeFirstLetter(text),
      },
      {
        title: "Transfer Status",
        dataIndex: "transfer_status",
        key: "transfer_status",
        render: (text, item) => {
          return item.share_transfer_at ? <img src={checkmark} style={{ width: 25, height: 25 }} /> : "❌";
        },
      },
      {
        title: "Invoice Date",
        dataIndex: "invoice_date",
        key: "invoice_date",
        render: text => moment(text).format("DD MMM YYYY"),
      },
      {
        title: "Due Date",
        dataIndex: "due_date",
        key: "due_date",
        render: text => moment(text).format("DD MMM YYYY"),
      },
      {
        title: "Paid On",
        dataIndex: "paid_at",
        key: "paid_at",
        render: (text, item) => (item.payment_status === "paid" ? moment(text).format("DD MMM YYYY") : ""),
      },
      // {
      //   title: "Classes Taken",
      //   dataIndex: "classTaken",
      //   key: "classTaken",
      //   render: (_, item) => `${item.payments[0].no_of_days}/30`,
      // },
      {
        title: "Upload",
        dataIndex: "receipt",
        key: "receipt",
        render: (_, item) => {
          const filteredFileList = selectedFiles[item.id] ? [selectedFiles[item.id]] : [];

          const props: UploadProps = {
            multiple: false,
            maxCount: 1,
            fileList: filteredFileList as never,
            onRemove: () => {
              setSelectedFiles(prevState => ({
                ...prevState,
                [item.id]: undefined,
              }));
            },
            beforeUpload: file => {
              setSelectedFiles(prevState => ({
                ...prevState,
                [item.id]: file,
              }));
              setInvoiceId(item.id);
              setUploadModal(true);

              return false;
            },
          };

          const handleClick = () => {
            if (item.receipt) {
              const url = `${MEDIA_BASE_URL}${item.receipt}`;
              window.open(url, "_blank");
            }
          };

          return (
            <Row gutter={[20, 10]} align={"middle"} justify={"space-evenly"}>
              <Upload {...props}>
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>

              <div style={{ width: "20%" }}>
                {item.receipt && (
                  <Button onClick={handleClick} icon={<EyeOutlined className={styles.viewImg} />}></Button>
                )}
              </div>
            </Row>
          );
        },
      },
    ];

    if (paymentStatus === "unpaid" || paymentStatus === "pending") {
      columns.splice(7, 1);
    }

    return columns;
  }, [handleRowClick, paymentStatus, selectedFiles]);

  return (
    <div>
      <Table
        dataSource={data?.data as unknown as DataType[]}
        pagination={{
          pageSize: data?.per_page,
          current: data?.current_page,
          total: data?.total,
          onChange: handleChange,
        }}
        loading={isLoading}
        columns={getColumns}
        scroll={{ x: 900 }}
      />

      <Modal
        open={uploadModal}
        onOk={handleOk}
        okButtonLoading={uploadLoading}
        onCancel={handleCancel}
        showCancelButton
        title={"Confirmation"}>
        <Row>
          <Col span={24}>{"Are you sure you want to upload this file?"}</Col>
          <Col className={styles.link} span={24}>
            {selectedFiles[invoiceId]?.name || ""}
          </Col>
        </Row>
      </Modal>
    </div>
  );
};

export default TableComponent;
