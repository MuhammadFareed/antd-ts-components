import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Col, Row, Tabs, DatePicker, Space } from "antd";
import type { TabsProps } from "antd";
import Header from "src/components/header";
import Text from "src/components/text";
import total_packages from "src/assets/svgs/paper_fill.svg";
import paidInvoice from "src/assets/svgs/paid_Invoices";
import pending from "src/assets/svgs/pending";
import TextInput from "src/components/input";
import TableComponent from "./components/table";
import PaymentModal from "./components/paymentModal";
import search from "src/assets/svgs/search";
import { RootState } from "@store/reducers";
import Wallet_alt_duotone from "src/assets/svgs/Wallet_alt_duotone.svg";
import { useSelector, useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import { IInvoice } from "@type/payments";
import * as actions from "src/store/actions";
import { debounce } from "lodash";
import styles from "./styles.module.css";
import { DataType } from "@type/index";
import { RangePickerProps } from "antd/es/date-picker";

const dateFormat = "DD-MM-YYYY";
const { RangePicker } = DatePicker;
type PaymentStatus = "paid" | "unpaid" | "pending";
interface Params {
  start_date?: string;
  end_date?: string;
  invoice_id?: string;
}

const Payments = () => {
  const dispatch = useDispatch();
  const action = bindActionCreators(actions, dispatch);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [selectedInvoice, setSelectedInvoice] = useState<IInvoice>();
  const [invoiceId, setInvoiceId] = useState<string>("");
  const [sDate, setSDate] = useState<string>();
  const [eDate, setEDate] = useState<string>();
  const handleText = (e: string) => setInvoiceId(e);
  const [activeKey, setActiveKey] = useState<PaymentStatus>("paid");
  const {
    invoiceSummary,
    paidInvoicesLoading,
    unPaidInvoicesLoading,
    paidInvoices,
    unPaidInvoices,
    pendingInvoices,
    pendingInvoicesLoading,
  } = useSelector((state: RootState) => state.payment);
  const closeModal = () => setShowModal(false);
  const dateRef = useRef(null);

  useEffect(() => {
    const debouncing = debounce(() => {
      handlePaginate(1, 10, activeKey);
    }, 1000);

    debouncing();

    return () => {
      debouncing.cancel();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invoiceId, sDate, activeKey]);

  const handlePaginate = useCallback(
    (page: number, pageSize: number, status: PaymentStatus) => {
      const params: Params = {};

      if (sDate) {
        params.start_date = sDate;
      }

      if (eDate) {
        params.end_date = eDate;
      }

      if (invoiceId) {
        params.invoice_id = invoiceId.replace("INV", "");
      }

      action.getTeacherPayments(status, {
        ...params,
        page,
        limit: pageSize,
      });
    },
    [action, eDate, invoiceId, sDate],
  );

  const handleShow = (item: DataType) => {
    const invoice = item as unknown as IInvoice;
    setShowModal(true);
    setSelectedInvoice(invoice);
  };

  useEffect(() => {
    fetchData();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchData = () => {
    action.getInvoiceSummary();
  };

  const dateFormatter = (dateString: string) => {
    const parts = dateString.split("-");

    if (parts.length === 3) {
      const day = parts[0];
      const month = parts[1];
      const year = parts[2];

      return `${year}-${month}-${day}`;
    }
  };

  const onChangeDate: RangePickerProps["onChange"] = (date, dateStr) => {
    if (dateStr.some(i => Boolean(i))) {
      const startDate = dateFormatter(dateStr[0]);
      const endDate = dateFormatter(dateStr[1]);

      setSDate(startDate);
      setEDate(endDate);
    } else {
      setSDate("");
      setEDate("");
    }
  };

  const itemsMemo = useMemo(() => {
    if (invoiceSummary) {
      const items: TabsProps["items"] = [
        {
          key: "paid",
          label: `Paid (${invoiceSummary?.total_paid || 0})`,
          children: (
            <TableComponent
              data={paidInvoices}
              handleChange={(a, b) => handlePaginate(a, b, "paid")}
              isLoading={paidInvoicesLoading}
              handleRowClick={handleShow}
              paymentStatus={activeKey}
            />
          ),
        },
        {
          key: "unpaid",
          label: `Unpaid (${invoiceSummary?.total_unpaid || 0})`,
          children: (
            <TableComponent
              data={unPaidInvoices}
              handleChange={(a, b) => handlePaginate(a, b, "unpaid")}
              isLoading={unPaidInvoicesLoading}
              handleRowClick={handleShow}
              paymentStatus={activeKey}
            />
          ),
        },
        {
          key: "pending",
          label: `Pending Transfer (${invoiceSummary?.pending || 0})`,
          children: (
            <TableComponent
              data={pendingInvoices}
              handleChange={(a, b) => handlePaginate(a, b, "pending")}
              isLoading={pendingInvoicesLoading}
              handleRowClick={handleShow}
              paymentStatus={activeKey}
            />
          ),
        },
      ];
      return items;
    }
  }, [
    activeKey,
    handlePaginate,
    invoiceSummary,
    paidInvoices,
    paidInvoicesLoading,
    pendingInvoices,
    pendingInvoicesLoading,
    unPaidInvoices,
    unPaidInvoicesLoading,
  ]);

  const onChangeTab = (e: string) => {
    setSDate("");
    setEDate("");
    setInvoiceId("");
    setActiveKey(e as PaymentStatus);
  };

  const getTotalEarnings = useMemo(() => {
    const earnings = invoiceSummary.total_earnings_pkr;
    const formatted = earnings.toFixed(2);

    return parseFloat(formatted).toString();
  }, [invoiceSummary.total_earnings_pkr]);

  return (
    <div>
      <Header />

      <div className="container py-35">
        <Text title={"Payment"} font={"SEMIBOLD"} size={"XL"} color={"HEADING"} />
        <Row gutter={[20, 0]}>
          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                <img src={total_packages} className={styles.total_packages_icon} alt="" />
                <div className="ml-12">
                  <Text title={invoiceSummary.total_invoices.toString() || "0"} font="SEMIBOLD" size="XXL2" />
                  <Text title="Total Invoices" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>

          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                {paidInvoice}
                <div className="ml-12">
                  <Text title={invoiceSummary.total_paid || "0"} font="SEMIBOLD" size="XXL2" />
                  <Text title="Paid Invoices" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>

          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                {pending}
                <div className="ml-12">
                  <Text title={invoiceSummary.total_unpaid || "0"} font="SEMIBOLD" size="XXL2" />
                  <Text title="Pending" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>

          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                <img src={Wallet_alt_duotone} className={styles.total_packages_icon} alt="" />
                <div className="ml-12">
                  <Text title={`RS ${getTotalEarnings || 0}`} font="SEMIBOLD" size="XXL2" />
                  <Text title="Your Earning" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>
        </Row>

        <div className="white_box px-20 py-15 mt-20">
          <Row>
            <Col span={24}>
              <Row className={styles.searchBar}>
                <Col className="mr-20 mb-10" xxl={8} xl={8} lg={8} md={10} sm={10} xs={20}>
                  <TextInput
                    onChange={handleText}
                    className={styles.textInput}
                    suffix={search}
                    placeholder={"Search by Invoice ID"}
                  />
                </Col>

                <Col xxl={6} xl={6} lg={6} md={9} sm={9} xs={21}>
                  <Space>
                    <Text title="FIlters" color="HEADING" font="SEMIBOLD" size="S" />
                    <RangePicker
                      ref={dateRef}
                      placeholder={["Start date", "End date"]}
                      format={dateFormat}
                      onChange={onChangeDate}
                    />
                  </Space>
                </Col>
              </Row>

              <Col>
                <Tabs defaultActiveKey={activeKey} items={itemsMemo} onChange={onChangeTab} />
              </Col>
            </Col>
          </Row>
        </div>
      </div>

      {showModal && selectedInvoice && (
        <PaymentModal showModal={showModal} data={selectedInvoice} handleClose={closeModal} />
      )}
    </div>
  );
};
export default Payments;
