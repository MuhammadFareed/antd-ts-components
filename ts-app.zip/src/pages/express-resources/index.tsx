import React, { FC, Fragment } from "react";
import LearningLayout from "src/components/learning-layout";
import HomeworkHelp from "./homework-help";
import Introduction from "./introduction";
import SchoolAdmissionTests from "./school-admission-tests";
import { useLocation, useParams } from "react-router-dom";
import { RootState } from "@store/reducers";
import { useSelector } from "react-redux";
import Loader from "src/components/loader";
import styles from "./styles.module.css";
import Text from "src/components/text";
import { capitilizeBreadcrumb } from "src/utils";
import SupplementaryOnlineResources from "./supplementary-online-resources";

const ExpressResources: FC = () => {
  const { id } = useParams();
  const { loadingLearningResouces, learningResouces } = useSelector((state: RootState) => state?.learning);
  const { pathname } = useLocation();
  const splittedPathname = pathname?.split("/").slice(1);
  const { expressResources } = learningResouces;
  const homeworkResources = expressResources?.find(e => e?.id === 1); // id 1 for Homework help
  const admissionResources = expressResources?.find(e => e?.id === 2); // id 2 for School admission tests
  const onlineResources = expressResources?.find(e => e?.id === 3); // id 3 for Supplementary Online Resources

  const SegmentDetails = () => {
    switch (id) {
      case "introduction": {
        return <Introduction />;
      }
      case "homework-help": {
        return <HomeworkHelp data={homeworkResources} />;
      }
      case "school-admission-tests": {
        return <SchoolAdmissionTests data={admissionResources} />;
      }
      case "supplementary-online-resources": {
        return <SupplementaryOnlineResources data={onlineResources} />;
      }
      default: {
        return <Fragment />;
      }
    }
  };

  return (
    <LearningLayout>
      {loadingLearningResouces && <Loader fullPage />}
      <Fragment>
        {splittedPathname && splittedPathname?.length && (
          <div className={styles.breadcrumb}>
            <Text className={styles.breadcrumb_text}>Learning</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>Express Resources</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>{capitilizeBreadcrumb(id || "")}</Text>
          </div>
        )}
      </Fragment>
      <div className={styles.express_resources}>
        <SegmentDetails />
      </div>
    </LearningLayout>
  );
};

export default ExpressResources;
