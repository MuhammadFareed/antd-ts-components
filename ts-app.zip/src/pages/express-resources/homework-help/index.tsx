import React, { FC, Fragment } from "react";
import styles from "./../styles.module.css";
import Link from "src/components/link";
import { Table } from "antd";
import { ExpressResource, ExpressResourceLink, ResourceType } from "@type/index";
import parser from "html-react-parser";
import { resourceTypes } from "src/constant";

type Props = {
  data?: ExpressResource;
};

const HomeworkHelp: FC<Props> = props => {
  const { data } = props;

  return (
    <div className={styles.homework_help}>
      {data && (
        <Fragment>
          <div className={styles.description}>{parser(data?.description || "")}</div>
          <Table
            bordered
            size="small"
            className="mt-30"
            pagination={{ hideOnSinglePage: true, defaultPageSize: 10 }}
            columns={[
              {
                title: "#",
                dataIndex: "id",
                width: 50,
                className: "text-center",
              },
              {
                title: "Type",
                dataIndex: "type",
                render: (item: ResourceType) => resourceTypes[item],
                width: 160,
              },
              {
                title: "Link",
                render: record => (
                  <Link target="_blank" to={record.link}>
                    {record?.title}
                  </Link>
                ),
              },
              {
                title: "Description",
                render: record => parser(record?.description),
              },
            ]}
            dataSource={data?.links?.map((el: ExpressResourceLink, index: number) => {
              return {
                id: index + 1,
                type: el?.type,
                link: el?.link,
                title: el?.title,
                description: el?.description,
              };
            })}
          />
        </Fragment>
      )}
    </div>
  );
};

export default HomeworkHelp;
