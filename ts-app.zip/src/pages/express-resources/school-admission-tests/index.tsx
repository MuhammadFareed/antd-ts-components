import React, { FC } from "react";
import { Table } from "antd";
import parser from "html-react-parser";
import { Link } from "react-router-dom";
import styles from "./../styles.module.css";
import { resourceTypes } from "src/constant";
import { ExpressResource, ExpressResourceLink, ResourceType } from "@type/index";

type Props = {
  data?: ExpressResource;
};

const SchoolAdmissionTests: FC<Props> = props => {
  const { data } = props;

  return (
    <div className="mt-40 mb-10">
      {data && (
        <>
          <div className={styles.description}>{parser(data?.description || "")}</div>
          <Table
            bordered
            size="small"
            className="mt-30"
            pagination={{ hideOnSinglePage: true, defaultPageSize: 10 }}
            columns={[
              {
                title: "#",
                dataIndex: "id",
                width: 50,
                className: "text-center",
              },
              {
                title: "Type",
                dataIndex: "type",
                render: (item: ResourceType) => resourceTypes[item],
                width: 160,
              },
              {
                title: "Link",
                render: record => (
                  <Link target="_blank" to={record.link}>
                    {record?.title}
                  </Link>
                ),
              },
              {
                title: "Description",
                render: record => parser(record?.description),
              },
            ]}
            dataSource={data?.links?.map((el: ExpressResourceLink, index: number) => {
              return {
                id: index + 1,
                type: el?.type,
                link: el?.link,
                title: el?.title,
                description: el?.description,
              };
            })}
          />
        </>
      )}
    </div>
  );
};

export default SchoolAdmissionTests;
