import React, { FC } from "react";
import Text from "src/components/text";
import styles from "./../styles.module.css";

const Introduction: FC = () => {
  return (
    <div className="mt-40 mb-10">
      <Text className={"mb-16"} size="L" font="SEMIBOLD">
        Introduction to Express
      </Text>
      <Text className={styles.text_line_height} size="S" font="LIGHTER">
        With the Express Program launch, teachers will be provided with an online repository that will act as a teaching
        aid to make their classroom up to date and efficient. The Express Program moves with each child’s school
        curriculum and covers both homework help and exam preparation for all core subjects.
        <br /> <br />
        To become a Dot and Line trained and certified teacher partner is very competitive and only 8% of applicants
        make the cut. Hence, our teachers are really the best in the country from whom each child can gain maximum
        benefit and academic success. Keeping our high quality benchmark in line across centres, Dot and Line is
        releasing a carefully curated and well-researched archive of content from which Express Tutors can draw practice
        sheets, concept building exercises and mock tests. There really is nothing standing between you and success in
        the form of full batches for your centre! These resources are in the form of online tests and PDFs that can be
        downloaded and printed by teachers for students.
        <br /> <br />
        Dot and Line’s content department delivers to you material for three areas:
        <br />
        <ul className="mt-15">
          <li>Homework help - solution</li>
          <li>School admission tests and exam preparation</li>
          <li>Subject specific online resources</li>
        </ul>
      </Text>
    </div>
  );
};

export default Introduction;
