/* eslint-disable indent */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { ChangeEvent, FC, useCallback, useEffect, useRef, useState } from "react";
import styles from "./styles.module.css";
import Header from "src/components/header";
import { Col, Form, Row, Space, message } from "antd";
import anonymous from "src/assets/images/anonymous.jpeg";
import camera from "src/assets/icons/camera_pink.png";
import Badge from "src/components/badge";
import Text from "src/components/text";
import Button from "src/components/button";
import TextInput from "src/components/input";
import DatePicker from "src/components/date-picker";
import SelectInput from "src/components/select-input";
import { dateFormat, dotAndLineMainDomain } from "src/constant";
import { capitilizeFirstLetter, openLinkInNewTab } from "src/utils";
import Modal from "src/components/modal";
import ChangePassword from "src/pages/change-password";
import { profileServices } from "src/services";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@store/reducers";
import { bindActionCreators } from "redux";
import * as actions from "src/store/actions";
import { Formik, FormikHelpers } from "formik";
import {
  BankFormData,
  ChangePasswordFormData,
  PersistedGeneralState,
  ProfileStateType,
  ProfileFormData,
} from "@type/index";
import { CloseOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import PhoneNumberInput from "src/components/phone-input";
import ProfilePictureGuidelines from "./profile-picture-guidelines";
import DemoVideoGuidelines from "./demo-video-guidelines";
import demo_video_guidelines from "src/assets/pdfs/demo_video_guidelines.pdf";
import Loader from "src/components/loader";
import moment from "moment-timezone";

const ProfileComp: FC = () => {
  const dispatch = useDispatch();
  const action = bindActionCreators(actions, dispatch);
  const profilePictureInputRef = useRef<HTMLInputElement>(null);
  const demoVideoInputRef = useRef<HTMLInputElement>(null);
  const videoBoxRef = useRef<HTMLVideoElement>(null);
  const { profile, persistedGeneral, auth } = useSelector((state: RootState) => state);
  const { userProfile, bankDetails }: ProfileStateType = profile;
  const { domainParametersData }: PersistedGeneralState = persistedGeneral;
  const teacherId = auth?.user?.user?.id;

  // useStates
  const [errorInitialized, setErrorInitialized] = useState<boolean>(false);
  const [errorInitialized2, setErrorInitialized2] = useState<boolean>(false);
  const [errorInitialized3, setErrorInitialized3] = useState<boolean>(false);
  const [showPictureGuideLineModal, setShowPictureGuideLineModal] = useState<boolean>(false);
  const [showChangePasswordModal, setShowChangePasswordModal] = useState<boolean>(false);
  const [showVideoGuideLineModal, setShowVideoGuideLineModal] = useState<boolean>(false);
  const [viewedVideoGuidelines, setViewedVideoGuidelines] = useState<boolean>(false);
  const [bankDetailsUpdated, setBankDetailsUpdated] = useState<boolean>(false);
  const [profileUpdated, setProfileUpdated] = useState<boolean>(false);

  const initialValues: ProfileFormData = {
    dob: userProfile?.teacher?.dob,
    experience: userProfile?.teacher?.years_of_experience,
    country: userProfile?.teacher?.country,
    city: userProfile?.teacher?.city,
    area: userProfile?.teacher?.area,
    address: userProfile?.address,
    cnic: userProfile?.cnic,
    phone: userProfile?.phone,
    profilePhoto: userProfile?.picture,
    subjects: userProfile?.teacher?.subjects || [],
    academicLevel: userProfile?.teacher?.qualification_levels?.id,
    qualification: userProfile?.teacher?.qualification?.id,
    tagLine: userProfile?.teacher?.tagline,
    bio: userProfile?.teacher?.bio,
    demoVideo: userProfile?.teacher?.demo_video || "",
  };

  const bankInitialValues: BankFormData = {
    bankName: bankDetails?.bank_name,
    accountTitle: bankDetails?.account_title,
    iban: bankDetails?.account_iban,
    accountNumber: bankDetails?.account_number,
    swiftCode: bankDetails?.swift_code || "",
  };

  const changePasswordInitialValues: ChangePasswordFormData = {
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  };

  const fetchData = useCallback(() => {
    action.setProfile(teacherId);
    action.setBankDetails();
  }, [teacherId]);

  useEffect(() => {
    fetchData();
  }, []);

  const changePasswordHandler = (
    values: ChangePasswordFormData,
    { setSubmitting, resetForm }: FormikHelpers<ChangePasswordFormData>,
  ) => {
    profileServices
      .changePassword(values)
      .then(() => {
        setSubmitting(false);
        setShowChangePasswordModal(false);
        resetForm();
      })
      .catch(() => setSubmitting(false));
  };

  const updateProfileHandler = (values: ProfileFormData, { setSubmitting }: FormikHelpers<ProfileFormData>) => {
    profileServices
      .updateProfile(values)
      .then(() => {
        setSubmitting(false);
        action.setProfile(teacherId);
        setProfileUpdated(false);
      })
      .catch(() => setSubmitting(false));
  };

  const updateBankDetails = (values: BankFormData, { setSubmitting }: FormikHelpers<BankFormData>) => {
    profileServices.updateBankDetails(values, teacherId).then(() => {
      setSubmitting(false);
      action.setBankDetails();
      setBankDetailsUpdated(false);
    });
  };

  return (
    <div>
      {showChangePasswordModal && (
        <Formik initialValues={changePasswordInitialValues} onSubmit={changePasswordHandler}>
          {({ values, handleSubmit, isSubmitting, resetForm, setFieldValue }) => (
            <Form>
              <Modal
                title={"Change Password"}
                open={showChangePasswordModal}
                maskClosable={false}
                onCancel={() => {
                  resetForm();
                  setShowChangePasswordModal(false);
                  setErrorInitialized3(false);
                }}
                okButtonText={"Save"}
                okButtonLoading={isSubmitting}
                onOk={() => {
                  if (
                    values?.oldPassword &&
                    values?.newPassword &&
                    values?.newPassword?.length >= 8 &&
                    values?.confirmPassword &&
                    values?.confirmPassword?.length >= 8
                  ) {
                    handleSubmit();
                  } else {
                    setErrorInitialized3(true);
                  }
                }}>
                <ChangePassword values={values} setFieldValue={setFieldValue} errorInitialized={errorInitialized3} />
              </Modal>
            </Form>
          )}
        </Formik>
      )}
      <Header />
      <Modal
        title={"Profile Picture Guidelines"}
        open={showPictureGuideLineModal}
        onCancel={() => setShowPictureGuideLineModal(false)}
        okButtonText={"Proceed to Upload"}
        onOk={() => profilePictureInputRef?.current?.click()}>
        <ProfilePictureGuidelines />
      </Modal>
      <Modal
        title={"Demo Video Guidelines"}
        open={showVideoGuideLineModal}
        onCancel={() => {
          setViewedVideoGuidelines(false);
          setShowVideoGuideLineModal(false);
        }}
        okButtonText={viewedVideoGuidelines ? "Proceed to Upload" : "View PDF"}
        onOk={() => {
          if (viewedVideoGuidelines) {
            demoVideoInputRef?.current?.click();
          } else {
            openLinkInNewTab(demo_video_guidelines);
            setViewedVideoGuidelines(true);
          }
        }}>
        <DemoVideoGuidelines />
      </Modal>
      <div className={styles.yellow_div} />
      {userProfile || bankDetails ? (
        <Form>
          <Formik initialValues={initialValues} onSubmit={updateProfileHandler}>
            {({ values, setFieldValue, handleSubmit, isSubmitting }) => (
              <div className={"container"}>
                <Row className="mb-40">
                  <Col xxl={16} xl={16} lg={16} md={24} sm={24} xs={24}>
                    <div className="d-flex">
                      <div className={styles.profile_image_container}>
                        <div
                          title="Upload Profile Picture"
                          className={styles.camera_div}
                          onClick={() => setShowPictureGuideLineModal(true)}>
                          <img src={camera} alt="camera" className={styles.camera} />
                        </div>
                        <img
                          alt="DP"
                          className={styles.dp}
                          src={
                            values?.profilePhoto?.name
                              ? URL?.createObjectURL(values?.profilePhoto)
                              : values?.profilePhoto
                              ? values?.profilePhoto
                              : anonymous
                          }
                        />
                        <input
                          type="file"
                          accept="image/*"
                          className="d-none-imp"
                          ref={profilePictureInputRef}
                          onChange={(event: ChangeEvent<HTMLInputElement>) => {
                            if (event && event?.target?.files && event?.target?.files?.length !== 0) {
                              setFieldValue("profilePhoto", event?.target?.files[0]);
                              setShowPictureGuideLineModal(false);
                              if (!profileUpdated) {
                                setProfileUpdated(true);
                              }
                            }
                          }}
                        />
                      </div>
                      <div className="d-column">
                        <Text className="mt-20 mb-4" bold size="XXL2">
                          {userProfile?.name || ""}
                        </Text>
                        <Text className="mb-10">{userProfile?.email}</Text>
                        <Space>
                          {userProfile?.teacher?.isSuper ? (
                            <div className={[styles.tag, styles.super_tutor_tag].join(" ")}>Super Tutor</div>
                          ) : null}
                          <div className={[styles.tag, styles.tier_tag].join(" ")}>
                            Tier {userProfile?.teacher?.tier}
                          </div>
                        </Space>
                        <Space className={"mt-15"}>
                          {userProfile?.area_manager ? <Badge type="teacher_manager" /> : null}
                          {userProfile?.teacher?.isSuper ? <Badge type="super_teacher" /> : null}
                          {userProfile?.teacher?.is_graduated ? <Badge type="graduate_teacher" /> : null}
                        </Space>
                      </div>
                    </div>
                  </Col>
                  <Col xxl={8} xl={8} lg={8} md={24} sm={24} xs={24} className={"justify-end"}>
                    <Space className="align-start mt-26">
                      <Button onClick={() => openLinkInNewTab(`${dotAndLineMainDomain}/teachers/${teacherId}`)}>
                        View Public Profile
                      </Button>
                      <Button onClick={() => setShowChangePasswordModal(true)} type="secondary">
                        Change Password
                      </Button>
                    </Space>
                  </Col>
                </Row>
                <Row gutter={[20, 24]}>
                  <Col xxl={14} xl={14} lg={24} md={24} sm={24} xs={24}>
                    <div className="white_box p-24 mb-50">
                      <Text font="SEMIBOLD" size="L" className="mb-24">
                        Profile Information
                      </Text>
                      <Row gutter={[20, 24]}>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Date of Birth<span className="red">*</span>
                            </Text>
                            <DatePicker
                              placeholder="Enter date of birth"
                              format={dateFormat}
                              value={dayjs(values?.dob, dateFormat)}
                              defaultValue={dayjs("2005-01-01", dateFormat)}
                              defaultPickerValue={dayjs("2005-01-01", dateFormat)}
                              onChange={(_, dateString: string) => {
                                setFieldValue("dob", dateString);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.dob ? "Please select start date" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Total Experience<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              type="number"
                              disabled
                              placeholder="Enter experience"
                              value={
                                userProfile?.teacher?.recruitedDate
                                  ? moment().diff(moment(userProfile?.teacher?.recruitedDate, dateFormat), "year") +
                                    Number(userProfile?.teacher?.years_of_experience || 0)
                                  : userProfile?.teacher?.years_of_experience
                              }
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Country<span className="red">*</span>
                            </Text>
                            <SelectInput
                              options={domainParametersData?.countries || []}
                              placeholder="Select country"
                              allowClear
                              showSearch
                              value={values.country}
                              onChange={value => {
                                setFieldValue("country", capitilizeFirstLetter(value));
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.country ? "Please select country" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              City<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter city"
                              value={values.city}
                              onChange={value => {
                                setFieldValue("city", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.city ? "Please enter city" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Area<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter area"
                              value={values.area}
                              onChange={value => {
                                setFieldValue("area", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.area ? "Please enter area" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Address<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter address"
                              value={values.address}
                              onChange={value => {
                                setFieldValue("address", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.address ? "Please enter address" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              CNIC<span className="red">*</span>
                            </Text>
                            <TextInput
                              disabled
                              allowClear
                              placeholder="Enter CNIC"
                              value={values.cnic}
                              onChange={value => setFieldValue("cnic", value)}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Phone<span className="red">*</span>
                            </Text>
                            <PhoneNumberInput
                              enableSearch
                              placeholder="Enter phone number"
                              searchNotFound="Result not found."
                              searchPlaceholder="Search by country"
                              value={values?.phone}
                              onChange={value => {
                                setFieldValue("phone", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.phone ? "Please enter phone number" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Subject<span className="red">*</span>
                            </Text>
                            <SelectInput
                              mode="multiple"
                              options={domainParametersData?.subjects || []}
                              placeholder="Select subjects"
                              allowClear
                              showSearch
                              value={values.subjects}
                              error={
                                errorInitialized &&
                                (!values?.subjects || (values?.subjects && values?.subjects?.length === 0))
                                  ? "Please select subject"
                                  : ""
                              }
                              onChange={(value: any) => {
                                if (
                                  values &&
                                  values?.subjects &&
                                  (values?.subjects?.length < 4 || value?.length < values?.subjects?.length)
                                ) {
                                  setFieldValue("subjects", value);
                                  if (!profileUpdated) {
                                    setProfileUpdated(true);
                                  }
                                } else {
                                  message.error("You can select up to 4 subjects at a time.");
                                }
                              }}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Academic Level<span className="red">*</span>
                            </Text>
                            <SelectInput
                              options={domainParametersData?.qualificationLevels || []}
                              placeholder="Select academic level"
                              allowClear
                              showSearch
                              value={values.academicLevel}
                              onChange={value => {
                                setFieldValue("academicLevel", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.academicLevel ? "Please select academic level" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Qualification<span className="red">*</span>
                            </Text>
                            <SelectInput
                              options={domainParametersData?.qualifications || []}
                              placeholder="Select qualification"
                              allowClear
                              showSearch
                              value={values.qualification}
                              onChange={value => {
                                setFieldValue("qualification", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.qualification ? "Please select qualification" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Tag Line<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter tag line"
                              value={values.tagLine}
                              onChange={value => {
                                setFieldValue("tagLine", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.tagLine ? "Please enter tag line" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Bio<span className="red">*</span>
                            </Text>
                            <TextInput
                              multiline
                              rows={5}
                              allowClear
                              placeholder="Enter bio"
                              value={values.bio}
                              onChange={value => {
                                setFieldValue("bio", value);
                                if (!profileUpdated) {
                                  setProfileUpdated(true);
                                }
                              }}
                              error={errorInitialized && !values?.bio ? "Please enter bio" : ""}
                            />
                          </Form.Item>
                        </Col>
                        <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                          <Form.Item className="mb-0">
                            <Space direction="vertical">
                              <Text font="SEMIBOLD" size="S">
                                Demo Video<span className="red">*</span>
                              </Text>
                              <Button
                                className="my-5"
                                type="secondary"
                                onClick={() => setShowVideoGuideLineModal(true)}>
                                Upload Video
                              </Button>
                              {errorInitialized && !values?.demoVideo && (
                                <Text color="RED" size="XS">
                                  Please upload demo video
                                </Text>
                              )}
                              {values?.demoVideo && (
                                <Space>
                                  {values?.demoVideo?.name && (
                                    <Text font="LIGHTER" size="S">
                                      {values?.demoVideo?.name}
                                    </Text>
                                  )}
                                  <div
                                    className={styles.cancel_demo_video_button}
                                    onClick={() => setFieldValue("demoVideo", "")}>
                                    <CloseOutlined />
                                  </div>
                                </Space>
                              )}
                              <input
                                className="d-none-imp"
                                ref={demoVideoInputRef}
                                type="file"
                                id="media-URL"
                                accept="video/*"
                                onChange={(event: ChangeEvent<HTMLInputElement>) => {
                                  if (event && event.target?.files && event.target?.files?.length !== 0) {
                                    setShowVideoGuideLineModal(false);
                                    setViewedVideoGuidelines(false);
                                    setFieldValue("demoVideo", event.target?.files[0]);
                                    videoBoxRef.current?.load();
                                    if (!profileUpdated) {
                                      setProfileUpdated(true);
                                    }
                                  }
                                }}
                              />
                            </Space>
                            {values?.demoVideo && (
                              <video
                                controls
                                ref={videoBoxRef}
                                className={styles.demo_video}
                                src={
                                  values?.demoVideo?.name ? URL.createObjectURL(values?.demoVideo) : values?.demoVideo
                                }
                                controlsList="nodownload">
                                <source
                                  src={
                                    values?.demoVideo?.name ? URL.createObjectURL(values?.demoVideo) : values?.demoVideo
                                  }
                                />
                              </video>
                            )}
                          </Form.Item>
                        </Col>
                        <Col span={24} className={"mb-10 justify-center"}>
                          <Button
                            type="tertiary"
                            disabled={!profileUpdated}
                            onClick={() => {
                              if (
                                values?.dob &&
                                values?.country &&
                                values?.city &&
                                values?.area &&
                                values?.address &&
                                values?.phone &&
                                values?.subjects &&
                                values?.subjects?.length !== 0 &&
                                values?.academicLevel &&
                                values?.qualification &&
                                values?.tagLine &&
                                values?.bio &&
                                values?.demoVideo
                              ) {
                                if (values?.profilePhoto) {
                                  handleSubmit();
                                } else {
                                  message.error("Please upload profile photo first");
                                }
                              } else {
                                setErrorInitialized(true);
                                message.error("Please fill all required fields.");
                              }
                            }}
                            loading={isSubmitting}>
                            Update Profile
                          </Button>
                        </Col>
                      </Row>
                    </div>
                  </Col>
                  <Col xxl={10} xl={10} lg={24} md={24} sm={24} xs={24}>
                    <div className="white_box p-24">
                      <Row gutter={[20, 20]}>
                        {userProfile?.area_manager_name ? (
                          <Col xxl={8} xl={12} lg={8} md={8} sm={12} xs={24}>
                            <Text font="LIGHTER" size="S" className="mb-8">
                              Teacher Manager
                            </Text>
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              {userProfile?.area_manager_name}
                            </Text>
                          </Col>
                        ) : null}
                        <Col xxl={8} xl={12} lg={8} md={8} sm={12} xs={24}>
                          <Text font="LIGHTER" size="S" className="mb-8">
                            Assign Demos
                          </Text>
                          <Text font="SEMIBOLD" size="S" className="mb-8">
                            {userProfile?.teacher?.assignDemos ? "Yes" : "No"}
                          </Text>
                        </Col>
                        {userProfile?.teacher?.recruitedDate && (
                          <Col xxl={8} xl={12} lg={8} md={8} sm={12} xs={24}>
                            <Text font="LIGHTER" size="S" className="mb-8">
                              Recruited Date
                            </Text>
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              {moment(userProfile?.teacher?.recruitedDate, dateFormat)?.format("DD MMM, YYYY")}
                            </Text>
                          </Col>
                        )}
                      </Row>
                    </div>
                    <Formik initialValues={bankInitialValues} onSubmit={updateBankDetails}>
                      {({
                        values: bankFormValues,
                        handleSubmit: handleSubmitBankDetails,
                        isSubmitting: isSubmittingBankForm,
                        setFieldValue: setBankFormValue,
                      }) => (
                        <div className="white_box p-24 mt-20">
                          <Text font="SEMIBOLD" size="L" className="mb-24">
                            Bank Account Information
                          </Text>
                          <Form.Item>
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Bank Name<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter bank name"
                              value={bankFormValues.bankName}
                              onChange={value => {
                                setBankFormValue("bankName", value);
                                if (!bankDetailsUpdated) {
                                  setBankDetailsUpdated(true);
                                }
                              }}
                              error={errorInitialized2 && !bankFormValues?.bankName ? "Please enter bank name" : ""}
                            />
                          </Form.Item>
                          <Form.Item>
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Account Title<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter account title"
                              value={bankFormValues.accountTitle}
                              onChange={value => {
                                setBankFormValue("accountTitle", value);
                                if (!bankDetailsUpdated) {
                                  setBankDetailsUpdated(true);
                                }
                              }}
                              error={
                                errorInitialized2 && !bankFormValues?.accountTitle ? "Please enter account title" : ""
                              }
                            />
                          </Form.Item>
                          <Form.Item>
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Account Number<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter account number"
                              value={bankFormValues.accountNumber}
                              onChange={value => {
                                setBankFormValue("accountNumber", value);
                                if (!bankDetailsUpdated) {
                                  setBankDetailsUpdated(true);
                                }
                              }}
                              error={
                                errorInitialized2 && !bankFormValues?.accountNumber ? "Please enter account number" : ""
                              }
                            />
                          </Form.Item>
                          <Form.Item>
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              IBAN<span className="red">*</span>
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter IBAN"
                              value={bankFormValues.iban}
                              onChange={value => {
                                setBankFormValue("iban", value);
                                if (!bankDetailsUpdated) {
                                  setBankDetailsUpdated(true);
                                }
                              }}
                              error={errorInitialized2 && !bankFormValues?.iban ? "Please enter IBAN" : ""}
                            />
                          </Form.Item>
                          <Form.Item>
                            <Text font="SEMIBOLD" size="S" className="mb-8">
                              Swift Code
                            </Text>
                            <TextInput
                              allowClear
                              placeholder="Enter swift code"
                              value={bankFormValues.swiftCode}
                              onChange={value => {
                                setBankFormValue("swiftCode", value);
                                if (!bankDetailsUpdated) {
                                  setBankDetailsUpdated(true);
                                }
                              }}
                            />
                          </Form.Item>
                          <Form.Item className="mb-10">
                            <Button
                              className="ml-auto mr-auto"
                              loading={isSubmittingBankForm}
                              onClick={() => {
                                if (
                                  bankFormValues?.bankName &&
                                  bankFormValues?.accountTitle &&
                                  bankFormValues?.accountNumber &&
                                  bankFormValues?.iban
                                ) {
                                  handleSubmitBankDetails();
                                } else {
                                  setErrorInitialized2(true);
                                  message.error("Please fill all required fields.");
                                }
                              }}
                              disabled={!bankDetailsUpdated}
                              type="tertiary">
                              Update Bank Details
                            </Button>
                          </Form.Item>
                        </div>
                      )}
                    </Formik>
                  </Col>
                </Row>
              </div>
            )}
          </Formik>
        </Form>
      ) : (
        <Loader fullPage text={"Loading..."} />
      )}
    </div>
  );
};

export default ProfileComp;
