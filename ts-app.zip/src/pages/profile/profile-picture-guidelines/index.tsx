import React, { FC } from "react";
import Text from "src/components/text";
import { profilePictureGuidelines } from "src/constant";

const ProfilePictureGuidelines: FC = () => {
  return (
    <div>
      <Text className="mb-12">
        Please make sure to follow these guidelines for the image to ensure a smooth approval process:
      </Text>
      <ul>
        {profilePictureGuidelines?.map((text: string) => (
          <li>
            <Text className="mb-4" font="LIGHTER" size="S">
              {text}
            </Text>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProfilePictureGuidelines;
