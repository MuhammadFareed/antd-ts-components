import React, { FC } from "react";
import Text from "src/components/text";

const DemoVideoGuidelines: FC = () => {
  return (
    <div>
      <Text className="mb-20">
        Please make sure to follow these guidelines for the Demo Video to ensure a smooth approval process:
      </Text>
      <Text className="mb-10" font="LIGHTER" size="S">
        To read the Guidelines, please click on the button below to view a PDF
      </Text>
    </div>
  );
};

export default DemoVideoGuidelines;
