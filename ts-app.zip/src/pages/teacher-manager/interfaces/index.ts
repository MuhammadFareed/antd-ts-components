export interface ITeacherManager {
  type?: string;
}
