export { default as TeacherCard } from "./teacherCard";
