import React, { useMemo } from "react";

import { Col, Row, Pagination, Space } from "antd";
import TeacherCard from "../teacherCard";
import TextInput from "src/components/input";
import SelectInput from "src/components/select-input";
import Text from "src/components/text";
import { theme } from "src/constant/theme";
import { DefaultPagination } from "@type/index";
import { RootState } from "@store/reducers";
import { useSelector } from "react-redux";
import { TeacherManager } from "@type/teacher-manager";
import search from "src/assets/svgs/search";
import noData from "src/assets/svgs/noData.svg";
import Loader from "src/components/loader";

import styles from "../../styles.module.css";

interface ITeacherTab {
  teacher?: DefaultPagination<TeacherManager[]>;
  isLoading: boolean;
  handleChangeText: React.Dispatch<React.SetStateAction<string>>;
  handleChangeSelect: React.Dispatch<React.SetStateAction<string>>;
  handlePaginate: (page: number, pageSize: number) => void;
}

const TeacherTab = ({ teacher, isLoading, handleChangeText, handleChangeSelect, handlePaginate }: ITeacherTab) => {
  const { subjects } = useSelector((state: RootState) => state.persistedGeneral);

  const getSubjectOptions = useMemo(() => {
    if (subjects && subjects.express && subjects.express.length) {
      return subjects.express.map(i => ({
        ...i,
        value: i.label,
      }));
    }

    return [];
  }, [subjects]);

  return (
    <div>
      <Row className={styles.searchInput} gutter={[20, 10]}>
        <Col>
          <TextInput
            onChange={handleChangeText}
            className={styles.textInput}
            suffix={search}
            allowClear
            placeholder={"Search by Name"}
          />
        </Col>

        <Col>
          <SelectInput
            showArrow
            allowClear
            placeholder={"Search by Subject"}
            popupClassName={styles.selectColor}
            dropdownStyle={{ color: theme.GREY }}
            onChange={handleChangeSelect}
            customStyles={{ width: "17rem", color: theme.GREY }}
            options={getSubjectOptions}
          />
        </Col>
      </Row>

      {teacher && teacher.data && teacher.data.length ? (
        <TeacherCard data={teacher?.data || []} />
      ) : isLoading ? (
        <Row justify={"center"} className="mt-50">
          <Loader text={"Loading..."} />
        </Row>
      ) : (
        <div className={["mt-50", styles.noData].join(" ")}>
          <Space size={"middle"} direction={"vertical"}>
            <img src={noData} />

            <Text title={"No Data Found"} font={"SEMIBOLD"} size={"M"} color={"HEADING"} />
            <Text title={"Try adjusting your filter"} font={"NORMAL"} size={"S"} customStyles={{ color: "#535353" }} />
          </Space>
        </div>
      )}

      <Row justify={"center"} className={"mt-20"}>
        <Pagination
          className="d-row justify-center mt-20 mb-60 pagination-card"
          total={teacher?.total}
          current={teacher?.current_page}
          hideOnSinglePage
          pageSize={teacher?.per_page || 0}
          onChange={handlePaginate}
        />
      </Row>
    </div>
  );
};

export default TeacherTab;
