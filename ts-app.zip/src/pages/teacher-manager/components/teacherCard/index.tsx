import React from "react";
import { Row, Col } from "antd";
import { Link } from "react-router-dom";
import { uniqueId } from "lodash";

import Text from "src/components/text";
import Badge from "src/components/badge";
import { TeacherManager } from "@type/teacher-manager";

import edu from "src/assets/svgs/edu";
import location from "src/assets/svgs/location";
import noPackageCoverImage from "src/assets/images/no_cover.png";

import styles from "../../styles.module.css";

interface ITeacherCard {
  data: TeacherManager[];
}

const Card: React.FC<{ item: TeacherManager }> = ({ item }) => (
  <Link to={`/teacher-manager/${item.id}`}>
    <div key={item.id} className={styles.container}>
      <div className={styles.package_cover}>
        <img alt="cover" className={styles.package_cover_img} src={item.picture || noPackageCoverImage} />
        {item.teacher.isSuper > 0 && (
          <div className={styles.badge}>
            <Badge type="super_teacher" />
          </div>
        )}
      </div>
      <div className={styles.cardBody}>
        <Text title={item.name} size="M" color="BLACK" font="SEMIBOLD" />
        <div className={styles.edu}>
          <div className={`pr-5 ${styles.iconStyle}`}>{edu}</div>
          <Text title={item.teacher?.subjects?.join(", ")} size="S" color="GREY" />
        </div>
        <div className={styles.edu}>
          <div className={`pr-5 ${styles.iconStyle}`}>{location}</div>
          <Text size="S" color="GREY">
            {`${item.teacher?.city}, ${item.teacher?.country}`}
          </Text>
        </div>
      </div>
    </div>
  </Link>
);

const TeacherCard: React.FC<ITeacherCard> = ({ data = [] }) => (
  <Row className="mt-10">
    {data.map((item: TeacherManager) => (
      <Col key={uniqueId()} xxl={6} xl={8} lg={12} md={24} sm={24} xs={24}>
        <Card item={item} />
      </Col>
    ))}
  </Row>
);

export default TeacherCard;
