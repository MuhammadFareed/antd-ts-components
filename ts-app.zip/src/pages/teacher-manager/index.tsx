import React, { useEffect, useState } from "react";

import { Col, Row } from "antd";
import Text from "src/components/text";
import { Tabs } from "antd";
import TeacherTab from "./components/tab";
import { TeacherTier } from "@type/teacher-manager";
import type { TabsProps } from "antd";
import Header from "src/components/header";
import { debounce } from "lodash";
import { RootState } from "@store/reducers";
import { useSelector, useDispatch } from "react-redux";
import { bindActionCreators } from "redux";

import * as actions from "src/store/actions";

interface Params {
  name?: string;
  subject?: string;
}

const options = {
  page: "1",
  limit: 12,
};

const TeacherManager: React.FC = () => {
  const dispatch = useDispatch();
  const [tier, setTier] = useState<TeacherTier>("1");
  const [text, setText] = useState<string>("");
  const [subject, setSubject] = useState<string>("");
  const { teacherTier1, teacherTier2, teacherTier1Loading, teacherTier2Loading } = useSelector(
    (state: RootState) => state.teacherManager,
  );
  const action = bindActionCreators(actions, dispatch);

  useEffect(() => {
    getTeacherManagers();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const obj: Params = {};

    if (text) {
      obj.name = text;
    }

    if (subject) {
      obj.subject = subject;
    }

    const debouncing = debounce(() => {
      if (text || subject) {
        getTeacherWithFilters(obj);
      } else {
        getTeacherWithFilters();
      }
    }, 1000);

    debouncing();

    return () => {
      debouncing.cancel();
    };

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, subject]);

  const getTeacherWithFilters = (params?: object) => {
    action.getTeacherManager(tier, {
      ...options,
      ...params,
    });
  };

  const getTeacherManagers = () => {
    action.getTeacherManager("1", options);
    action.getTeacherManager("2", options);
  };

  const handlePagination = (page: number, pageSize: number) => {
    const obj: Params = {};

    if (text) {
      obj.name = text;
    }

    if (subject) {
      obj.subject = subject;
    }
    action.getTeacherManager(tier, {
      ...obj,
      limit: pageSize,
      page,
    });
  };

  const items: TabsProps["items"] = [
    {
      key: "1",
      label: "Tier 1",
      children: (
        <TeacherTab
          teacher={teacherTier1}
          handleChangeText={setText}
          handleChangeSelect={setSubject}
          isLoading={teacherTier1Loading}
          handlePaginate={handlePagination}
        />
      ),
    },
    {
      key: "2",
      label: "Tier 2",
      children: (
        <TeacherTab
          teacher={teacherTier2}
          handleChangeText={setText}
          handleChangeSelect={setSubject}
          isLoading={teacherTier2Loading}
          handlePaginate={handlePagination}
        />
      ),
    },
  ];

  const handleChangeTab = (e: string) => {
    const tierTab = e as TeacherTier;
    setTier(tierTab);
  };

  return (
    <div>
      <Header />

      <div className="container py-35">
        <Col>
          <Row className={"pt-20 pb-20"}>
            <Text title={"Teacher Manager"} font={"SEMIBOLD"} size={"XL"} color={"HEADING"} />
          </Row>

          <Tabs defaultActiveKey={"1"} items={items} onChange={handleChangeTab} />
        </Col>
      </div>
    </div>
  );
};

export default TeacherManager;
