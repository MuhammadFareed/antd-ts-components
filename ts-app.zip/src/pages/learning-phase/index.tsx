/* eslint-disable react-hooks/exhaustive-deps */
import React, { FC, Fragment, memo, useEffect, useState } from "react";
import styles from "./styles.module.css";
import LearningLayout from "src/components/learning-layout";
import YellowMessageBanner from "src/components/message-banner";
import Button from "src/components/button";
import { Col, Form, Row } from "antd";
import LearningCard from "src/components/learning-card";
import { RootState } from "@store/reducers";
import { useSelector } from "react-redux";
import { useLocation, useParams } from "react-router-dom";
import Text from "src/components/text";
import { capitilizeBreadcrumb } from "src/utils";
import { TrainingModule, TrainingModuleItem, TrainingPhase } from "@type/index";

const LearningPhase: FC = () => {
  const { pathname } = useLocation();
  const splittedPathname = pathname?.split("/").slice(1);
  const { phaseId, moduleId } = useParams();
  const [showSuccessMessage] = useState<boolean>(false);
  const { trainingPhases } = useSelector((state: RootState) => state?.learning?.learningResouces);
  const [moduleItems, setModuleItems] = useState<TrainingModuleItem[]>([]);

  useEffect(() => {
    for (let i = 0; i < trainingPhases?.length; i++) {
      const phase: TrainingPhase = trainingPhases[i];
      const formattedPhaseId = Number(phaseId?.replace("phase", ""));
      if (phase?.id === formattedPhaseId) {
        for (let j = 0; j < phase?.modules?.length; j++) {
          const module: TrainingModule = phase?.modules[j];
          const formattedModuleId = Number(moduleId?.replace("module", ""));
          if (module?.index === formattedModuleId) {
            setModuleItems(module?.items);
            break;
          }
        }
      }
    }
  }, [phaseId, moduleId]);

  return (
    <LearningLayout>
      {showSuccessMessage && (
        <YellowMessageBanner
          bannerClassName={styles.banner}
          heading={"Great Job on finishing Phase 1 of your Teacher Training"}
          subHeading={"Our Team will be reaching out to you to schedule a Readiness Call before Phase 2"}
          extraContent={
            <Button className="mt-10" type="tertiary">
              Select Time Slot
            </Button>
          }
        />
      )}
      <Fragment>
        {splittedPathname && splittedPathname?.length && (
          <div className={styles.breadcrumb}>
            <Text className={styles.breadcrumb_text}>Learning</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>{capitilizeBreadcrumb(phaseId || "")}</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>{capitilizeBreadcrumb(moduleId || "")}</Text>
          </div>
        )}
      </Fragment>
      <Form>
        <Row gutter={[20, 20]}>
          {moduleItems?.length !== 0 &&
            moduleItems.map((item: TrainingModuleItem) => (
              <Col key={item?.id} xxl={6} xl={8} lg={12} md={12} sm={24} xs={24}>
                <LearningCard item={item} />
              </Col>
            ))}
        </Row>
      </Form>
    </LearningLayout>
  );
};

export default memo(LearningPhase);
