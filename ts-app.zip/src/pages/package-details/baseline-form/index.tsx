/* eslint-disable indent */
import React, { FC } from "react";
import TextInput from "src/components/input";
import SelectInput from "src/components/select-input";
import { Col, Form, Row } from "antd";
import Text from "src/components/text";
import {
  academicGoals,
  behaviouralGoals,
  boards,
  classTimes,
  gradeLevels,
  studentPersonalities,
  teachingStyles,
  testPatterns,
  whyJoinedOptions,
} from "src/constant";
import CheckboxGroupButton from "src/components/checkbox-group-button";
import { BaselineFormData, PersistedGeneralState } from "@type/index";
import { useSelector } from "react-redux";
import { RootState } from "@store/reducers";

type Props = {
  values: BaselineFormData;
  updateValues: (key: string, value: string) => void;
  errorInitialized: boolean;
  edit: boolean;
};

const BaselineForm: FC<Props> = props => {
  const { values, updateValues, errorInitialized } = props;
  const { subjects }: PersistedGeneralState = useSelector((state: RootState) => state.persistedGeneral);

  return (
    <div>
      <Form>
        <Row gutter={[20, 20]}>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mb-10" size="S" font="SEMIBOLD">
              Teacher Partner Name<span className="red">*</span>
            </Text>
            <TextInput
              disabled
              value={values?.teacherName}
              placeholder={"Enter full name"}
              error={errorInitialized && !values?.teacherName ? "Teacher name is required" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mb-10" size="S" font="SEMIBOLD">
              Student Name<span className="red">*</span>
            </Text>
            <TextInput
              disabled
              value={values?.studentName}
              placeholder={"Enter student name"}
              error={errorInitialized && !values?.studentName ? "Student name is required" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mb-10" size="S" font="SEMIBOLD">
              Student Board<span className="red">*</span>
            </Text>
            <SelectInput
              allowClear
              options={boards}
              placeholder={"Select your student’s board"}
              value={values?.board || undefined}
              onChange={value => updateValues("board", value)}
              error={errorInitialized && !values?.board ? "Please select your student’s board" : ""}
            />
          </Col>
          {values?.board === "Other" && (
            <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
              <Text className="mb-10" size="S" font="SEMIBOLD">
                Specify student’s board<span className="red">*</span>
              </Text>
              <TextInput
                allowClear
                value={values?.otherBoard}
                onChange={value => updateValues("otherBoard", value)}
                placeholder={"Enter board name"}
                error={errorInitialized && !values?.otherBoard ? "Please enter board name" : ""}
              />
            </Col>
          )}
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mb-10" size="S" font="SEMIBOLD">
              Student Personality<span className="red">*</span>
            </Text>
            <SelectInput
              allowClear
              options={studentPersonalities}
              placeholder="Select your student’s personality"
              value={values?.personality || undefined}
              onChange={value => updateValues("personality", value)}
              error={errorInitialized && !values?.personality ? "Please select your student’s personality" : ""}
            />
          </Col>
        </Row>
        <Row gutter={[20, 20]} className="mt-20">
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <div className="d-row">
              <Text className="mb-10" size="S" font="SEMIBOLD">
                Student Interest<span className="red">*</span>
              </Text>
              <Text font="LIGHTEST" size="XS" color="GREY03" className="ml-6">
                (Max: 300 words)
              </Text>
            </div>
            <TextInput
              rows={5}
              multiline
              allowClear
              value={values?.interest}
              onChange={value => updateValues("interest", value)}
              placeholder="Enter student’s academic interests and extra-curricular"
              error={
                errorInitialized && !values?.interest
                  ? "Please enter student’s interest"
                  : errorInitialized && values?.interest?.split(" ")?.length > 300
                  ? "300 words limit exceeded"
                  : ""
              }
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <div className="d-row">
              <Text className="mb-10" size="S" font="SEMIBOLD">
                Curriculum Focus Areas and Milestones<span className="red">*</span>
              </Text>
              <Text font="LIGHTEST" size="XS" color="GREY03" className="ml-6">
                (Max: 250 words)
              </Text>
            </div>
            <TextInput
              rows={5}
              multiline
              allowClear
              value={values?.milestones}
              onChange={value => updateValues("milestones", value)}
              placeholder="Note: A detailed breakdown of topics and focus areas the parent wants you to cover goes here. Please do not be vague or brief here."
              error={
                errorInitialized && !values?.milestones
                  ? "Please enter the curriculum focus areas and milestones"
                  : values?.milestones?.split(" ")?.length > 250
                  ? "250 words limit exceeded"
                  : ""
              }
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mb-10" size="S" font="SEMIBOLD">
              Area of Interests
            </Text>
            <SelectInput
              allowClear
              value={Number(values?.areaOfInterest) || undefined}
              options={subjects?.short_courses || []}
              placeholder="Select your student’s area of interests"
              onChange={value => updateValues("areaOfInterest", value)}
              error={
                errorInitialized && !values?.areaOfInterest ? "Please select your student’s area of interests" : ""
              }
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24} />
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mt-20 mb-10" size="S" font="SEMIBOLD">
              Why have you joined Dot and Line?<span className="red">*</span>
            </Text>
            <CheckboxGroupButton
              direction="vertical"
              options={whyJoinedOptions}
              value={values?.haveJoined}
              onChange={(value: any) => updateValues("haveJoined", value)}
              error={errorInitialized && !values?.haveJoined?.length ? "Select at least one option" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mt-20 mb-10" size="S" font="SEMIBOLD">
              Behavioural Goals (You can select one or more)<span className="red">*</span>
            </Text>
            <CheckboxGroupButton
              direction="vertical"
              options={behaviouralGoals}
              value={values?.behaviouralGoals}
              onChange={(value: any) => updateValues("behaviouralGoals", value)}
              error={errorInitialized && !values?.behaviouralGoals?.length ? "Select at least one option" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mt-20 mb-10" size="S" font="SEMIBOLD">
              Grade/Proficiency Level in School
            </Text>
            <SelectInput
              allowClear
              options={gradeLevels}
              value={values?.grade || undefined}
              onChange={value => updateValues("grade", value)}
              placeholder="Select your student’s Grade/Proficiency Level in School"
              error={errorInitialized && !values?.grade ? "Please select grade/proficiency level" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mt-20 mb-10" size="S" font="SEMIBOLD">
              Exam/Tests pattern in the student’s school<span className="red">*</span>
            </Text>
            <SelectInput
              allowClear
              options={testPatterns}
              value={values?.examPattern || undefined}
              placeholder="Select your student’s test pattern"
              onChange={value => updateValues("examPattern", value)}
              error={errorInitialized && !values?.examPattern ? "Please select exam/tests pattern" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mb-10" size="S" font="SEMIBOLD">
              Class Time<span className="red">*</span>
            </Text>
            <SelectInput
              allowClear
              options={classTimes}
              value={values?.classTime || undefined}
              placeholder="Select your class time"
              onChange={value => updateValues("classTime", value)}
              error={errorInitialized && !values?.classTime ? "Please select class time" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mb-10" size="S" font="SEMIBOLD">
              Preferred Teaching Style<span className="red">*</span>
            </Text>
            <SelectInput
              allowClear
              options={teachingStyles}
              value={values?.teachingStyle || undefined}
              onChange={value => updateValues("teachingStyle", value)}
              placeholder="Select your student’s preferred teaching style"
              error={
                errorInitialized && !values?.teachingStyle
                  ? "Please select preferred teaching style for your student"
                  : ""
              }
            />
          </Col>
          <Col xxl={12} xl={12} lg={24} md={24} sm={24} xs={24}>
            <Text className="mt-10 mb-10" size="S" font="SEMIBOLD">
              Academic Goals (You can select one or more)<span className="red">*</span>
            </Text>
            <CheckboxGroupButton
              direction="vertical"
              options={academicGoals}
              value={values?.academicGoal}
              onChange={(value: any) => updateValues("academicGoal", value)}
              error={errorInitialized && !values?.academicGoal?.length ? "Select at least one option" : ""}
            />
          </Col>
        </Row>
      </Form>
    </div>
  );
};

export default BaselineForm;
