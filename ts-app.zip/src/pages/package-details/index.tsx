/* eslint-disable react-hooks/exhaustive-deps */
import React, { Fragment, useCallback, useEffect, useState } from "react";
import Header from "src/components/header";
import styles from "./styles.module.css";
import { Col, Divider, Row, Space, message } from "antd";
import Text from "src/components/text";
import lock from "src/assets/svgs/green_lock.svg";
import student_icon from "src/assets/svgs/red_grade.svg";
import grade_icon from "src/assets/svgs/red_grade2.svg";
import subject_icon from "src/assets/svgs/red_subject.svg";
import Button from "src/components/button";
import StudentInfoCard from "./student-info-card";
import { useNavigate, useParams } from "react-router-dom";
import { AttendenceData, Enrollment, EnrollPackage } from "@type/index";
import Loader from "src/components/loader";
import { packageServices } from "src/services";
import Tag from "src/components/tag";
import { convertToLocalDate, getGrades, getPackageAmount, openLinkInNewTab } from "src/utils";
import { MEDIA_BASE_URL } from "src/config/api-constants";
import moment from "moment-timezone";
import { dateFormat } from "src/constant";
import Modal from "src/components/modal";
import StudentAttendenceCard from "./student-attendence-card";

const PackageDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showAttendenceModal, setShowAttendenceModal] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  // We can not edit package (which were created through old dashboard) created before 14 july 2023.
  const [editable, setEditable] = useState<boolean>(false);
  const [packageDetails, setPackageDetails] = useState<EnrollPackage | null>(null);
  const [attendenceData, setAttendenceData] = useState<AttendenceData[]>([]);

  const getEnrollments = useCallback(async () => {
    try {
      const { package: tempPackage, enrollments } = await packageServices.fetchEnrollments(id);
      setEnrollments(enrollments);
      setPackageDetails(tempPackage);
      const localDate = convertToLocalDate(tempPackage?.created_at);
      if (localDate) {
        const after13July = moment("2023-07-13", dateFormat).isBefore(moment(localDate, dateFormat));
        setEditable(after13July);
      }
      setLoading(false);

      const tempAttendence: AttendenceData[] = [];
      if (enrollments && enrollments?.length) {
        enrollments?.forEach(el => {
          if (el?.student_type === "student") {
            console.log("el?.student_id", el?.student_id);
            tempAttendence.push({
              studentId: el?.student_id,
              status: "absent",
            });
          }
        });
      }
      setAttendenceData(tempAttendence);
    } catch (err) {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    getEnrollments();
  }, []);

  const updateAttendenceData = (id: number, status: "present" | "absent") => {
    const updatedAttendence = attendenceData.map(el => {
      return Number(el?.studentId) === Number(id) ? { ...el, status } : el;
    });
    setAttendenceData(updatedAttendence);
  };

  return (
    <div>
      <Header />
      {loading ? (
        <Loader fullPage />
      ) : (
        <div className="container py-35">
          <Modal
            showFooter
            destroyOnClose
            maskClosable={false}
            okButtonText={"Save"}
            title={"Mark Atttendance"}
            open={showAttendenceModal}
            onCancel={() => setShowAttendenceModal(false)}>
            {enrollments?.map(enrollment => {
              if (enrollment.student_type == "student") {
                return (
                  <StudentAttendenceCard
                    key={enrollment?.id}
                    student={enrollment?.student}
                    updateAttendenceData={updateAttendenceData}
                  />
                );
              }
              return null;
            })}
          </Modal>
          {packageDetails && (
            <Fragment>
              <Row gutter={[0, 10]}>
                <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={24}>
                  <Space>
                    <Tag color="grey" title={packageDetails?.package_mode === "online" ? "Online" : "Onsite"} />
                    <Tag color="pink" title={packageDetails?.program?.name} />
                    <Tag
                      color="sky"
                      title={packageDetails?.access_mode}
                      prefix={packageDetails?.access_mode === "private" ? <img src={lock} alt="" /> : null}
                    />
                  </Space>
                </Col>
                <Col className="justify-end" xxl={12} xl={12} lg={12} md={12} sm={12} xs={24}>
                  <Space direction="vertical">
                    <Space size={"middle"}>
                      <Button
                        style={{ width: 130 }}
                        onClick={() => {
                          if (editable) {
                            navigate(`/packages/edit/${id}`);
                          } else {
                            message.error(
                              "This package was created through old teacher dashboard. You can not edit it.",
                            );
                          }
                        }}>
                        Edit
                      </Button>
                      {enrollments[0]?.package?.active_enrollments_count ? (
                        <Button onClick={() => setShowAttendenceModal(true)} type="secondary">
                          Mark Attendace
                        </Button>
                      ) : null}
                      {enrollments[0]?.package?.active_enrollments_count ? (
                        <Button onClick={() => openLinkInNewTab(enrollments[0]?.slot?.zoom_link)} type="tertiary">
                          Start Class
                        </Button>
                      ) : null}
                    </Space>
                  </Space>
                </Col>
              </Row>
              <Text font="BOLD" size="XXL" className="my-20">
                {packageDetails?.title || ""}
              </Text>
              <div className="justify-between flex-wrap">
                <Space size={"large"} className="flex-wrap mr-20 mb-24">
                  <Text font="SEMIBOLD">{getPackageAmount(packageDetails, "PKR")}</Text>
                  <Text font="SEMIBOLD">{getPackageAmount(packageDetails, "USD")}</Text>
                  <Space className={styles.grade}>
                    <img src={student_icon} alt="" />
                    <p className={styles.grade_text}>
                      {`${enrollments[0]?.package?.active_enrollments_count || 0} ${
                        enrollments[0]?.package?.active_enrollments_count > 1 ? "Students" : "Student"
                      }`}
                    </p>
                  </Space>
                  {packageDetails && packageDetails?.grades?.length !== 0 && (
                    <Space className={styles.grade}>
                      <img src={grade_icon} alt="" />
                      <p className={styles.grade_text}>{`Grade ${getGrades(packageDetails)}`}</p>
                    </Space>
                  )}
                  {packageDetails?.subjects && packageDetails?.subjects?.length !== 0 && (
                    <Space className={styles.grade}>
                      <img src={subject_icon} alt="" />
                      <p className={styles.grade_text}>{packageDetails?.subjects?.map(e => e.subject)?.join(", ")}</p>
                    </Space>
                  )}
                </Space>
                <div className="justify-end">
                  <Button
                    onClick={() => {
                      if (packageDetails?.course_outline_pdf) {
                        openLinkInNewTab(`${MEDIA_BASE_URL}${packageDetails.course_outline_pdf}`);
                      } else {
                        message.error("PDF link not found!");
                      }
                    }}
                    type="secondary">
                    View Course Outline PDF
                  </Button>
                </div>
              </div>
            </Fragment>
          )}
          <Divider />
          {enrollments && enrollments?.length === 0 ? (
            <p className={styles.grade_text}>No Enrollment!</p>
          ) : (
            <Fragment>
              <div className="justify-between">
                <Space size={"small"}>
                  <Text font="SEMIBOLD" size="M">
                    Enrolled students
                  </Text>
                  <Text>({enrollments?.length})</Text>
                </Space>
                <Button type="tertiary" onClick={() => navigate("/demos")}>
                  Enroll Student
                </Button>
              </div>
              <Row gutter={[15, 15]} className="mt-15">
                {enrollments.map((enrollment: Enrollment) => (
                  <Col key={enrollment?.id} xxl={6} xl={8} lg={12} md={24} sm={24} xs={24}>
                    <StudentInfoCard enrollment={enrollment} getEnrollments={getEnrollments} />
                  </Col>
                ))}
              </Row>
            </Fragment>
          )}
        </div>
      )}
    </div>
  );
};

export default PackageDetails;
