/* eslint-disable max-len */
import { Space } from "antd";
import React, { FC, useState } from "react";
import Text from "src/components/text";
import Switch from "src/components/switch";
import styles from "./../styles.module.css";
import { EnrollmentStudent } from "@type/index";
import { getStudentImage } from "src/utils";

type Props = {
  student: EnrollmentStudent;
  updateAttendenceData: (id: number, status: "present" | "absent") => void;
};

const StudentAttendenceCard: FC<Props> = props => {
  const { student, updateAttendenceData } = props;
  const [checked, setChecked] = useState<boolean>(false);

  return (
    <div className="white_box p-6 mb-10">
      <div className="justify-between align-center">
        <Space size={"middle"}>
          <img
            className={styles.student_attendence_card}
            src={getStudentImage(student?.avatar, student?.image)}
            alt=""
          />
          <Text size="S">{student?.name || ""}</Text>
        </Space>
        <Space direction="vertical">
          <Switch
            checked={checked}
            onChange={(value: boolean) => {
              setChecked(value);
              updateAttendenceData(student?.id, value ? "present" : "absent");
            }}
          />
          <Text color={checked ? "DARK_GREEN" : "GREY"} size="XS">
            {checked ? "PRESENT" : "ABSENT"}
          </Text>
        </Space>
      </div>
    </div>
  );
};

export default StudentAttendenceCard;
