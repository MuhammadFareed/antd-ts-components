import React, { FC } from "react";
import Text from "src/components/text";
import SelectInput from "src/components/select-input";
import { UpdateEnrollStatusForm } from "@type/index";
import { dateFormat, enrollStatusOptions } from "src/constant";
import DatePicker from "src/components/date-picker";
import dayjs from "dayjs";
import type { Dayjs } from "dayjs";
import TextInput from "src/components/input";
import { Col, Row } from "antd";
import moment from "moment-timezone";

type Props = {
  values: UpdateEnrollStatusForm;
  updateValues: (key: string, value: string) => void;
  errorInitialized: boolean;
  genDate?: Date;
};

const UpdateEnrollStatus: FC<Props> = props => {
  const { values, updateValues, errorInitialized, genDate } = props;

  const disabledDates = (currentDate: Dayjs, isBreak?: string) => {
    const increaseDays = moment(genDate).add(14, "days").format("YYYY-MM-DD");
    const isOnBreakPeriod =
      isBreak === "breakStart"
        ? dayjs(genDate)?.startOf("day")
        : isBreak === "breakEnd"
        ? dayjs(increaseDays)?.startOf("day")
        : dayjs()?.startOf("day");
    return currentDate?.isBefore(isOnBreakPeriod);
  };

  return (
    <div>
      <div className="mb-20">
        <Text className="mb-10" size="S">
          Status<span className="red">*</span>
        </Text>
        <SelectInput
          allowClear
          options={enrollStatusOptions}
          value={values?.status || undefined}
          onChange={value => updateValues("status", value)}
          placeholder="Select status"
          error={errorInitialized && !values?.status ? "Please select status" : ""}
        />
      </div>
      <div className="mb-20">
        <Text className="mb-10" size="S">
          Date<span className="red">*</span>
        </Text>
        <DatePicker
          placeholder="Enter start date"
          format={dateFormat}
          disabledDate={disabledDates}
          // value={dayjs(values?.date, dateFormat)?.isValid() ? dayjs(values?.date, dateFormat) : null}
          onChange={(_, dateString: string) => updateValues("date", dateString)}
          error={errorInitialized && !values?.date ? "Please select date" : ""}
        />
      </div>
      {values?.status === "break" && (
        <Row gutter={[20, 20]} className="mb-20">
          <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={24}>
            <Text className="mb-10" size="S">
              Start Date<span className="red">*</span>
            </Text>
            <DatePicker
              placeholder="Enter start date"
              format={dateFormat}
              defaultPickerValue={dayjs(genDate)}
              disabledDate={e => disabledDates(e, "breakStart")}
              // value={dayjs(values?.startDate, dateFormat)?.isValid() ? dayjs(values?.startDate, dateFormat) : null}
              onChange={(_, dateString: string) => updateValues("startDate", dateString)}
              error={errorInitialized && !values?.startDate ? "Please select start date" : ""}
            />
          </Col>
          <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={24}>
            <Text className="mb-10" size="S">
              End Date<span className="red">*</span>
            </Text>
            <DatePicker
              placeholder="Enter end date"
              format={dateFormat}
              defaultPickerValue={dayjs(moment(genDate).add(14, "days").format("YYYY-MM-DD"))}
              disabledDate={e => disabledDates(e, "breakEnd")}
              // value={dayjs(values?.endDate, dateFormat)?.isValid() ? dayjs(values?.endDate, dateFormat) : null}
              onChange={(_, dateString: string) => updateValues("endDate", dateString)}
              error={errorInitialized && !values?.endDate ? "Please select end date" : ""}
            />
          </Col>
        </Row>
      )}
      <div className="mb-20">
        <div className="d-row mb-10">
          <Text size="S">
            Reason<span className="red">*</span>
          </Text>
          <Text font="LIGHTEST" size="XS" color="GREY03" className="ml-6">
            (Max: 200 characters)
          </Text>
        </div>
        <TextInput
          multiline
          showCount
          allowClear
          maxLength={200}
          placeholder="Enter reason"
          value={values?.reason}
          onChange={value => updateValues("reason", value)}
          error={errorInitialized && !values?.reason ? "Please enter reason" : ""}
        />
      </div>
    </div>
  );
};

export default UpdateEnrollStatus;
