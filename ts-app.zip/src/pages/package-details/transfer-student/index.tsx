import React, { useEffect, useMemo, useRef, useState } from "react";

import { Form, Col, Row, message } from "antd";
import Header from "src/components/header";
import Text from "src/components/text";
import TextInput from "src/components/input";
import Button from "src/components/button";
import SelectInput from "src/components/select-input";
import { Formik, FormikProps } from "formik";
import { debounce } from "lodash";
import Modal from "src/components/modal";
import { getTeachers, postTransferRequest } from "src/services/package";
import * as Yup from "yup";
import { ITeacher, IEnrolment } from "@type/teacher-manager";
import { getEnrolmentById, getTeacherPackagesById } from "src/store/actions";
import { Package } from "@type/demos";
import { PackageTimeSlot } from "@type/index";
import { capitalizeDays } from "src/utils";
import moment from "moment-timezone";
import circle from "src/assets/svgs/questionCircle.svg";
import tick from "src/assets/svgs/tickgreen.svg";
import { useNavigate, useParams } from "react-router-dom";
import { grades } from "src/constant";
import { Student } from "@type/payments";

const initialValues: IFormikValues = {
  grade: "",
  ref_teacher_id: "",
  teacher_package_id: "",
  slots: "",
  classes: "",
  classes_taken: "",
  classes_pending: "",
  packageTitle: "",
  reason: "",
};

interface IFormikValues {
  grade: string;
  ref_teacher_id: string;
  teacher_package_id: string;
  slots: string;
  classes: string;
  classes_taken: string;
  classes_pending: string;
  packageTitle?: string;
  reason: string;
}

interface ITeachers {
  data: ITeacher[];
}

const transferStudentSchema = Yup.object().shape({
  grade: Yup.string().required("This field is required"),
  ref_teacher_id: Yup.string(),
  teacher_package_id: Yup.string(),
  slots: Yup.string(),
  classes: Yup.number().required("This field is required"),
  classes_taken: Yup.number().required("This field is required"),
  classes_pending: Yup.number().required("This field is required"),
  packageTitle: Yup.string(),
  reason: Yup.string().required("This field is required"),
});

interface ISelectOptions {
  id: number;
  label: string;
  value: number;
  slots?: PackageTimeSlot[];
}

interface IParams {
  enrolmentId: string;
}

const TransferStudent = () => {
  const params = useParams();
  const navigate = useNavigate();
  const [teachers, setTeachers] = useState<ISelectOptions[]>([]);
  const [submitLoading, setSubmitLoading] = useState<boolean>(false);
  const [transferConfirm, setTransferConfirm] = useState<boolean>(false);
  const [teacherSearch, setTeacherSearch] = useState<string>("");
  const [enrolmentId, setEnrolmentId] = useState<string>();
  const [confirmTransferModal, setConfirmTransferModal] = useState<boolean>(false);
  const [teacherPackages, setTeacherPackages] = useState<ISelectOptions[]>([]);
  const [timeSlots, setTimeSlots] = useState<ISelectOptions[]>([]);
  const [teacherSearchLoader, setTeacherSearchLoader] = useState<boolean>(false);
  const [student, setStudent] = useState<Student>();
  const formikRef = useRef<FormikProps<IFormikValues>>(null);

  useEffect(() => {
    if (params) {
      const { enrolmentId } = params as unknown as IParams;
      setEnrolmentId(enrolmentId);

      getEnrolmentById(enrolmentId).then(response => {
        const data = response as IEnrolment;
        if (data && data.data) {
          formikRef.current?.setFieldValue("packageTitle", data.data?.package?.title);
          setStudent(data.data.student);

          const gradeLvl = grades.find(i => i.label === data.data?.student?.level);

          if (gradeLvl) {
            formikRef.current?.setFieldValue("grade", gradeLvl.value);
          }
        }
      });
    }
  }, [params]);

  useEffect(() => {
    const debouncing = debounce(() => {
      if (teacherSearch) {
        getTeacher(teacherSearch);
      } else {
        getTeacher();
      }
    }, 200);

    debouncing();

    return () => {
      debouncing.cancel();
    };
  }, [teacherSearch]);

  const getTeacher = (name?: string) => {
    setTeacherSearchLoader(true);
    getTeachers(name).then(({ data }) => {
      const teacherData = data as ITeachers;

      const arr = teacherData.data.map(item => {
        return {
          id: item.id,
          label: item.name,
          value: item.id,
        };
      });
      setTeacherSearchLoader(false);
      setTeachers(arr);
    });
  };

  const handleSelectTeacher = (id: any) => {
    formikRef.current?.setFieldValue("ref_teacher_id", id);

    getTeacherPackagesById(id).then(data => {
      const packagesData = data as Package[];
      const arr = packagesData.map(item => {
        return {
          id: item.id,
          label: item.title,
          value: item.id,
          slots: item.time_slot,
        };
      });

      setTeacherPackages(arr);
    });
  };

  const handleSelectPackage = (id: any) => {
    formikRef.current?.setFieldValue("teacher_package_id", id);
    formikRef.current?.setFieldValue("slots", "");
    const clonePackages = teacherPackages.find(i => i.id === id);

    if (clonePackages && clonePackages.slots && clonePackages.slots.length) {
      const arr = clonePackages.slots.map(i => {
        const days = capitalizeDays(i.days);
        const startTime = moment(`2022-01-01 ${i.start_time}`).format("hh:mm a");
        const endTime = moment(`2022-01-01 ${i.end_time}`).format("hh:mm a");

        return {
          id: i.id,
          label: `${days} - ${startTime} to ${endTime}`,
          value: i.id,
        };
      });

      setTimeSlots(arr);
    }
  };

  const handleSelectSlot = (id: any) => {
    formikRef.current?.setFieldValue("slots", id);
  };

  const handleSelectGrade = (grade: any) => {
    formikRef.current?.setFieldValue("grade", grade);
  };

  const onSubmitForm = () => {
    setConfirmTransferModal(true);
  };

  const handleConfirmTransfer = () => {
    setSubmitLoading(true);

    const values = formikRef.current?.values as IFormikValues;
    if (values) {
      postTransferRequest({
        ...values,
        student_enroll_id: enrolmentId || "",
      })
        .then(() => {
          setTransferConfirm(true);
          setConfirmTransferModal(false);
          setSubmitLoading(false);
          formikRef.current?.resetForm({
            values: {
              grade: values.grade,
              packageTitle: values.packageTitle,
              classes: "",
              classes_pending: "",
              classes_taken: "",
              reason: "",
              ref_teacher_id: "",
              slots: "",
              teacher_package_id: "",
            },
          });
        })
        .catch(err => {
          setSubmitLoading(false);
          setConfirmTransferModal(false);
          message.error(err.response.data.message);
        });
    }
  };

  const validate = (touched?: boolean, value?: string) => {
    return touched && value;
  };

  const getText = useMemo(() => {
    if (student) {
      // eslint-disable-next-line max-len
      const name = `You have requested to transfer ${student?.name} to another teacher. Do you confirm you want to go ahead with the process?`;
      return name;
    }
  }, [student]);

  const handleTransferConfirm = () => {
    setTransferConfirm(false);

    navigate(-1);
  };

  return (
    <div>
      <Header />

      <Modal
        open={confirmTransferModal}
        onOk={handleConfirmTransfer}
        okButtonLoading={submitLoading}
        onCancel={() => setConfirmTransferModal(false)}
        showCancelButton
        cancelButtonText={"Not now"}
        okButtonText={"Confirm"}
        svg={circle}
        title={"Student Transfer confirmation"}>
        <Row gutter={[10, 0]}>
          <Col span={24}>{getText}</Col>
        </Row>
      </Modal>

      <Modal
        open={transferConfirm}
        onOk={handleTransferConfirm}
        onCancel={handleTransferConfirm}
        showCancelButton={false}
        svg={tick}
        okButtonText={"Great!"}
        title={"Transfer Student"}>
        <Row gutter={[10, 0]}>
          <Col span={24}>
            {`Your request to transfer ${
              student?.name || ""
            } has been sent. You will be notified once the transfer is successful.`}
          </Col>
        </Row>
      </Modal>

      <div className="container py-35">
        <Text title={"Student Transfer"} font={"SEMIBOLD"} size={"XL"} color={"HEADING"} />

        <div className="container">
          <Text title={"To transfer your student, please fill out these fields"} className={"mt-50"} font={"NORMAL"} />

          <Form>
            <Formik
              innerRef={formikRef}
              validationSchema={transferStudentSchema}
              validateOnChange
              validateOnBlur
              initialValues={initialValues}
              onSubmit={onSubmitForm}>
              {({ values, setFieldValue, errors, handleChange, touched, handleBlur, handleSubmit }) => (
                <div className={"mt-30 px-50"}>
                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Grade Level"}
                        <span className="red">* {validate(touched.grade, errors.grade)}</span>
                      </Text>

                      <SelectInput
                        options={grades}
                        placeholder=""
                        allowClear
                        onChange={e => {
                          if (!e) {
                            setFieldValue("grade", "");
                          }
                        }}
                        value={values.grade}
                        onSelect={handleSelectGrade}
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Select Teacher"} <span className="grey">(Optional)</span>
                      </Text>

                      <SelectInput
                        options={teachers}
                        placeholder="Search Teacher"
                        loading={teacherSearchLoader}
                        showSearch
                        allowClear
                        onChange={e => {
                          if (!e) {
                            setFieldValue("ref_teacher_id", "");
                            setFieldValue("teacher_package_id", "");
                            setTeacherPackages([]);
                            setTimeSlots([]);
                          }
                        }}
                        onSearch={setTeacherSearch}
                        value={values.ref_teacher_id}
                        onSelect={handleSelectTeacher}
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Select Package"} <span className="grey">(Optional)</span>
                      </Text>

                      <SelectInput
                        options={teacherPackages}
                        placeholder=""
                        allowClear
                        showSearch
                        onSelect={handleSelectPackage}
                        value={values.teacher_package_id}
                        onChange={e => {
                          if (!e) {
                            setFieldValue("teacher_package_id", "");
                            setFieldValue("slots", "");
                            setTimeSlots([]);
                          }
                        }}
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Time Slot"} <span className="grey">(Optional)</span>
                      </Text>

                      <SelectInput
                        options={timeSlots}
                        placeholder=""
                        allowClear
                        showSearch
                        onSelect={handleSelectSlot}
                        value={values.slots}
                        onChange={e => {
                          if (!e) {
                            setFieldValue("slots", "");
                          }
                        }}
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Total Sessions"}
                        <span className="red">* {validate(touched.classes, errors.classes)}</span>
                      </Text>

                      <TextInput
                        allowClear
                        type={"number"}
                        onChange={e => {
                          if (e && values.classes_taken) {
                            const pending = Number(e) - Number(values.classes_taken);
                            if (pending >= 0) {
                              setFieldValue("classes_pending", pending.toString());
                            } else {
                              setFieldValue("classes_pending", "");
                            }
                          } else {
                            setFieldValue("classes_pending", "");
                          }
                          setFieldValue("classes", e);
                        }}
                        onBlur={handleBlur("classes")}
                        value={values.classes?.toString()}
                        placeholder=""
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Sessions Conducted"}
                        <span className="red">* {validate(touched.classes_taken, errors.classes_taken)}</span>
                      </Text>

                      <TextInput
                        allowClear
                        value={values.classes_taken?.toString()}
                        onChange={e => {
                          if (values.classes && e) {
                            const pending = Number(values.classes) - Number(e);
                            if (pending >= 0) {
                              setFieldValue("classes_pending", pending.toString());
                            } else {
                              setFieldValue("classes_pending", "");
                            }
                          } else {
                            setFieldValue("classes_pending", "");
                          }
                          setFieldValue("classes_taken", e);
                        }}
                        onBlur={handleBlur("classes_taken")}
                        type={"number"}
                        placeholder=""
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Sessions Left"}
                        <span className="red">* {validate(touched.classes_pending, errors.classes_pending)}</span>
                      </Text>

                      <TextInput
                        allowClear
                        value={values.classes_pending?.toString()}
                        onChange={handleChange("classes_pending")}
                        onBlur={handleBlur("classes_pending")}
                        type={"number"}
                        disabled
                        placeholder=""
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Current Package Title"}
                        <span className="red">{validate(touched.packageTitle, errors.packageTitle)}</span>
                      </Text>

                      <TextInput
                        allowClear
                        value={values.packageTitle}
                        onChange={handleChange("packageTitle")}
                        onBlur={handleBlur("packageTitle")}
                        type={"text"}
                        disabled
                        placeholder=""
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Form.Item>
                      <Text font="SEMIBOLD" size="S" className="mb-8">
                        {"Reason for Transfer"}
                        <span className="red">* {validate(touched.reason, errors.reason)}</span>
                      </Text>

                      <TextInput
                        multiline
                        rows={5}
                        value={values.reason}
                        onChange={handleChange("reason")}
                        onBlur={handleBlur("reason")}
                        allowClear
                        type={"text"}
                        placeholder=""
                      />
                    </Form.Item>
                  </Col>

                  <Col xxl={14} xl={16} lg={24} md={24} sm={24} xs={24}>
                    <Button className={"ml-auto mr-auto"} onClick={handleSubmit} type="tertiary">
                      {"Send Request"}
                    </Button>
                  </Col>
                </div>
              )}
            </Formik>
          </Form>
        </div>
      </div>
    </div>
  );
};
export default TransferStudent;
