import React, { FC } from "react";
import styles from "./../styles.module.css";
import logo_transparent from "src/assets/images/logo-transparent.png";
import Text from "src/components/text";
import star from "src/assets/svgs/star.svg";
import maheen_signature from "src/assets/images/maheen_signature.png";
import lina_signature from "src/assets/images/lina_signature.png";
import certificate_completion_icon from "src/assets/svgs/certificate_completion_icon.svg";
import certificate_text from "src/assets/images/certificate_text.png";
import moment from "moment-timezone";
import { capitalize } from "lodash";

type Props = {
  studentName: string;
};

const Certificate: FC<Props> = props => {
  const { studentName } = props;

  return (
    <div className={styles.certificate}>
      <img src={star} alt="" className={styles.c_star1} />
      <img src={star} alt="" className={styles.c_star2} />
      <img src={star} alt="" className={styles.c_star3} />
      <img src={star} alt="" className={styles.c_star4} />
      <img alt="" src={certificate_completion_icon} className={styles.c_img1} />
      <div className={styles.certificate_body}>
        <div className="d-column justify-center align-center">
          <img src={logo_transparent} className={styles.logo} alt="" />
          <img src={certificate_text} alt="" className={styles.certificate_text} />
          <Text size="L" font="LIGHTER" className={styles.yellow_heading}>
            OF COMPLETION
          </Text>
          <Text className="mt-20 mb-30" size="S" font="LIGHTEST" color="WHITE">
            This certificate is awarded to :
          </Text>
          <div className={styles.c_input_container}>
            <div className={styles.c_name_date}>{studentName ? capitalize(studentName) : ""}</div>
          </div>
          <Text className="mt-50 mb-30" size="S" font="LIGHTEST" color="WHITE">
            For successfully completing the <span className={styles.course_name}>The Coding Wizard Level 1</span> course
            on
          </Text>
          <div className={styles.c_input_container}>
            <div className={styles.c_name_date}>{moment()?.format("DD MMM, YYYY")}</div>
          </div>
          <div className={styles.c_space_evenly_row}>
            <div className={styles.w_35}>
              <img alt="" src={maheen_signature} className={styles.signature} />
              <Text className="mt-10 mb-5 text-center" color="WHITE" size="XS" font="LIGHTER">
                MAHEEN B. ADAMJEE
              </Text>
              <Text className="text-center" color="WHITE" size="XXS" font="LIGHTEST">
                Chairman, Dot &amp; Line
              </Text>
            </div>
            <div className={styles.w_35}>
              <img src={lina_signature} alt="" className={styles.signature} />
              <Text className="mt-10 mb-5 text-center" color="WHITE" size="XS" font="LIGHTER">
                Lina Ahmed
              </Text>
              <Text className="text-center" color="WHITE" size="XXS" font="LIGHTEST">
                Chairman, Dot &amp; Line
              </Text>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Certificate;
