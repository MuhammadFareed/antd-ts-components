/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { ChangeEvent, FC } from "react";
import styles from "./../styles.module.css";
import Text from "src/components/text";
import blue_logo from "src/assets/images/blue-logo.png";
import { Col, Row, Space, message } from "antd";
import { ProgressReportForm } from "@type/index";
import { wordCount } from "src/utils";

type Props = {
  level: string;
  errorInitialized: boolean;
  values: ProgressReportForm;
  updateValues: (key: string, value: string) => void;
};

const SecondaryProgressReport: FC<Props> = props => {
  const { updateValues, values, level } = props;

  const changeHandler = (
    e: ChangeEvent<HTMLTextAreaElement> | ChangeEvent<HTMLInputElement>,
    name: string,
    limit?: number,
  ) => {
    if (limit) {
      if (wordCount(e?.target?.value) <= limit) {
        updateValues(name, e?.target?.value);
      } else {
        message.error("Word limit exceeded!");
      }
    } else {
      updateValues(name, e?.target?.value);
    }
  };

  return (
    <div className={styles.secondary_progress_report}>
      <div className={styles.yellow_div}>
        <div className="justify-center">
          <img src={blue_logo} alt="" className={styles.blue_logo} />
        </div>
        <Text className={styles.yellow_box_header}>Progress Report</Text>
      </div>
      <div className={styles.white_div}>
        <Row gutter={[50, 20]}>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <div className={styles.s_input_container}>
              <Text color="DARK_BLUE" font="LIGHTER" className={styles.label_text}>
                Student :
              </Text>
              <input
                disabled
                type="text"
                value={values?.studentName}
                className={styles.s_text_input}
                placeholder="Enter Student Name"
              />
            </div>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <div className={styles.s_input_container}>
              <Text color="DARK_BLUE" font="LIGHTER" className={styles.label_text}>
                Grade Level :
              </Text>
              <input
                disabled={!!level}
                type="text"
                value={values?.grade}
                className={styles.s_text_input}
                placeholder="Enter Grade Level"
                onChange={e => changeHandler(e, "grade")}
              />
            </div>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <div className={styles.s_input_container}>
              <div>
                <Text color="DARK_BLUE" font="LIGHTER" className={styles.label_text}>
                  Teacher Partner :
                </Text>
              </div>
              <input
                disabled
                type="text"
                value={values?.teacherName}
                className={styles.s_text_input}
                placeholder="Enter Teacher Partner"
              />
            </div>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <div className={styles.s_input_container}>
              <Text color="DARK_BLUE" font="LIGHTER" className={styles.label_text}>
                Attendance :
              </Text>
              <div className="d-row">
                <input
                  type="number"
                  placeholder="XX"
                  className={[styles.s_score_input, styles.score_input_left].join(" ")}
                  value={values?.attendence}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    if (String(e?.target?.value)?.length < 3) {
                      updateValues("attendence", e?.target?.value);
                    }
                  }}
                />
                <Text font="LIGHTER" size="S" color="DARK_BLUE" className={"mt-3 mx-4"}>
                  /
                </Text>
                <input
                  type="number"
                  placeholder="XX"
                  className={[styles.s_score_input, styles.score_input_right].join(" ")}
                  value={values?.attendenceTotal}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    if (String(e?.target?.value)?.length < 3) {
                      updateValues("attendenceTotal", e?.target?.value);
                    }
                  }}
                />
              </div>
            </div>
          </Col>
          <Col span={24} className={"mt-10"}>
            <Space size={"middle"} className={styles.comment_box_header}>
              <Text color="WHITE" font="NORMAL" className={styles.sub_heading}>
                MILESTONES ACHIEVED
              </Text>
              <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
                (Word Limit: 300 words)
              </Text>
            </Space>
            <textarea
              rows={4}
              placeholder="Enter comment"
              className={styles.s_text_area}
              value={values?.milestone}
              onChange={e => changeHandler(e, "milestone", 300)}
            />
          </Col>
          <Col span={24}>
            <Space size={"middle"} className={styles.comment_box_header}>
              <Text color="WHITE" font="NORMAL" className={styles.sub_heading}>
                KNOWLEDGE APPLICATION & CONCEPT CLARITY
              </Text>
              <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
                (Word Limit: 300 words)
              </Text>
            </Space>
            <textarea
              rows={4}
              placeholder="Enter comment"
              className={styles.s_text_area}
              value={values?.knowledge}
              onChange={e => changeHandler(e, "knowledge", 300)}
            />
          </Col>
          <Col span={24}>
            <Space size={"middle"} className={styles.comment_box_header}>
              <Text color="WHITE" font="NORMAL" className={styles.sub_heading}>
                TIME MANAGEMENT
              </Text>
              <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
                (Word Limit: 200 words)
              </Text>
            </Space>
            <textarea
              rows={4}
              placeholder="Enter comment"
              className={styles.s_text_area}
              value={values?.timeManagement}
              onChange={e => changeHandler(e, "timeManagement", 200)}
            />
          </Col>
          <Col span={24}>
            <Space size={"middle"} className={styles.comment_box_header}>
              <Text color="WHITE" font="NORMAL" className={styles.sub_heading}>
                CHALLENGES
              </Text>
              <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
                (Word Limit: 300 words)
              </Text>
            </Space>
            <textarea
              rows={4}
              placeholder="Enter comment"
              className={styles.s_text_area}
              value={values?.challenges}
              onChange={e => changeHandler(e, "challenges", 300)}
            />
          </Col>
          <Col span={24}>
            <Space size={"middle"} className={styles.s_comment_box_header}>
              <Text color="DARK_BLUE" font="SEMIBOLD" className={styles.sub_heading}>
                MONTHLY ASSESSMENT
              </Text>
              <Text color="DARK_BLUE" size="S" font="LIGHTER">
                (Word Limit: 100 words)
              </Text>
            </Space>
            <Space className="mt-12">
              <Text color="DARK_BLUE" font="SEMIBOLD">
                Score
              </Text>
              <div className="d-row">
                <input
                  type="number"
                  placeholder="XXX"
                  className={[styles.s_score_input, styles.score_input_left].join(" ")}
                  value={values?.score}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    if (String(e?.target?.value)?.length < 4) {
                      updateValues("score", e?.target?.value);
                    }
                  }}
                />
                <Text font="LIGHTER" size="S" color="DARK_BLUE" className={"mt-3 mx-4"}>
                  /
                </Text>
                <input
                  type="number"
                  placeholder="XXX"
                  className={[styles.s_score_input, styles.score_input_right].join(" ")}
                  value={values?.scoreTotal}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    if (String(e?.target?.value)?.length < 4) {
                      updateValues("scoreTotal", e?.target?.value);
                    }
                  }}
                />
              </div>
            </Space>
            <textarea
              rows={4}
              placeholder="Enter comment"
              className={styles.s_text_area}
              value={values?.monthlyAssessment}
              onChange={e => changeHandler(e, "monthlyAssessment", 100)}
            />
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default SecondaryProgressReport;
