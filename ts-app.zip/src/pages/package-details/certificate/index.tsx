import React, { FC, useEffect, useRef } from "react";
import styles from "./../styles.module.css";
import c_yellow_rect from "src/assets/images/c_yellow_rect.png";
import c_blue_rect from "src/assets/images/c_blue_rect.png";
import c_logo from "src/assets/images/c_white_transparent_logo.png";
import c_rocket_ship from "src/assets/images/c_rocket_ship.png";
import c_stamp from "src/assets/images/c_stamp.png";
import moment from "moment-timezone";
import Text from "src/components/text";
import maheen_signature from "src/assets/images/maheen_signature2.png";
import lina_signature from "src/assets/images/lina_signature2.png";
import star from "src/assets/images/star.png";
import { CertificateValues } from "@type/index";
import { message } from "antd";

type Props = {
  certificateTypes: string[];
  values: CertificateValues;
  errorInitialized: boolean;
  showCertificateConfirmModal: boolean;
  updateValues: (key: string, value: string) => void;
};

const Certificate: FC<Props> = props => {
  const forInputRef = useRef<HTMLInputElement>(null);
  const { certificateTypes, values, errorInitialized, showCertificateConfirmModal, updateValues } = props;

  useEffect(() => {
    if (forInputRef && forInputRef?.current) {
      forInputRef?.current?.focus();
    }
  }, []);

  return (
    <div className={styles.certificate}>
      <img src={star} alt="" className={styles.c_star1} />
      <img src={star} alt="" className={styles.c_star2} />
      <img src={star} alt="" className={styles.c_star3} />
      <img src={star} alt="" className={styles.c_star4} />
      <img src={c_yellow_rect} alt="" className={styles.c_yellow_rect} />
      <img src={c_logo} alt="" className={styles.c_logo} />
      <img src={c_blue_rect} alt="" className={styles.c_blue_rect} />
      <p className={styles.c_date}>{moment()?.format("DD MMM, YYYY")}</p>
      <img src={c_rocket_ship} alt="" className={styles.c_rocket_ship} />
      <img src={c_stamp} alt="" className={styles.c_stamp} />
      <div className="d-column justify-center align-center">
        {values?.certificateType === certificateTypes[0] ? (
          <div>
            <p className={styles.c_heading}>CERTIFICATE</p>
            <p className={styles.c_type}>OF COMPLETION</p>
          </div>
        ) : values?.certificateType === certificateTypes[1] ? (
          <div>
            <p className={styles.c_type2}>EMOTIONAL INTELLIGENCE</p>
            <p className={styles.c_type3}>CERTIFICATE</p>
          </div>
        ) : (
          <div>
            <p className={styles.c_heading}>CERTIFICATE</p>
            <p className={styles.c_type4}>FOR MASTERY OF CONCEPT</p>
          </div>
        )}
        <p className={styles.presented_to}>Presented to:</p>
        {showCertificateConfirmModal ? (
          <p className={styles.c_name}>{values?.studentName}</p>
        ) : (
          <input
            placeholder={"Eg; John Doe"}
            className={styles.c_name}
            value={values?.studentName}
            style={{
              border: errorInitialized && !values?.studentName ? "1px solid red" : "none",
            }}
            onChange={e => {
              if (e?.target?.value?.length <= 25) {
                updateValues("studentName", e?.target?.value);
              } else {
                message.error("Length limit exceeded!");
              }
            }}
          />
        )}

        {values?.certificateType === certificateTypes[2] ? (
          <div>
            <p className={styles.c_for}>For Mastering</p>
            <input
              ref={forInputRef}
              className={styles.hidden_input}
              value={values?.for}
              placeholder="Eg; Art & Crafts"
              onChange={e => updateValues("for", e?.target?.value)}
              style={{
                fontWeight: "700",
                width: "100%",
                fontSize: 18,
                marginBlock: 10,
                border: errorInitialized && !values?.for ? "1px solid red" : "none",
              }}
            />
            <input
              placeholder="Eg; Level 2"
              className={[styles.hidden_input, styles.level_input, styles.c_for].join(" ")}
              value={values?.masterLevel}
              onChange={e => updateValues("masterLevel", e?.target?.value)}
              style={{
                border: errorInitialized && !values?.masterLevel ? "1px solid red" : "none",
              }}
            />
          </div>
        ) : (
          <p className={styles.c_for}>
            For {values?.certificateType === certificateTypes[0] ? "successfully completing the" : ""} <br />
            <input
              ref={forInputRef}
              className={styles.hidden_input}
              value={values?.for}
              onChange={e => updateValues("for", e?.target?.value)}
              style={{
                fontWeight: "600",
                width: "100%",
                maxWidth: 350,
                border: errorInitialized && !values?.for ? "1px solid red" : "none",
              }}
              placeholder={
                values?.certificateType === certificateTypes[0] ? "Eg; Art & Crafts" : "Eg; Being Confident in Class"
              }
            />
          </p>
        )}
      </div>
      <div className={styles.c_space_evenly_row}>
        <div className={styles.w_35}>
          <img alt="" src={lina_signature} className={styles.signature} />
          <Text className="mt-10 mb-5 text-center" size="XS" font="SEMIBOLD">
            Lina Ahmed
          </Text>
          <Text className="text-center" size="XS" font="LIGHTEST">
            Director
            <br />
            Dot &amp; Line
          </Text>
        </div>
        <div className={styles.w_35}>
          <img src={maheen_signature} alt="" className={styles.signature} />
          <Text className="mt-10 mb-5 text-center" size="XS" font="SEMIBOLD">
            Maheen Adamjee
          </Text>
          <Text className="text-center" size="XS" font="LIGHTEST">
            Director
            <br />
            Dot &amp; Line
          </Text>
        </div>
      </div>
    </div>
  );
};

export default Certificate;
