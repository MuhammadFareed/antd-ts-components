import React, { ChangeEvent, FC } from "react";
import Text from "src/components/text";
import styles from "./../styles.module.css";
import logo_transparent from "src/assets/images/logo-transparent.png";
import star_icon from "src/assets/images/star.png";
import success_icon from "src/assets/images/success.png";
import { Col, Row, Space, message } from "antd";
import { ProgressReportForm } from "@type/index";
import { wordCount } from "src/utils";

type Props = {
  level: string;
  errorInitialized: boolean;
  values: ProgressReportForm;
  updateValues: (key: string, value: string) => void;
};

const PrimaryProgressReport: FC<Props> = props => {
  const { values, updateValues, level } = props;

  const changeHandler = (
    e: ChangeEvent<HTMLTextAreaElement> | ChangeEvent<HTMLInputElement>,
    name: string,
    limit?: number,
  ) => {
    if (limit) {
      if (wordCount(e?.target?.value) <= limit) {
        updateValues(name, e?.target?.value);
      } else {
        message.error("Word limit exceeded!");
      }
    } else {
      updateValues(name, e?.target?.value);
    }
  };

  return (
    <div className={styles.primary_progress_report}>
      <img className={[styles.star_icon, styles.star1].join(" ")} src={star_icon} alt="" />
      <img className={[styles.star_icon, styles.star2].join(" ")} src={star_icon} alt="" />
      <img className={[styles.star_icon, styles.star3].join(" ")} src={star_icon} alt="" />
      <img className={[styles.star_icon, styles.star4].join(" ")} src={star_icon} alt="" />
      <img className={[styles.star_icon, styles.star5].join(" ")} src={star_icon} alt="" />
      <img className={styles.success_icon} src={success_icon} alt="" />
      <div className="justify-center">
        <img src={logo_transparent} className={styles.logo} alt="" />
      </div>
      <Text font="SEMIBOLD" color="WHITE" className={styles.heading}>
        Progress Report
      </Text>
      <Row gutter={[50, 20]}>
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
          <div className={styles.input_container}>
            <Text color="WHITE" font="LIGHTER" className={styles.label_text}>
              Student :
            </Text>
            <input
              disabled
              type="text"
              value={values?.studentName}
              className={styles.text_input}
              placeholder="Enter Student Name"
            />
          </div>
        </Col>
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
          <div className={styles.input_container}>
            <Text color="WHITE" font="LIGHTER" className={styles.label_text}>
              Grade Level :
            </Text>
            <input
              disabled={!!level}
              type="text"
              value={values?.grade}
              className={styles.text_input}
              placeholder="Enter Grade Level"
              onChange={e => changeHandler(e, "grade")}
            />
          </div>
        </Col>
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
          <div className={styles.input_container}>
            <div>
              <Text color="WHITE" font="LIGHTER" className={styles.label_text}>
                Teacher Partner :
              </Text>
            </div>
            <input
              disabled
              type="text"
              value={values?.teacherName}
              className={styles.text_input}
              placeholder="Enter Teacher Partner"
            />
          </div>
        </Col>
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
          <div className={styles.input_container}>
            <Text color="WHITE" font="LIGHTER" className={styles.label_text}>
              Attendance :
            </Text>
            <div className="d-row">
              <input
                type="number"
                placeholder="XX"
                className={[styles.white_score_input, styles.score_input_left].join(" ")}
                value={values?.attendence}
                onChange={(e: ChangeEvent<HTMLInputElement>) => {
                  if (String(e?.target?.value)?.length < 3) {
                    updateValues("attendence", e?.target?.value);
                  }
                }}
              />
              <Text font="LIGHTER" size="S" color="WHITE" className={"mt-5 mx-4"}>
                /
              </Text>
              <input
                type="number"
                placeholder="XX"
                className={[styles.white_score_input, styles.score_input_right].join(" ")}
                value={values?.attendenceTotal}
                onChange={(e: ChangeEvent<HTMLInputElement>) => {
                  if (String(e?.target?.value)?.length < 3) {
                    updateValues("attendenceTotal", e?.target?.value);
                  }
                }}
              />
            </div>
          </div>
        </Col>
        <Col span={24} className={"mt-20"}>
          <Space size={"middle"}>
            {/* <QuestionCircleOutlined /> */}
            <Text color="WHITE" font="SEMIBOLD" size="M2" className={styles.sub_heading}>
              STRENGTHS & SUPERSTAR MOMENTS
            </Text>
            <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
              (Word Limit: 250 words)
            </Text>
          </Space>
          <textarea
            rows={4}
            placeholder="Enter comment"
            className={styles.text_area}
            value={values?.strengths}
            onChange={e => changeHandler(e, "strengths", 250)}
          />
        </Col>
        <Col span={24}>
          <Space size={"middle"}>
            {/* <QuestionCircleOutlined /> */}
            <Text color="WHITE" font="SEMIBOLD" size="M2" className={styles.sub_heading}>
              CHALLENGES (WORK IN PROGRESS)
            </Text>
            <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
              (Word Limit: 250 words)
            </Text>
          </Space>
          <textarea
            rows={4}
            placeholder="Enter comment"
            className={styles.text_area}
            value={values?.challenges}
            onChange={e => changeHandler(e, "challenges", 250)}
          />
        </Col>
        <Col span={24}>
          <Space size={"middle"}>
            {/* <QuestionCircleOutlined /> */}
            <Text color="WHITE" font="SEMIBOLD" size="M2" className={styles.sub_heading}>
              BEHAVIORAL BRIEF
            </Text>
            <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
              (Word Limit: 150 words)
            </Text>
          </Space>
          <textarea
            rows={4}
            placeholder="Enter comment"
            className={styles.text_area}
            value={values?.behavioralBrief}
            onChange={e => changeHandler(e, "behavioralBrief", 150)}
          />
        </Col>
        <Col span={24}>
          <div className="justify-between">
            <Space size={"middle"}>
              {/* <QuestionCircleOutlined /> */}
              <Text font="SEMIBOLD" size="M2" className={[styles.sub_heading, styles.yellow_text].join(" ")}>
                MONTHLY ASSESSMENT
              </Text>
              <Text color="LIGHT_ORANGE" size="S" font="LIGHTEST">
                (Word Limit: 100 words)
              </Text>
            </Space>
            <Space>
              <Text size="M" font="LIGHTER" className={styles.yellow_text}>
                Score
              </Text>
              <div className="d-row">
                <input
                  type="number"
                  placeholder="XXX"
                  className={[styles.score_input, styles.score_input_left].join(" ")}
                  value={values?.score}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    if (String(e?.target?.value)?.length < 4) {
                      updateValues("score", e?.target?.value);
                    }
                  }}
                />
                <Text font="LIGHTER" className={[styles.yellow_text, "mt-3 mx-4"].join(" ")}>
                  /
                </Text>
                <input
                  type="number"
                  placeholder="XXX"
                  className={[styles.score_input, styles.score_input_right].join(" ")}
                  value={values?.scoreTotal}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    if (String(e?.target?.value)?.length < 4) {
                      updateValues("scoreTotal", e?.target?.value);
                    }
                  }}
                />
              </div>
            </Space>
          </div>
          <textarea
            rows={4}
            placeholder="Enter comment"
            className={styles.text_area_yellow}
            value={values?.monthlyAssessment}
            onChange={e => changeHandler(e, "monthlyAssessment", 100)}
          />
        </Col>
      </Row>
    </div>
  );
};

export default PrimaryProgressReport;
