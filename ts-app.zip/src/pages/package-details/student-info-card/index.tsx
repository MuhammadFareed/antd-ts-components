/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable react-hooks/exhaustive-deps */
import React, { FC, Fragment, useEffect, useRef, useState } from "react";
import { Space, Tooltip, message } from "antd";
import Text from "src/components/text";
import styles from "./../styles.module.css";
import MenuItems from "src/components/menu-items";
import {
  BaselineFormData,
  CertificateValues,
  Enrollment,
  MenuItemType,
  ProgressReportForm,
  UpdateEnrollStatusForm,
} from "@type/index";
import Modal from "src/components/modal";
import BaselineForm from "../baseline-form";
import PrimaryProgressReport from "../primary-progress-report";
import Certificate from "../certificate";
import grade_icon from "src/assets/svgs/red_grade2.svg";
import Tag from "src/components/tag";
import { dateFormat, enrollStatusColor, enrollStatuses, primaryGrades } from "src/constant";
import { getStudentImage, isProgressReportSubmited } from "src/utils";
import { packageServices } from "src/services";
import no_baseline from "src/assets/svgs/no_baseline.svg";
import no_prog_report from "src/assets/svgs/no_prog_report.svg";
import submitted_baseline from "src/assets/svgs/submitted_baseline.svg";
import submitted_prog_report from "src/assets/svgs/submitted_prog_report.svg";
import green_check from "src/assets/svgs/green_check.svg";
import UpdateEnrollStatus from "../update-enroll-status";
import SecondaryProgressReport from "../secondary-progress-report";
import no_certificate from "src/assets/svgs/no_certificate.svg";
import submitted_certificate from "src/assets/svgs/submitted_certificate.svg";
import moment from "moment-timezone";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { useNavigate } from "react-router-dom";

type Props = {
  enrollment: Enrollment;
  getEnrollments: () => void;
};

const StudentInfoCard: FC<Props> = props => {
  const certificateRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { enrollment, getEnrollments } = props;
  const completion = "completion";
  const behavioural = "behavioural";
  const mastery = "mastery";
  const certificateTypes = [completion, behavioural, mastery];
  const isStudentOrAumni = enrollment?.student_type === "student" || enrollment?.student_type === "alumni";
  const initialBaselineFormValues: BaselineFormData = {
    teacherId: enrollment?.teacher?.id,
    studentId: enrollment?.student?.id,
    teacherName: enrollment?.teacher?.name,
    studentName: enrollment?.student?.name,
    board: "",
    otherBoard: "",
    personality: "",
    interest: "",
    milestones: "",
    areaOfInterest: "",
    haveJoined: [],
    behaviouralGoals: [],
    grade: "",
    examPattern: "",
    classTime: "",
    teachingStyle: "",
    academicGoal: [],
  };
  const initialProgressReportValues: ProgressReportForm = {
    teacherId: enrollment?.teacher?.id,
    studentId: enrollment?.student?.id,
    enrollId: enrollment?.id,
    teacherName: enrollment?.teacher?.name,
    studentName: enrollment?.student?.name,
    grade: enrollment?.student?.level,
    attendence: "",
    attendenceTotal: "",
    strengths: "",
    behavioralBrief: "",
    monthlyAssessment: "",
    score: "",
    scoreTotal: "",
    milestone: "",
    knowledge: "",
    timeManagement: "",
    challenges: "",
  };
  const initialEnrollStatusValues: UpdateEnrollStatusForm = {
    status: "",
    date: "",
    reason: "",
    startDate: "",
    endDate: "",
  };
  const initialCertificateValues: CertificateValues = {
    teacherId: enrollment?.teacher?.id,
    studentId: enrollment?.student?.id,
    enrollId: enrollment?.id,
    date: moment()?.format(dateFormat),
    studentName: enrollment?.student?.name,
    for: enrollment?.package?.title,
    certificateType: "",
    masterLevel: "",
  };
  const isPrimary = primaryGrades?.includes(enrollment?.student?.level);
  const [showBaselineForm, setShowBaselineForm] = useState<boolean>(false);
  const [showReport, setShowReport] = useState<boolean>(false);
  const [showCertificate, setShowCertificate] = useState<boolean>(false);
  const [baselineErrorInitialized, setBaselineErrorInitialized] = useState<boolean>(false);
  const [baselineSubmitting, setBaselineSubmitting] = useState<boolean>(false);
  const baselineExists = enrollment?.base_line_forms?.length !== 0;
  const [progErrorInitialized, setProgErrorInitialized] = useState<boolean>(false);
  const [submittingProgressReport, setSubmittingProgressReport] = useState<boolean>(false);
  const [showStatusModal, setShowStatusModal] = useState<boolean>(false);
  const [statusErrorInitialized, setStatusErrorInitialized] = useState<boolean>(false);
  const [submittingStatus, setSubmittingStatus] = useState<boolean>(false);
  const [progReportSubmitted, setProgReportSubmitted] = useState<boolean>(false);
  const [submittingCertificate, setSubmittingCertificate] = useState<boolean>(false);
  const [certificateSubmitted, setCertificateSubmitted] = useState<boolean>(false);
  const [submittedCertificateType, setSubmittedCertificateType] = useState<string>("");
  const [certificateErrorInitialized, setCertificateErrorInitialized] = useState<boolean>(false);
  const [showCertificateConfirmModal, setShowCertificateConfirmModal] = useState<boolean>(false);
  const [baselineFormValues, setBaselineFormValues] = useState<BaselineFormData>({ ...initialBaselineFormValues });
  const [certificateValues, setCertificateValues] = useState<CertificateValues>({ ...initialCertificateValues });
  const [progressReportValues, setProgressReportValues] = useState<ProgressReportForm>({
    ...initialProgressReportValues,
  });
  const [enrollStatusValues, setEnrollStatusValues] = useState<UpdateEnrollStatusForm>({
    ...initialEnrollStatusValues,
  });

  const menuOptions: MenuItemType[] = [
    {
      id: 1,
      label: baselineExists ? "Edit Baseline Form" : "Add Baseline Form",
      onClick: () => setShowBaselineForm(true),
      suffixIcon: baselineExists ? <img className="ml-12" src={green_check} style={{ width: 19 }} alt="" /> : null,
    },
    {
      id: 2,
      label: "Generate Report",
      // label: progReportSubmitted ? "Report Generated" : "Generate Report",
      onClick: () => setShowReport(true),
      // disabled: progReportSubmitted,
    },
    {
      id: 4,
      label: "Mark Alumni",
      onClick: () => {
        setShowStatusModal(true);
        updateEnrollStatusData("status", "alumni");
      },
    },
    {
      id: 5,
      label: "Mark Potential",
      onClick: () => {
        setShowStatusModal(true);
        updateEnrollStatusData("status", "archive");
      },
    },
    {
      id: 6,
      label: "Mark On Break",
      onClick: () => {
        setShowStatusModal(true);
        updateEnrollStatusData("status", "break");
      },
    },
  ];

  if (window?.innerWidth >= 960 && window?.innerHeight >= 680) {
    menuOptions?.splice(2, 0, {
      id: 3,
      label: "Generate Certificate",
      children: [
        {
          id: 1,
          label: "Course Completion",
          disabled: certificateSubmitted,
          suffixIcon:
            submittedCertificateType === completion ? (
              <img className="ml-12" src={green_check} style={{ width: 19 }} alt="" />
            ) : null,
          onClick: () => {
            updateCertificateData("certificateType", completion);
            setShowCertificate(true);
          },
        },
        {
          id: 2,
          label: "Behavioural Certificates",
          disabled: certificateSubmitted,
          suffixIcon:
            submittedCertificateType === behavioural ? (
              <img className="ml-12" src={green_check} style={{ width: 19 }} alt="" />
            ) : null,
          onClick: () => {
            updateCertificateData("certificateType", behavioural);
            setShowCertificate(true);
          },
        },
        {
          id: 3,
          label: "Mastery of Concept",
          disabled: certificateSubmitted,
          suffixIcon:
            submittedCertificateType === mastery ? (
              <img className="ml-12" src={green_check} style={{ width: 19 }} alt="" />
            ) : null,
          onClick: () => {
            updateCertificateData("certificateType", mastery);
            setShowCertificate(true);
          },
        },
      ],
    });
  }

  if (enrollment.student_type !== "transfer") {
    menuOptions.push({
      id: 7,
      label: "Transfer",
      onClick: () => navigate(`/packages/transfer-student/${enrollment.id}`),
    });
  }

  useEffect(() => {
    if (
      enrollment?.progress_reports &&
      enrollment?.progress_reports?.length !== 0 &&
      isProgressReportSubmited(enrollment?.progress_reports[enrollment?.progress_reports?.length - 1]?.from)
    ) {
      setProgReportSubmitted(true);
    }
  }, []);

  useEffect(() => {
    if (enrollment?.certificates?.length !== 0) {
      for (let i = 0; i < enrollment?.certificates?.length; i++) {
        const certificate = enrollment?.certificates[i];
        const currentMonth = moment()?.month();
        const currentYear = moment()?.year();
        const certificateMonth = moment(certificate?.date, dateFormat)?.month();
        const certificateYear = moment(certificate?.date, dateFormat)?.year();
        if (currentMonth === certificateMonth && currentYear === certificateYear) {
          setCertificateSubmitted(true);
          setSubmittedCertificateType(certificate?.certificate_type);
          break;
        }
      }
    }
  }, []);

  useEffect(() => {
    const { base_line_forms } = enrollment;
    if (base_line_forms?.length !== 0) {
      setBaselineFormValues((prev: BaselineFormData): BaselineFormData => {
        return {
          ...prev,
          board: base_line_forms[0]?.board,
          personality: base_line_forms[0]?.personality,
          interest: base_line_forms[0]?.interest,
          milestones: base_line_forms[0]?.milestones,
          areaOfInterest: base_line_forms[0]?.area_of_interest,
          haveJoined: base_line_forms[0]?.have_joined,
          behaviouralGoals: base_line_forms[0]?.behavioural_goals,
          grade: base_line_forms[0]?.grade,
          examPattern: base_line_forms[0]?.exam_pattern,
          classTime: base_line_forms[0]?.class_time,
          teachingStyle: base_line_forms[0]?.teaching_style,
          academicGoal: base_line_forms[0]?.academic_goal,
        };
      });
    }
  }, [enrollment]);

  const resetEnrollStatusForm = () => {
    setEnrollStatusValues({ ...initialEnrollStatusValues });
  };

  const updateEnrollStatusData = (key: string, value: string) => {
    setEnrollStatusValues(prev => {
      return { ...prev, [key]: value };
    });
  };

  const updateBaselineFormData = (key: string, value: string) => {
    setBaselineFormValues((prev: BaselineFormData) => {
      return { ...prev, [key]: value };
    });
  };

  const updateProgressReportData = (key: string, value: string) => {
    setProgressReportValues((prev: ProgressReportForm) => {
      return { ...prev, [key]: value };
    });
  };

  const updateCertificateData = (key: string, value: string) => {
    setCertificateValues((prev: CertificateValues) => {
      return { ...prev, [key]: value };
    });
  };

  const onSubmitBaselineForm = () => {
    const {
      teacherName,
      studentName,
      board,
      otherBoard,
      personality,
      interest,
      milestones,
      areaOfInterest,
      haveJoined,
      behaviouralGoals,
      grade,
      examPattern,
      classTime,
      teachingStyle,
      academicGoal,
    } = baselineFormValues;
    if (
      teacherName &&
      studentName &&
      ((board && board !== "Other") || (board && board === "Other" && otherBoard)) &&
      personality &&
      interest &&
      interest?.split(" ")?.length <= 300 &&
      milestones &&
      milestones?.split(" ")?.length <= 250 &&
      areaOfInterest &&
      haveJoined?.length &&
      behaviouralGoals?.length &&
      grade &&
      examPattern &&
      classTime &&
      teachingStyle &&
      academicGoal?.length
    ) {
      setBaselineSubmitting(true);
      packageServices
        .createBaselineForm(baselineFormValues)
        .then(() => {
          getEnrollments();
          setBaselineSubmitting(false);
          setShowBaselineForm(false);
          message.success(`Baseline form ${baselineExists ? "updated" : "created"} successfully!`);
        })
        .catch(() => setBaselineSubmitting(false));
    } else {
      setBaselineErrorInitialized(true);
      message.warning("Please fill all required fields.");
    }
  };

  const submitProgReportHandler = (data: ProgressReportForm) => {
    setSubmittingProgressReport(true);
    packageServices
      .sendProgressReport(data, isPrimary)
      .then(() => {
        getEnrollments();
        setProgReportSubmitted(true);
        setSubmittingProgressReport(false);
        setShowReport(false);
        message.success("Progress report has been sent successfully!");
        setProgressReportValues({ ...initialProgressReportValues });
      })
      .catch(() => setSubmittingProgressReport(false));
  };

  const onSubmitProgressReport = () => {
    if (isPrimary) {
      const {
        grade,
        strengths,
        challenges,
        behavioralBrief,
        monthlyAssessment,
        score,
        scoreTotal,
        attendence,
        attendenceTotal,
      } = progressReportValues;
      if (
        grade &&
        strengths &&
        challenges &&
        behavioralBrief &&
        monthlyAssessment &&
        score !== "" &&
        scoreTotal !== "" &&
        attendence !== "" &&
        attendenceTotal !== ""
      ) {
        submitProgReportHandler(progressReportValues);
      } else {
        setProgErrorInitialized(true);
        message.warning("Please fill all fields.");
      }
    } else {
      const {
        grade,
        milestone,
        knowledge,
        timeManagement,
        challenges,
        monthlyAssessment,
        score,
        scoreTotal,
        attendence,
        attendenceTotal,
      } = progressReportValues;
      if (
        grade &&
        milestone &&
        knowledge &&
        timeManagement &&
        challenges &&
        monthlyAssessment &&
        score !== "" &&
        scoreTotal !== "" &&
        attendence !== "" &&
        attendenceTotal !== ""
      ) {
        submitProgReportHandler(progressReportValues);
      } else {
        setProgErrorInitialized(true);
        message.warning("Please fill all fields.");
      }
    }
  };

  const onUpdateEnrollStatus = () => {
    if (enrollStatusValues?.status && enrollStatusValues?.date && enrollStatusValues?.reason) {
      if (
        enrollStatusValues?.status !== "break" ||
        (enrollStatusValues?.status === "break" && enrollStatusValues?.startDate && enrollStatusValues?.endDate)
      ) {
        setSubmittingStatus(true);
        packageServices
          .updateEnrollStatus(enrollStatusValues, enrollment?.id)
          .then(() => {
            getEnrollments();
            setSubmittingStatus(false);
            setShowStatusModal(false);
          })
          .catch(() => setSubmittingStatus(false));
      } else {
        setStatusErrorInitialized(true);
        message.warning("Please fill all required fields.");
      }
    } else {
      setStatusErrorInitialized(true);
      message.warning("Please fill all required fields.");
    }
  };

  const submitCertificateHandler = () => {
    setSubmittingCertificate(true);
    if (certificateRef && certificateRef?.current) {
      html2canvas(certificateRef?.current, { scale: 2 })
        .then(canvas => {
          const imgData = canvas?.toDataURL("image/png", 1);
          const pdf = new jsPDF("l", "px", [520, 310], true);
          pdf?.addImage(imgData, "PNG", 0, 0, 520, 310);
          const pdfBase64 = pdf?.output("blob");
          const certificateFile = new File([pdfBase64], "certificate.pdf", { type: "application/pdf" });
          packageServices
            .sendCertificate(certificateValues, certificateFile)
            .then(() => {
              setSubmittingCertificate(false);
              setCertificateSubmitted(true);
              setSubmittedCertificateType(certificateValues?.certificateType);
              setShowCertificateConfirmModal(false);
              setShowCertificate(false);
              message.success("Certificate has been submitted successfully!");
              setCertificateValues({ ...initialCertificateValues });
            })
            .catch(() => setSubmittingCertificate(false));
        })
        .catch(() => message.error("Error when generating PDF!"));
    }
  };

  const onSubmitCertificate = () => {
    const { studentName, certificateType, masterLevel, for: for2 } = certificateValues;
    if (
      (studentName && for2 && certificateType === "mastery" && masterLevel) ||
      (certificateType !== "mastery" && studentName && for2)
    ) {
      setShowCertificateConfirmModal(true);
    } else {
      setCertificateErrorInitialized(true);
      message.warning("Please fill all required fields.");
    }
  };

  const getTitle = () => {
    if (enrollment && enrollment.progress_reports && enrollment.progress_reports.length) {
      return `Last submitted at ${moment(
        enrollment?.progress_reports[enrollment?.progress_reports?.length - 1]?.created_at,
      ).format("D MMM, Y hh:mm A")}`;
    } else {
      return "Progress Report has not been submitted yet";
    }
  };

  return (
    <div className="white_box p-10 w-100 h-100">
      {enrollment && (
        <Fragment>
          <Modal
            width={1100}
            destroyOnClose
            maskClosable={false}
            title={"Baseline form"}
            open={showBaselineForm}
            okButtonLoading={baselineSubmitting}
            okButtonText={baselineExists ? "Update" : "Submit"}
            onOk={onSubmitBaselineForm}
            onCancel={() => {
              setBaselineErrorInitialized(false);
              setShowBaselineForm(false);
            }}>
            <BaselineForm
              edit={baselineExists}
              values={baselineFormValues}
              updateValues={updateBaselineFormData}
              errorInitialized={baselineErrorInitialized}
            />
          </Modal>
          <Modal
            width={1100}
            destroyOnClose
            closable={false}
            maskClosable={false}
            open={showReport}
            okButtonText="Send Report"
            onOk={onSubmitProgressReport}
            okButtonLoading={submittingProgressReport}
            onCancel={() => {
              setProgErrorInitialized(false);
              setShowReport(false);
            }}>
            <div>
              {isPrimary ? (
                <PrimaryProgressReport
                  values={progressReportValues}
                  updateValues={updateProgressReportData}
                  errorInitialized={progErrorInitialized}
                  level={enrollment?.student?.level}
                />
              ) : (
                <SecondaryProgressReport
                  values={progressReportValues}
                  updateValues={updateProgressReportData}
                  errorInitialized={progErrorInitialized}
                  level={enrollment?.student?.level}
                />
              )}
            </div>
          </Modal>
          <Modal
            width={950}
            destroyOnClose
            okButtonText="Generate"
            closable={false}
            maskClosable={false}
            open={showCertificate}
            onOk={onSubmitCertificate}
            onCancel={() => {
              setShowCertificate(false);
              setCertificateValues({ ...initialCertificateValues });
              setCertificateErrorInitialized(false);
            }}>
            <div ref={certificateRef} style={{ overflow: "auto" }}>
              <Certificate
                certificateTypes={certificateTypes}
                values={certificateValues}
                updateValues={updateCertificateData}
                errorInitialized={certificateErrorInitialized}
                showCertificateConfirmModal={showCertificateConfirmModal}
              />
            </div>
          </Modal>
          <Modal
            destroyOnClose
            title={"Confirmation"}
            okButtonText="Confirm"
            open={showCertificateConfirmModal}
            okButtonLoading={submittingCertificate}
            onOk={submitCertificateHandler}
            onCancel={() => setShowCertificateConfirmModal(false)}>
            <Text className="mb-50" size="S" font="LIGHTER">
              Are you sure you want to generate this certificate?
            </Text>
          </Modal>
          <Modal
            width={800}
            destroyOnClose
            maskClosable={false}
            open={showStatusModal}
            okButtonLoading={submittingStatus}
            title={"Update Enroll Status"}
            okButtonText="Update Status"
            onOk={onUpdateEnrollStatus}
            onCancel={() => {
              setShowStatusModal(false);
              setStatusErrorInitialized(false);
              resetEnrollStatusForm();
            }}>
            <UpdateEnrollStatus
              values={enrollStatusValues}
              genDate={enrollment.gen_date}
              updateValues={updateEnrollStatusData}
              errorInitialized={statusErrorInitialized}
            />
          </Modal>
          <div className="d-row justify-between">
            <Space size={"middle"}>
              <img
                className={styles.student_image}
                src={getStudentImage(enrollment?.student?.avatar, enrollment?.student?.image)}
                alt="DP"
              />
              <div>
                <Text font="SEMIBOLD">{enrollment?.student?.name || ""}</Text>
                <div className={[styles.grade, "d-row mt-6 mb-8"].join(" ")}>
                  <img src={grade_icon} alt="" />
                  <Text className="mt-1 ml-8" font="LIGHTEST" size="S" color="BLACK02">
                    {`${enrollment?.student?.level?.includes("Grade") ? "" : "Grade"} ${
                      enrollment?.student?.level || ""
                    }`}
                  </Text>
                </div>
                <Tag
                  color={enrollStatusColor[enrollment?.student_type]}
                  title={enrollStatuses[enrollment?.student_type]}
                />
              </div>
            </Space>
            {isStudentOrAumni ? (
              <div className="align-start ml-12">
                {baselineExists ? (
                  <Tooltip title="Baseline form has been submitted" placement="bottom">
                    <img src={submitted_baseline} className="mt-7 mr-10" alt="" />
                  </Tooltip>
                ) : (
                  <Tooltip title="Baseline form is not submitted" placement="bottom">
                    <img src={no_baseline} className="mt-7 mr-10" alt="" />
                  </Tooltip>
                )}
                {enrollment?.progress_reports?.length === 0 ? (
                  <Tooltip title={"Progress Report has not been submitted yet"} placement="bottom">
                    <img src={no_prog_report} className="mt-7 mr-10" alt="" />
                  </Tooltip>
                ) : (
                  <Tooltip
                    placement="bottom"
                    title={`Last submitted on ${moment(
                      enrollment?.progress_reports[enrollment?.progress_reports?.length - 1]?.created_at,
                    ).format("D MMM, Y hh:mm A")}`}>
                    <img src={submitted_prog_report} className="mt-7 mr-10" alt="" />
                  </Tooltip>
                )}
                {enrollment?.certificates && enrollment?.certificates?.length !== 0 ? (
                  <Tooltip
                    placement="bottom"
                    title={`Certificate submitted on ${moment(
                      enrollment?.certificates[enrollment?.certificates?.length - 1]?.created_at,
                    ).format("D MMM, Y hh:mm A")}`}>
                    <img src={submitted_certificate} className="mt-7 mr-10" alt="" />
                  </Tooltip>
                ) : (
                  <Tooltip title="Certificate is not submitted" placement="bottom">
                    <img src={no_certificate} className="mt-7 mr-10" alt="" />
                  </Tooltip>
                )}
                <MenuItems options={menuOptions} />
              </div>
            ) : null}
          </div>
        </Fragment>
      )}
    </div>
  );
};

export default StudentInfoCard;
