/* eslint-disable react-hooks/exhaustive-deps */
import React, { FC, useEffect } from "react";
import { useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import LearningLayout from "src/components/learning-layout";
import * as actions from "src/store/actions";

const Learning: FC = () => {
  const dispatch = useDispatch();
  const action = bindActionCreators(actions, dispatch);

  useEffect(() => {
    action.setActiveLearningMenu([]);
  }, []);

  return <LearningLayout />;
};

export default Learning;
