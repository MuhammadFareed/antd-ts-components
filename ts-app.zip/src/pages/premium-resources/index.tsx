/* eslint-disable react-hooks/exhaustive-deps */
import React, { FC, Fragment, useEffect, useState } from "react";
import { Col, Form, Row, Table } from "antd";
import LearningLayout from "src/components/learning-layout";
import { SearchOutlined } from "@ant-design/icons";
import TextInput from "src/components/input";
import SelectInput from "src/components/select-input";
import Text from "src/components/text";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@store/reducers";
import { Lesson, SelectInputData } from "@type/index";
import Button from "src/components/button";
import { MEDIA_BASE_URL } from "src/config/api-constants";
import Modal from "src/components/modal";
import styles from "./styles.module.css";
import { useLocation, useParams } from "react-router-dom";
import { cloneDeep, debounce, find } from "lodash";
import { bindActionCreators } from "redux";
import * as actions from "src/store/actions";

const PremiumResources: FC = () => {
  const { subjectId } = useParams();
  const { pathname } = useLocation();
  const dispatch = useDispatch();
  const action = bindActionCreators(actions, dispatch);
  const splittedPathname = pathname?.split("/").slice(1);
  const { loadingPremiumResources, premiumResources } = useSelector((state: RootState) => state.learning);
  const [data, setData] = useState<Lesson[]>(premiumResources?.lesson || []);
  const [text, setText] = useState<string>("");
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [selectedGrade, setSelectedGrade] = useState<string>("");
  const [showPDFModal, setShowPDFModal] = useState<boolean>(false);
  const [dataToShowInModal, setDataToShowInModal] = useState<{ id: string; link: string; title: string }>();
  const [topics, setTopics] = useState<SelectInputData[]>([]);
  const [grades, setGrades] = useState<SelectInputData[]>([]);

  useEffect(() => {
    if (premiumResources?.lesson) {
      setData(cloneDeep(premiumResources?.lesson));
    }
  }, [premiumResources?.lesson]);

  useEffect(() => {
    const temp: SelectInputData[] = [];
    if (premiumResources?.lessonPack_option) {
      for (const [key, value] of Object.entries(premiumResources?.lessonPack_option)) {
        temp.push({
          id: key,
          label: value,
          value: key,
        });
      }
      setTopics(temp);
    }
  }, [premiumResources?.lessonPack_option]);

  useEffect(() => {
    const temp: SelectInputData[] = [];
    if (premiumResources?.grades && premiumResources?.grades?.length) {
      for (let i = 0; i < premiumResources?.grades.length; i++) {
        const grade = premiumResources?.grades[i];
        if (grade) {
          temp.push({
            id: grade?.id,
            label: grade?.title,
            value: grade?.id,
          });
        }
      }
      setGrades(temp);
    }
  }, [premiumResources?.grades]);

  useEffect(() => {
    const params: Record<string, string> = {};
    if (subjectId) {
      params.subject = subjectId;
    }
    if (text) {
      params.title = text;
    }
    if (selectedTopic) {
      params.type = selectedTopic;
    }
    if (selectedGrade) {
      params.grade_id = selectedGrade;
    }

    const debouncing = debounce(() => {
      action.getPremiumResources(params);
    }, 500);

    debouncing();

    return () => {
      debouncing?.cancel();
    };
  }, [subjectId, text, selectedTopic, selectedGrade]);

  return (
    <LearningLayout>
      {dataToShowInModal && (
        <Modal
          width={1200}
          destroyOnClose
          showOkButton={false}
          maskClosable={false}
          open={showPDFModal}
          title={dataToShowInModal?.title}
          onCancel={() => setShowPDFModal(false)}>
          <iframe className={styles.pdf} src={`${`${MEDIA_BASE_URL}${dataToShowInModal?.link}`}#toolbar=0`} />
        </Modal>
      )}
      <Fragment>
        {splittedPathname && splittedPathname?.length && (
          <div className={styles.breadcrumb}>
            <Text className={styles.breadcrumb_text}>Learning</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>Premium Resources</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>
              {find(premiumResources?.subjects, { id: Number(subjectId) })?.subject || "All"}
            </Text>
          </div>
        )}
      </Fragment>
      <Form className="mt-30">
        <Row gutter={[15, 10]} className="mt-15">
          <Col xxl={3} xl={3} lg={24} md={24} sm={24} xs={24} className={"align-center"}>
            <Text>Filters</Text>
          </Col>
          <Col xxl={7} xl={7} lg={8} md={8} sm={12} xs={24}>
            <TextInput
              allowClear
              value={text}
              placeholder={"Search by title"}
              suffix={<SearchOutlined />}
              onChange={value => setText(value)}
            />
          </Col>
          <Col xxl={7} xl={7} lg={8} md={8} sm={12} xs={24}>
            <SelectInput allowClear placeholder={"Select topic"} options={topics} onChange={setSelectedTopic} />
          </Col>
          <Col xxl={7} xl={7} lg={8} md={8} sm={12} xs={24}>
            <SelectInput allowClear placeholder={"Select level"} options={grades} onChange={setSelectedGrade} />
          </Col>
        </Row>
        <Table
          bordered
          size="small"
          scroll={{ x: 600 }}
          className={"mt-30"}
          loading={loadingPremiumResources}
          pagination={{ hideOnSinglePage: true, defaultPageSize: 10 }}
          dataSource={data?.map((el: Lesson, index: number) => {
            return {
              id: index + 1,
              link: el?.link,
              title: el?.title,
              grade: el?.grade?.title,
              subject: el?.subject?.subject,
            };
          })}
          columns={[
            {
              title: "#",
              dataIndex: "id",
              className: "text-center",
              width: 50,
            },
            {
              title: "Title",
              dataIndex: "title",
            },
            {
              width: 150,
              title: "Grade",
              render: record => <>{record?.grade}</>,
            },
            {
              width: 150,
              title: "Subject",
              render: record => <>{record?.subject}</>,
            },
            {
              title: "Action",
              render: record => (
                <Button
                  className="ml-auto mr-auto"
                  onClick={() => {
                    setShowPDFModal(true);
                    setDataToShowInModal(record);
                  }}
                  type="secondary">
                  View PDF
                </Button>
              ),
            },
          ]}
        />
      </Form>
    </LearningLayout>
  );
};

export default PremiumResources;
