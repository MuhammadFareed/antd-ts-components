/* eslint-disable indent */
import React, { FC } from "react";
import Text from "src/components/text";
import TextInput from "src/components/input";
import { ChangePasswordFormData } from "@type/index";
import { Form } from "antd";

type Props = {
  errorInitialized: boolean;
  values: ChangePasswordFormData;
  setFieldValue: (name: string, value: string) => void;
};

const ChangePassword: FC<Props> = props => {
  const { values, setFieldValue, errorInitialized } = props;

  return (
    <Form className="mb-10">
      <Form.Item>
        <Text size="S" className="mb-8">
          Current Password
        </Text>
        <TextInput
          allowClear
          secure
          placeholder="Enter current password"
          value={values?.oldPassword}
          onChange={(value: string) => setFieldValue("oldPassword", value)}
          error={
            errorInitialized && !values?.oldPassword
              ? "Password is required"
              : errorInitialized && values?.oldPassword && values?.oldPassword?.length < 8
              ? "Minimum 8 characters are required"
              : ""
          }
        />
      </Form.Item>
      <Form.Item>
        <Text size="S" className="mb-8">
          New Password
        </Text>
        <TextInput
          allowClear
          secure
          placeholder="Enter new password"
          value={values?.newPassword}
          onChange={(value: string) => setFieldValue("newPassword", value)}
          error={
            errorInitialized && !values?.newPassword
              ? "New password is required"
              : errorInitialized && values?.newPassword && values?.newPassword?.length < 8
              ? "Minimum 8 characters are required"
              : ""
          }
        />
      </Form.Item>
      <Form.Item>
        <Text size="S" className="mb-8">
          Retype New Password
        </Text>
        <TextInput
          allowClear
          secure
          placeholder="Retype new password"
          value={values?.confirmPassword}
          onChange={(value: string) => setFieldValue("confirmPassword", value)}
          error={
            errorInitialized && !values?.confirmPassword
              ? "This field is also required"
              : errorInitialized && values?.confirmPassword && values?.confirmPassword?.length < 8
              ? "Minimum 8 characters are required"
              : ""
          }
        />
      </Form.Item>
    </Form>
  );
};

export default ChangePassword;
