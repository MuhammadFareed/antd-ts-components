/* eslint-disable react-hooks/exhaustive-deps */
import Header from "src/components/header";
import React, { useCallback, useEffect, useState, useRef } from "react";
import styles from "./styles.module.css";
import Text from "src/components/text";
import total_packages from "src/assets/svgs/total_packages.svg";
import hours_taught from "src/assets/svgs/hours_taught.svg";
import students_retention_rate from "src/assets/svgs/students_retention_rate.svg";
import demo_conversion_rate from "src/assets/svgs/demo_conversion_rate.svg";
import book_pink from "src/assets/svgs/book_pink.svg";
import yellow_calendar from "src/assets/svgs/yellow_calendar.svg";
import { Col, Row, Space } from "antd";
import Carousel from "src/components/carousel";
import { homeCarousel, packageCarousel, reviewCarousel } from "src/constant/carousel-breakpoints";
import Button from "src/components/button";
import Badge from "src/components/badge";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import ReviewCard from "src/components/review-card";
import YellowMessageBanner from "src/components/message-banner";
import { getCurrentWeekOfMonth, openLinkInNewTab } from "src/utils";
import { inspirationalQuotes } from "src/constant";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@store/reducers";
import { bindActionCreators } from "redux";
import * as actions from "src/store/actions";
import { uniqueId } from "lodash";
import CountUp from "react-countup";
import { Package, PackageTimeSlot, PersistedGeneralState, ProfileReview, ProfileStateType } from "@type/index";
import PackageCard from "src/components/package-card";
import moment from "moment-timezone";
import { EnrolPackage } from "@type/demos";
import whatsNewData from "src/constant/whats-new-data";

interface IUpcomingClasses {
  id: number;
  packageDetail: EnrolPackage;
  slot: PackageTimeSlot;
}

interface IClass {
  title: string;
  timeLeft: number;
  zoomLink: string;
}

const Home = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const review = searchParams.get("review");
  const myRef = useRef<HTMLDivElement | null>(null);
  const action = bindActionCreators(actions, dispatch);
  const { profile, persistedGeneral, demo } = useSelector((state: RootState) => state);
  const { userProfile, progressTrackerData }: ProfileStateType = profile;
  const { topPackages }: PersistedGeneralState = persistedGeneral;
  const { teacherSchedule } = demo;
  // const whatsNewData: WhatsNewData[] = persistedGeneral?.whatsNewData;
  const [mySchedule, setMySchedule] = useState<IUpcomingClasses | null>(null);
  const [myClass, setMyClass] = useState<IClass>();

  const fetchData = useCallback(() => {
    // action.setWhatsNewData();
    action.setProgressTracker();
    action.fetchTopPackages();
  }, []);

  useEffect(() => {
    if (review) {
      setTimeout(() => {
        if (myRef && myRef.current) {
          myRef.current.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }
      }, 1000);
    }
  }, [review]);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (
      teacherSchedule &&
      teacherSchedule.upcomming_classes &&
      teacherSchedule.upcomming_classes.length &&
      teacherSchedule.upcomming_demo &&
      teacherSchedule.upcomming_demo.length
    ) {
      getTime();
    }
  }, [teacherSchedule]);

  useEffect(() => {
    if (mySchedule) {
      setSchedule(mySchedule);
      const timer = setInterval(() => setSchedule(mySchedule), 60000);
      return () => clearInterval(timer);
    }
  }, [mySchedule]);

  const setSchedule = (data: IUpcomingClasses) => {
    const startTime = moment();

    const endTime = moment(`${startTime.format("YYYY-MM-DD")} ${data.slot.start_time}`);
    const timeLeft = endTime?.diff(startTime, "minutes");

    if (timeLeft <= 60) {
      setMyClass({
        title: data.packageDetail.title,
        timeLeft,
        zoomLink: data.slot.zoom_link,
      });
    }
  };

  const getTime = () => {
    if (teacherSchedule) {
      const upcoming_classes: IUpcomingClasses[] = [];

      teacherSchedule.upcomming_classes.map(i => {
        const timeslot = i?.package?.time_slots?.find(j => j?.id === i?.slot_id);
        if (timeslot) {
          upcoming_classes.push({
            id: i?.id,
            packageDetail: i?.package,
            slot: timeslot,
          });
        }
      });

      teacherSchedule?.upcomming_demo?.map(i => {
        upcoming_classes.push({
          id: i?.id,
          packageDetail: {
            ...i?.package,
            time_slots: i?.package?.time_slot,
          },
          slot: i?.slot,
        });
      });

      if (upcoming_classes?.length) {
        const currentTime = moment(); // Get the current time using Moment.js
        const sortedArray = upcoming_classes
          ?.map(obj => ({
            ...obj,
            startTimeDiff: Math?.abs(moment(obj?.slot?.start_time, "HH:mm:ss").diff(currentTime)),
            isPast: moment(obj?.slot?.start_time, "HH:mm:ss").isBefore(currentTime),
          }))
          .filter(obj => obj?.startTimeDiff >= 0 && !obj?.isPast)
          .sort((a, b) => a?.startTimeDiff - b?.startTimeDiff);

        setMySchedule(sortedArray[0]);
      }
    }
  };

  return (
    <div className="home">
      <Header />
      <div className="container py-35">
        <YellowMessageBanner
          heading={`Hi ${userProfile?.name || ""}!`}
          subHeading={inspirationalQuotes[getCurrentWeekOfMonth()]}
        />
        <Row gutter={[20, 20]} className={"mt-24"}>
          <Col xxl={16} xl={16} lg={16} md={24} sm={24} xs={24}>
            <div className="white_box">
              <Text className="m-20" color="PINK" font="SEMIBOLD" size="L">
                What’s New
              </Text>
              <div>
                <Carousel responsive={homeCarousel} autoPlay={true} infinite>
                  {whatsNewData?.map(element => (
                    <div key={element?.id} className={styles.what_is_new_container}>
                      <img src={element?.imageWeb} alt="Banner" className={styles.what_is_new_image_for_web} />
                      <img src={element?.imageMobile} alt="Banner" className={styles.what_is_new_image_for_mobile} />
                      <div className="d-row justify-end">
                        <Button
                          onClick={() => openLinkInNewTab(element?.link)}
                          type="secondary"
                          className="mt-12 mb-12 mr-12">
                          Explore More
                        </Button>
                      </div>
                    </div>
                  ))}
                </Carousel>
              </div>
            </div>
            <div className="white_box mt-20 p-20">
              <Text color="PINK" size="XL" font="SEMIBOLD" className="mb-20">
                My Schedule for The Week
              </Text>
              {(teacherSchedule && teacherSchedule.schedule_demo) || myClass ? (
                <Row gutter={[20, 20]}>
                  <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                    <div className="white_box p-15">
                      <div className="d-row">
                        <div className={[styles.schedule_icon_div, styles.light_pink_bg].join(" ")}>
                          <img src={book_pink} alt="" />
                        </div>
                        <div className="ml-12">
                          <Text font="LIGHTER" size="S">
                            {myClass
                              ? `${myClass.title}, starting in ${myClass.timeLeft} minutes`
                              : "No Classes scheduled for today"}
                          </Text>
                          <Button disabled={!myClass} className="mt-10" type="tertiary">
                            Start Class
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Col>

                  <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                    {teacherSchedule.schedule_demo ? (
                      <div className={["white_box p-15", styles.light_yellow_bg].join(" ")}>
                        <div className="d-row">
                          <div className={[styles.schedule_icon_div, styles.light_yellow_bg2].join(" ")}>
                            <img src={yellow_calendar} alt="" />
                          </div>
                          <div className="ml-12">
                            <Text font="LIGHTER" size="S">
                              {`You have ${teacherSchedule?.schedule_demo} upcoming scheduled ${
                                teacherSchedule?.schedule_demo > 1 ? "demoes" : "demo"
                              }`}
                            </Text>
                            <Button
                              className="mt-10"
                              type="custom"
                              onClick={() => navigate("/demos")}
                              style={{ border: "1px solid #FCCF13", color: "#FCCF13", background: "#FFF8E8" }}>
                              View Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    ) : null}
                  </Col>
                </Row>
              ) : (
                <Text className={"my-27 text-center"} font="LIGHTER" size="S">
                  No Classes or Demos scheduled for this week!
                </Text>
              )}
            </div>
          </Col>
          <Col xxl={8} xl={8} lg={8} md={24} sm={24} xs={24}>
            {progressTrackerData && (
              <div className="white_box p-20">
                <Text color="PINK" font="SEMIBOLD" size="L">
                  My Progress Tracker
                </Text>
                <div className="white_box px-20 py-15 mt-20">
                  <div className="d-row">
                    <img src={total_packages} className={styles.total_packages_icon} alt="" />
                    <div className="ml-12">
                      <Text font="SEMIBOLD" size="XXL2">
                        <CountUp duration={3} end={progressTrackerData?.teacher_details?.total_packages || 0} />
                      </Text>
                      <Text font="LIGHTER" size="M2" className="mt-5">
                        Total Packages
                      </Text>
                    </div>
                  </div>
                </div>
                <div className="white_box px-20 py-15 mt-20">
                  <div className="d-row">
                    <img src={hours_taught} className={styles.total_packages_icon} alt="" />
                    <div className="ml-12">
                      <Text font="SEMIBOLD" size="XXL2">
                        <CountUp end={progressTrackerData?.lifetime_hours || 0} duration={3} />
                      </Text>
                      <Text font="LIGHTER" size="M2" className="mt-5">
                        Hours Taught
                      </Text>
                    </div>
                  </div>
                </div>
                <div className="white_box px-20 py-15 mt-20">
                  <div className="d-row">
                    <img src={students_retention_rate} className={styles.total_packages_icon} alt="" />
                    <div className="ml-12">
                      <Text font="SEMIBOLD" size="XXL2">
                        <CountUp
                          end={progressTrackerData?.teacher_details?.retention_basic_score || 0}
                          duration={3}
                          suffix="%"
                        />
                      </Text>
                      <Text font="LIGHTER" size="M2" className="mt-5">
                        Students Retention Rate
                      </Text>
                    </div>
                  </div>
                </div>
                <div className="white_box px-20 py-15 mt-20">
                  <div className="d-row">
                    <img src={demo_conversion_rate} className={styles.total_packages_icon} alt="" />
                    <div className="ml-12">
                      <Text font="SEMIBOLD" size="XXL2">
                        <CountUp
                          end={progressTrackerData?.teacher_details?.demo_conversion || 0}
                          duration={3}
                          suffix="%"
                        />
                      </Text>
                      <Text font="LIGHTER" size="M2" className="mt-5">
                        Demo Conversion Rate
                      </Text>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div className="white_box px-20 py-15 mt-20">
              <Text color="PINK" size="XL" font="SEMIBOLD" className="mb-5">
                My Badges
              </Text>
              <Space className={"mt-15"}>
                {userProfile?.area_manager ? <Badge type="teacher_manager" /> : null}
                {userProfile?.teacher?.isSuper ? <Badge type="super_teacher" /> : null}
                {userProfile?.teacher?.is_graduated ? <Badge type="graduate_teacher" /> : null}
              </Space>
            </div>
          </Col>
          <Col span={24}>
            <div className="white_box p-20">
              <Text color="PINK" size="XL" font="SEMIBOLD" className="mb-10">
                Top Performing Packages
              </Text>
              <Space className="mb-16">
                <Text size="S" font="LIGHTER" className="">
                  Add a time slot to earn more!{" "}
                </Text>
                <Link className={styles.add_now} to={"/packages/create-package"}>
                  Add Now
                </Link>
              </Space>
              {topPackages && topPackages?.length !== 0 && (
                <Carousel responsive={packageCarousel}>
                  {topPackages.map((item: Package) => (
                    <PackageCard key={item?.id} item={item} />
                  ))}
                </Carousel>
              )}
            </div>
          </Col>
          {userProfile && userProfile?.reviews && userProfile?.reviews?.length !== 0 && (
            <Col span={24}>
              <div ref={myRef} className="white_box p-20">
                <Text color="PINK" size="XL" font="SEMIBOLD" className="mb-10">
                  Parent Reviews (<CountUp end={userProfile?.reviews?.length} duration={3} />)
                </Text>
                <Carousel responsive={reviewCarousel}>
                  {userProfile?.reviews.map((review: ProfileReview) => (
                    <ReviewCard key={uniqueId()} review={review} />
                  ))}
                </Carousel>
              </div>
            </Col>
          )}
        </Row>
      </div>
    </div>
  );
};

export default Home;
