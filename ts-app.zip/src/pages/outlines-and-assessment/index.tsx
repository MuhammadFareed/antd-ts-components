import React, { FC, Fragment, useEffect, useState } from "react";
import { Form, Table, message } from "antd";
import LearningLayout from "src/components/learning-layout";
import Text from "src/components/text";
import { OutlineAssessment, OutlineAssessmentColumns } from "@type/index";
import { Link, useLocation, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { RootState } from "@store/reducers";
import Button from "src/components/button";
import { AWS_ACCESS_KEY_ID, AWS_BUCKET_NAME, AWS_REGION, AWS_SECRET, MEDIA_BASE_URL } from "src/config/api-constants";
import styles from "./styles.module.css";
import { openLinkInNewTab } from "src/utils";
import AWS from "aws-sdk";
import { saveAs } from "file-saver";
import { cloneDeep, find } from "lodash";

AWS.config.update({
  accessKeyId: AWS_ACCESS_KEY_ID,
  secretAccessKey: AWS_SECRET,
  region: AWS_REGION,
});

const OutlinesAndAssessment: FC = () => {
  const { subjectId } = useParams();
  const { pathname } = useLocation();
  const splittedPathname = pathname?.split("/").slice(1);
  const { loadingLearningResouces, learningResouces } = useSelector((state: RootState) => state?.learning);
  const { outlineAssessments, outlineAssessmentSubjects } = learningResouces;
  const [data, setData] = useState<OutlineAssessment[]>(outlineAssessments);
  // const [text, setText] = useState<string>("");

  useEffect(() => {
    if (outlineAssessments && outlineAssessments?.length) {
      const temp = outlineAssessments?.filter(e => Number(e?.subject_id) === Number(subjectId));
      if (temp?.length) {
        setData(temp);
      } else {
        setData(cloneDeep(outlineAssessments));
      }
    }
  }, [outlineAssessments, subjectId]);

  return (
    <LearningLayout>
      <Fragment>
        {splittedPathname && splittedPathname?.length && (
          <div className={styles.breadcrumb}>
            <Text className={styles.breadcrumb_text}>Learning</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>Outlines And Assessment</Text>
            <Text className={[styles.breadcrumb_text, "mx-8"].join(" ")}>&gt;</Text>
            <Text className={styles.breadcrumb_text}>
              {find(outlineAssessmentSubjects, { id: Number(subjectId) })?.subject || "All"}
            </Text>
          </div>
        )}
      </Fragment>
      <Form className="mt-30">
        {/* <Row gutter={[15, 10]} className="mt-15">
          <Col xxl={3} xl={3} lg={24} md={24} sm={24} xs={24} className={"align-center"}>
            <Text>Filters</Text>
          </Col>
          <Col xxl={7} xl={7} lg={8} md={8} sm={12} xs={24}>
            <TextInput
              allowClear
              value={text}
              placeholder={"Search by title"}
              suffix={<SearchOutlined />}
              onChange={value => setText(value)}
            />
          </Col>
          <Col xxl={7} xl={7} lg={8} md={8} sm={12} xs={24}>
            <SelectInput options={testCountries} allowClear placeholder={"Select level"} />
          </Col>
          <Col xxl={7} xl={7} lg={8} md={8} sm={12} xs={24}>
            <SelectInput options={testCountries} allowClear placeholder={"Select level"} />
          </Col>
        </Row> */}
        <Table
          bordered
          size="small"
          scroll={{ x: 600 }}
          className={"mt-30"}
          loading={loadingLearningResouces}
          pagination={{ hideOnSinglePage: true, defaultPageSize: 10 }}
          dataSource={data?.map((el: OutlineAssessment, index: number) => {
            return {
              id: index + 1,
              link: el?.pdf_url,
              subject: el?.subject?.subject,
            };
          })}
          columns={[
            {
              title: "#",
              dataIndex: "id",
              className: "text-center",
              width: 50,
            },
            {
              title: "PDF URL",
              className: styles.link_col,
              render: record => (
                <Link target="_blank" to={`${MEDIA_BASE_URL}${record?.link}`}>
                  {`${MEDIA_BASE_URL}${record?.link}`}
                </Link>
              ),
            },
            {
              title: "Subject",
              dataIndex: "subject",
              className: styles.subject,
            },
            {
              title: "Action",
              render: record => (
                <Button type="secondary" onClick={() => openLinkInNewTab(`${MEDIA_BASE_URL}${record?.link}`)}>
                  View PDF
                </Button>
              ),
            },
            {
              title: "Download",
              render: (record: OutlineAssessmentColumns) => (
                <Button
                  onClick={() => {
                    const fileUrl = record?.link?.slice(1);
                    const fileName = fileUrl?.split("/")[2];
                    const s3 = new AWS.S3();
                    const params = { Bucket: String(AWS_BUCKET_NAME), Key: fileUrl };
                    s3.getObject(params, (error, data: AWS.S3.GetObjectOutput) => {
                      if (data && data?.Body) {
                        // @ts-ignore
                        const blob = new Blob([data.Body]);
                        saveAs(blob, `${fileName}.pdf`);
                        message.success("PDF downloaded successfully!");
                      }
                    });
                  }}
                  type="tertiary">
                  Download PDF
                </Button>
              ),
            },
          ]}
        />
      </Form>
    </LearningLayout>
  );
};

export default OutlinesAndAssessment;
