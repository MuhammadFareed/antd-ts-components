import React, { useEffect, useMemo, useState } from "react";
import { Col, Row, Space, Pagination } from "antd";
import TextComponent from "src/components/text";
import styles from "./styles.module.css";
import Button from "src/components/button";
import Header from "src/components/header";
import Text from "src/components/text";
import noData from "src/assets/svgs/noData.svg";
import { useNavigate, useParams } from "react-router-dom";
import { getTeacherProfile, getTeacherPackagesById, getTeacherEvaluation } from "src/store/actions";
import presentionChart from "src/assets/svgs/presention-chart.svg";
import education from "src/assets/svgs/education.svg";
import educationPink from "src/assets/svgs/educationpink.svg";
import students_retention_rate from "src/assets/svgs/students_retention_rate.svg";
import demo_conversion_rate from "src/assets/svgs/demo_conversion_rate.svg";
import { packageProfileCarousel, reviewCarousel } from "src/constant/carousel-breakpoints";
import Carousel from "src/components/carousel";
import { theme } from "src/constant/theme";
import PackageCard from "src/components/package-card";
import { openLinkInNewTab } from "src/utils";
import { Package } from "@type/index";
import Badge from "src/components/badge";
import Modal from "src/components/modal";
import ReviewCard from "src/components/review-card";
import { dotAndLineMainDomain } from "src/constant";
import { uniqueId } from "lodash";
import JWVideoPlayer from "src/components/jw-video-player";
import { TeacherManager, EvaluationReport, IEvalReportPagination } from "@type/teacher-manager";
import moment from "moment-timezone";

const TeacherManagerDetails: React.FC = () => {
  const [teacherDetails, setTeacherDetails] = useState<TeacherManager>();
  const [evaluationReports, setEvaluationReports] = useState<IEvalReportPagination>();
  const [showVideo, setShowVideo] = useState<boolean>(false);
  const [packages, setPackages] = useState<Package[]>([]);
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      const teacherId = Number(id);
      getTeacherProfile(teacherId).then(response => {
        const data = response as TeacherManager;
        setTeacherDetails(data);
      });

      getPaginationReport(teacherId);

      getTeacherPackagesById(teacherId).then(response => {
        const data = response as Package[];
        setPackages(data);
      });
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const getPaginationReport = (teacherId: number, page?: number) => {
    const pageNo = page ? page : 1;
    getTeacherEvaluation(teacherId, pageNo).then(response => {
      const data = response as IEvalReportPagination;
      setEvaluationReports(data);
    });
  };

  const getTeacherDetails = useMemo(() => {
    if (teacherDetails) {
      const getNumber = teacherDetails.phone;
      return `${getNumber} | ${teacherDetails.email} | ${teacherDetails.teacher.country}`;
    }
  }, [teacherDetails]);

  // const getSanitizedContent = (text: string) => {
  //   const parser = new DOMParser();
  //   const doc = parser.parseFromString(text, "text/html");
  //   return doc.body.textContent || "";
  // };

  const handleViewReport = (report?: EvaluationReport) => {
    if (report && report.id) {
      navigate("/teacher-manager/report", { state: { reportId: report.id, teacher: teacherDetails } });
    } else {
      navigate("/teacher-manager/report", { state: { teacher: teacherDetails } });
    }
  };

  const getTeacher = useMemo(
    () => <JWVideoPlayer src={teacherDetails?.teacher?.demo_video} image={teacherDetails?.picture} height={450} />,
    [teacherDetails?.picture, teacherDetails?.teacher?.demo_video],
  );

  const handlePagination = (page: number) => {
    if (teacherDetails) {
      getPaginationReport(teacherDetails.id, page);
    }
  };

  return (
    <div>
      {showVideo && (
        <Modal width={800} open={showVideo} onCancel={() => setShowVideo(false)} showFooter={false} maskClosable>
          <div className="mt-30">{getTeacher}</div>
        </Modal>
      )}

      <Header />

      <div className={styles.yellow_div} />

      <div className={"container"}>
        <Row className="mb-40">
          <Col xxl={16} xl={16} lg={16} md={24} sm={24} xs={24}>
            <div className="d-flex">
              <div className={styles.profile_image_container}>
                <img src={teacherDetails?.picture || ""} alt="DP" className={styles.dp} />
              </div>
              <div className="d-column">
                <TextComponent className="mt-20 mb-8" title={teacherDetails?.name} bold size="XXL2" />
                <Space>
                  <Row>
                    <TextComponent
                      title={getTeacherDetails}
                      font={"NORMAL"}
                      customStyles={{ marginBottom: "3px" }}
                      color={"BLACK"}
                    />
                  </Row>
                </Space>
                <Space className={"mt-15"}>
                  {teacherDetails?.area_manager ? <Badge type="teacher_manager" /> : null}
                  {teacherDetails?.teacher?.isSuper ? <Badge type="super_teacher" /> : null}
                  {teacherDetails?.teacher?.is_graduated ? <Badge type="graduate_teacher" /> : null}
                </Space>
              </div>
            </div>
          </Col>
          <Col xxl={8} xl={8} lg={8} md={24} sm={24} xs={24} className={"justify-end"}>
            <Space className="align-start mt-26">
              <Button onClick={() => openLinkInNewTab(`${dotAndLineMainDomain}/teachers/${teacherDetails?.id}`)}>
                {"View Public Profile"}
              </Button>

              <Button onClick={() => setShowVideo(true)} type="secondary">
                {"Demo Video"}
              </Button>
            </Space>
          </Col>
        </Row>

        <Row gutter={[20, 24]}>
          <Col xxl={16} xl={16} lg={24} md={24} sm={24} xs={24}>
            <div className="white_box p-24">
              <TextComponent title="Teacher Info" font="SEMIBOLD" size="XL" className="mb-24" />
              <Row gutter={[20, 20]}>
                <Col xxl={8} xl={12} lg={8} md={8} sm={12} xs={24}>
                  <TextComponent title="Area Manager" font="LIGHTER" size="S" className="mb-8" />
                  <TextComponent title={teacherDetails?.area_manager_name} font="SEMIBOLD" size="S" className="mb-8" />
                </Col>
                <Col xxl={8} xl={12} lg={8} md={8} sm={12} xs={24}>
                  <TextComponent title="Recruited Date" font="LIGHTER" size="S" className="mb-8" />
                  <TextComponent
                    title={teacherDetails?.teacher.recruitedDate}
                    font="SEMIBOLD"
                    size="S"
                    className="mb-8"
                  />
                </Col>
                <Col xxl={8} xl={12} lg={8} md={8} sm={12} xs={24}>
                  <TextComponent title="Training Completion Date" font="LIGHTER" size="S" className="mb-8" />
                  <TextComponent
                    title={teacherDetails?.teacher.trainingCompletionDate}
                    font="SEMIBOLD"
                    size="S"
                    className="mb-8"
                  />
                </Col>
                {/* <Col xxl={8} xl={12} lg={8} md={8} sm={12} xs={24}>
                  <TextComponent title="Last Demo Settings Update" font="LIGHTER" size="S" className="mb-8" />
                  <TextComponent title="2020-12-14 21:56:46" font="SEMIBOLD" size="S" className="mb-8" />
                </Col> */}
              </Row>
            </div>
            <div className="white_box p-24 mt-20">
              <TextComponent title="Subjects" font="SEMIBOLD" size="XL" className="mb-24" />
              <div className={styles.subject_tags}>
                {teacherDetails?.teacher.subjects?.map((item: string) => (
                  <div key={uniqueId()} className={styles.subject_tag} style={{ backgroundColor: theme.YELLOW02 }}>
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div className="white_box p-24 mt-20">
              <TextComponent title={`Packages (${packages?.length})`} font="SEMIBOLD" size="XL" className="mb-24" />
              {packages && packages.length > 0 ? (
                <Carousel responsive={packageProfileCarousel}>
                  {packages.map((item: Package) => (
                    <PackageCard key={item.id} item={item} isButtonDisabled isShowStatus={false} />
                  ))}
                </Carousel>
              ) : (
                <Row justify={"center"}>
                  <div className={["mt-20", styles.noData].join(" ")}>
                    <Space size={"middle"} direction={"vertical"}>
                      <img src={noData} />

                      <Text title={"No Packages Found"} font={"SEMIBOLD"} size={"M"} color={"HEADING"} />
                    </Space>
                  </div>
                </Row>
              )}
            </div>
          </Col>

          <Col xxl={8} xl={8} lg={24} md={24} sm={24} xs={24}>
            <div className="white_box p-20">
              <TextComponent title="Statistics" font="SEMIBOLD" size="XL" className="mb-24" />
              <div className="pb-15">
                <Row>
                  <Col xxl={14} xl={12} lg={8} md={8} sm={8} xs={12}>
                    <div className={["d-row mt-30", styles.tab].join(" ")}>
                      <img src={demo_conversion_rate} className={styles.total_packages_icon} alt="" />
                      <div className="ml-12">
                        <TextComponent
                          title={`${teacherDetails?.teacher.avg_month_conversion || "0"}%`}
                          font="SEMIBOLD"
                          size="L"
                        />
                        <TextComponent
                          title="Demo Conversion Rate"
                          font="LIGHTER"
                          color="GREY"
                          size="M2"
                          className="mt-5"
                        />
                      </div>
                    </div>
                  </Col>
                  <Col xxl={10} xl={12} lg={8} md={8} sm={8} xs={12}>
                    <div className={["d-row mt-30", styles.tab].join(" ")}>
                      <img src={education} className={styles.total_packages_icon} alt="" />
                      <div className="ml-12">
                        <TextComponent
                          title={teacherDetails?.active_students.toString() || "0"}
                          font="SEMIBOLD"
                          size="L"
                        />
                        <TextComponent title="Active Students" font="LIGHTER" color="GREY" size="M2" className="mt-5" />
                      </div>
                    </div>
                  </Col>
                  <Col xxl={14} xl={12} lg={8} md={8} sm={8} xs={12}>
                    <div className={["d-row mt-30", styles.tab].join(" ")}>
                      <img src={students_retention_rate} className={styles.total_packages_icon} alt="" />
                      <div className="ml-12">
                        <TextComponent title={teacherDetails?.teacher?.conversion} font="SEMIBOLD" size="L" />
                        <TextComponent
                          title="Demo Conversion Status"
                          font="LIGHTER"
                          color="GREY"
                          size="M2"
                          className="mt-5"
                        />
                      </div>
                    </div>
                  </Col>
                  <Col xxl={10} xl={12} lg={8} md={8} sm={8} xs={12}>
                    <div className={["d-row mt-30", styles.tab].join(" ")}>
                      <img src={presentionChart} className={styles.total_packages_icon} alt="" />
                      <div className="ml-12">
                        <TextComponent
                          title={teacherDetails?.teacher.assignDemos ? "Active" : "Inactive"}
                          font="SEMIBOLD"
                          size="L"
                        />
                        <TextComponent title="Demo Status" font="LIGHTER" color="GREY" size="M2" className="mt-5" />
                      </div>
                    </div>
                  </Col>
                  <Col xxl={10} xl={12} lg={8} md={8} sm={8} xs={12}>
                    <div className={["d-row mt-30", styles.tab].join(" ")}>
                      <img src={educationPink} className={styles.total_packages_icon} alt="" />
                      <div className="ml-12">
                        <TextComponent
                          title={`${teacherDetails?.teacher?.avg_per.toString() || "0"}%`}
                          font="SEMIBOLD"
                          size="L"
                        />
                        <TextComponent title="Retention Rate" font="LIGHTER" color="GREY" size="M2" className="mt-5" />
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
            <div className="white_box p-20 mt-20">
              <div className={styles.evaluation}>
                <TextComponent title="Evaluation Info" font="SEMIBOLD" size="XL" />

                <Button onClick={handleViewReport} type="tertiary">
                  Generate Report
                </Button>
              </div>
              {evaluationReports && evaluationReports.data && evaluationReports.data.length > 0 && (
                <div className="mt-20">
                  {evaluationReports?.data.map(item => (
                    <div key={uniqueId()} className={styles.reports}>
                      <TextComponent
                        title={moment(item.report_date).format("DD/MM/YYYY")}
                        font="LIGHTER"
                        color={"BLACK02"}
                        size="S"
                      />
                      <Button onClick={() => handleViewReport(item)} type="primary">
                        {"View"}
                      </Button>
                    </div>
                  ))}

                  <Row justify={"center"} className={"mt-20"}>
                    <Pagination
                      hideOnSinglePage
                      onChange={handlePagination}
                      current={evaluationReports?.current_page}
                      pageSize={evaluationReports?.per_page}
                      total={evaluationReports?.total}
                    />
                  </Row>
                </div>
              )}
            </div>
          </Col>
        </Row>

        <Row gutter={[20, 24]}>
          <Col span={24}>
            <div className="white_box p-20 mt-20">
              <TextComponent title="Reviews" font="SEMIBOLD" size="XL" className="mb-24" />

              {teacherDetails && teacherDetails.reviews && teacherDetails.reviews.length > 0 ? (
                <Carousel responsive={reviewCarousel}>
                  {teacherDetails?.reviews?.map(e => (
                    <ReviewCard key={uniqueId()} review={e} />
                  ))}
                </Carousel>
              ) : (
                <Row justify={"center"}>
                  <div className={["mt-20", styles.noData].join(" ")}>
                    <Space size={"middle"} direction={"vertical"}>
                      <img src={noData} />

                      <Text title={"No Reviews Found"} font={"SEMIBOLD"} size={"M"} color={"HEADING"} />
                    </Space>
                  </div>
                </Row>
              )}
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default TeacherManagerDetails;
