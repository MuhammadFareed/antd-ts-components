import React from "react";
import Text from "src/components/text";
import Button from "src/components/button";
import styles from "./styles.module.css";
import { useNavigate } from "react-router-dom";

const NotFound = () => {
  const navigate = useNavigate();

  return (
    <div className={styles.page_not_found}>
      <Text font="LIGHTER">Page not found.</Text>
      <Button onClick={() => navigate("/")} type="tertiary" className="mt-15">
        Go to Home
      </Button>
    </div>
  );
};

export default NotFound;
