import React, { FC } from "react";

import { Row, Col, Space } from "antd";
import Text from "src/components/text";
import Chip from "../../components/chip";
import styles from "../../styles.module.css";
import { MenuItemType } from "src/types";
import MenuItems from "src/components/menu-items";
import moment from "moment-timezone";
import { TeacherDemos } from "@type/demos";

interface ICard {
  data: TeacherDemos;
  menuOptions?: MenuItemType[];
}

const Card: FC<ICard> = props => {
  const { data, menuOptions } = props;
  const demoDate = new Date(data.demo_date);
  const date = moment(demoDate).format("DD-MM-YYYY");

  return (
    <div className="white_box px-20 py-15 mt-20">
      <div className={styles.head}>
        <div className={styles.rescheduled}>
          <Space>
            <Text title={`${date} - ${data.demo_time}`} size={"S"} font={"LIGHTER"} color={"GREEN02"} />

            {data.dealstage === "rescheduled" && (
              <Chip title={"RESCHEDULED"} customMainStyles={styles.chipMargin} customStyles={styles.rescheduled_chip} />
            )}
          </Space>
        </div>

        {menuOptions && <MenuItems data={data} options={menuOptions} />}
      </div>

      <Row>
        <Space>
          <Chip title={`#${data.id}`} customStyles={styles.id} />
          <Chip title={data.demo_mode.toUpperCase()} customStyles={styles.status} />
          <Chip
            title={data.status.toUpperCase()}
            customStyles={data.status === "open" ? styles.open : styles.rescheduled_chip}
          />
        </Space>
      </Row>

      <Row gutter={[10, 10]}>
        <div className={styles.hrow} />

        <Col xxl={10} xl={10} lg={10} md={10} sm={10} xs={10}>
          <Text title={"Name"} size={"S"} font={"LIGHTER"} color={"GREY03"} />
        </Col>

        <Col xxl={14} xl={14} lg={14} md={14} sm={14} xs={14}>
          <Text title={data.parent?.name} size={"S"} font={"SEMIBOLD"} color={"BLACK"} />
        </Col>

        <Col xxl={10} xl={10} lg={10} md={10} sm={10} xs={10}>
          <Text title={"Phone"} size={"S"} font={"LIGHTER"} color={"GREY03"} />
        </Col>

        <Col xxl={14} xl={14} lg={14} md={14} sm={14} xs={14}>
          <Text title={data.parent.phone} size={"S"} font={"SEMIBOLD"} color={"BLACK"} />
        </Col>

        <Col xxl={10} xl={10} lg={10} md={10} sm={10} xs={10}>
          <Text title={"Package"} size={"S"} font={"LIGHTER"} color={"GREY03"} />
        </Col>

        <Col xxl={14} xl={14} lg={14} md={14} sm={14} xs={14}>
          <Text title={data.package.title} size={"S"} font={"SEMIBOLD"} color={"BLACK"} />
        </Col>

        <Col xxl={10} xl={10} lg={10} md={10} sm={10} xs={10}>
          <Text title={"Location"} size={"S"} font={"LIGHTER"} color={"GREY03"} />
        </Col>

        <Col xxl={14} xl={14} lg={14} md={14} sm={14} xs={14}>
          <Text title={data?.time_zone} size={"S"} font={"SEMIBOLD"} color={"BLACK"} />
        </Col>

        <div className={styles.hrow} />

        <Col xxl={10} xl={10} lg={10} md={10} sm={10} xs={10}>
          <Text title={"Assigned by"} size={"S"} font={"LIGHTER"} color={"GREY03"} />
        </Col>

        <Col xxl={14} xl={14} lg={14} md={14} sm={14} xs={14}>
          <Text title={data.agent?.name} size={"S"} font={"SEMIBOLD"} color={"BLACK"} />
        </Col>

        <Col xxl={10} xl={10} lg={10} md={10} sm={10} xs={10}>
          <Text title={"Created at"} size={"S"} font={"LIGHTER"} color={"GREY03"} />
        </Col>

        <Col xxl={14} xl={14} lg={14} md={14} sm={14} xs={14}>
          <Text title={moment(data.created_at).format("DD-MM-YYYY")} size={"S"} font={"SEMIBOLD"} color={"BLACK"} />
        </Col>
      </Row>
    </div>
  );
};

export default Card;
