import React from "react";

import styles from "../../styles.module.css";

interface IChip {
  title: string;
  customStyles?: string;
  customMainStyles?: string;
}

const Chip: React.FC<IChip> = ({ title, customStyles, customMainStyles }) => (
  <div className={[styles.chipContainer, customMainStyles].join(" ")}>
    <div className={[styles.chip, customStyles].join(" ")}>{title}</div>
  </div>
);

export default Chip;
