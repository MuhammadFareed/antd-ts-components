import React, { Dispatch, useCallback } from "react";
import { Space, Checkbox, Row } from "antd";
import Text from "src/components/text";
import styles from "../../styles.module.css";
import grade_icon from "src/assets/svgs/grade.svg";
import { Package, Subject } from "@type/demos";

type PackageCard = {
  data: Package;
  handleSelect: Dispatch<React.SetStateAction<Package | undefined>>;
  selected: Package | undefined;
};

const PackageCard = ({ data, handleSelect, selected }: PackageCard) => {
  const { id, title, amount, subjects, package_mode } = data;

  const onChangeCheckBox = useCallback(() => {
    // handle checkbox change
    if (selected?.id === id) {
      handleSelect(undefined);
    } else {
      handleSelect(data);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, selected]);

  return (
    <div onClick={onChangeCheckBox} className={styles.packageCard}>
      <Text className="pr-20" font="SEMIBOLD">
        {title}
      </Text>

      <Row className="mt-15 mb-15">
        <Space>
          {package_mode === "online" && (
            <div className={[styles.tag, styles.light_green_tag].join(" ")}>
              <span>ONLINE</span>
            </div>
          )}

          <div className={[styles.grade, "d-row my-6"].join(" ")}>
            <img src={grade_icon} alt="" />
            <Text className="ml-5 w-50 overflow-elipsis" font="LIGHTEST" size="S">
              {subjects.map((i: Subject) => i.subject).join(", ")}
            </Text>
          </div>
        </Space>
      </Row>

      <Text color={"DARK_GREEN"} font="SEMIBOLD">
        {`PKR ${amount} / month`}
      </Text>

      <div className={styles.checkBox}>
        <Checkbox checked={data.id === selected?.id} onChange={onChangeCheckBox} />
      </div>
    </div>
  );
};

export default PackageCard;
