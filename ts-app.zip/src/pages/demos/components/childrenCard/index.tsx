import React, { Dispatch, useCallback, useMemo } from "react";
import { Space, Checkbox, Row } from "antd";
import Text from "src/components/text";
import styles from "../../styles.module.css";
import grade_icon from "src/assets/svgs/grade.svg";
import { Children } from "@type/demos";
import { avatarArray } from "src/constant";
import child from "src/assets/svgs/child.svg";

type StudentInfoCard = {
  selected?: string;
  handleChildSelect: Dispatch<React.SetStateAction<string>>;
  data: Children;
};

const ChildrenCard = ({ data, selected, handleChildSelect }: StudentInfoCard) => {
  const { id, name, level } = data;

  const onChangeCheckBox = useCallback(() => {
    // handle checkbox change
    const idStr = id.toString();
    if (selected === idStr) {
      handleChildSelect("");
    } else {
      handleChildSelect(idStr);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, selected]);

  const getAvatar = (name: string) => {
    const av = avatarArray.find(item => item.name === name);
    if (av) {
      return av.icon;
    } else {
      return avatarArray[0].icon;
    }
  };

  const getAvatarData = useMemo(() => {
    if (data.avatar) {
      return getAvatar(data.avatar);
    } else if (data.image) {
      return data.image;
    }
  }, [data]);

  return (
    <Row onClick={onChangeCheckBox} className={styles.studentCard} align={"top"} justify={"space-between"}>
      <Space size="middle">
        <img className={styles.student_image} src={getAvatarData || child} alt="" />
        <div>
          <Text font="SEMIBOLD">{name}</Text>
          <div className={[styles.grade, "d-row my-6"].join(" ")}>
            <img src={grade_icon} alt="" />
            <Text className="ml-5" font="LIGHTEST" size="S">
              {level}
            </Text>
          </div>
          <div className={[styles.tag, styles.light_green_tag].join(" ")}>
            <span>ONLINE</span>
          </div>
        </div>
      </Space>

      <Checkbox checked={selected === id.toString()} onChange={onChangeCheckBox} />
    </Row>
  );
};

export default ChildrenCard;
