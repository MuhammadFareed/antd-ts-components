import React, { useMemo } from "react";
import Text from "src/components/text";

import infoSvg from "src/assets/svgs/info.svg";
import styles from "../../styles.module.css";
import { Space } from "antd";
import moment from "moment-timezone";

interface ISlotTimings {
  slot_id: number;
  start: string;
  end: string;
}

interface INotificationPopup {
  title?: string;
  date?: string;
  time?: number;
  name?: string;
  slots: ISlotTimings[];
}

const NotificationPopup: React.FC<INotificationPopup> = ({ title, date, time, name, slots }) => {
  const getTime = useMemo(() => {
    if (slots && slots.length) {
      if (time) {
        const slotTime = slots.find(i => i.slot_id === time);
        return moment(`${date} ${slotTime?.start}`).format("hh:mm A");
      }
    }

    return "";
  }, [date, slots, time]);

  return (
    <div className={styles.notificationPopup}>
      <div className={styles.notificationText}>
        <Space>
          <img src={infoSvg} alt={"info"} />

          <Text font={"NORMAL"} size={"S"}>
            <Space>
              {"You have a Rescheduled Demo Class for"}

              <span className={styles.bold}>{date}</span>

              {"at"}

              <span className={styles.bold}>{getTime}</span>

              {"for"}

              <span className={styles.bold}>{title}</span>

              {`with ${name || ""}`}
            </Space>
          </Text>
        </Space>
      </div>
    </div>
  );
};

export default NotificationPopup;
