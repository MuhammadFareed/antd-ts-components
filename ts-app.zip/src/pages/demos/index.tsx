/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import { Row, Col, Steps, DatePicker, message, Space, Select } from "antd";
import type { DatePickerProps } from "antd";
import Header from "src/components/header";
import Text from "src/components/text";
import presentionChart from "src/assets/svgs/presention-chart.svg";
import presentionChartGrey from "src/assets/svgs/presention-chartGrey.svg";
import calendar from "src/assets/svgs/calendar.svg";
import TextInput from "src/components/input";
import calendarCheck from "src/assets/svgs/calendar_check";
import warning from "src/assets/svgs/warning";
import search from "src/assets/svgs/search";
import dayjs from "dayjs";
import Button from "src/components/button";
import styles from "./styles.module.css";
import Chip from "./components/chip";
import { IData, MenuItemType } from "src/types";
import { RootState } from "@store/reducers";
import Card from "./components/card";
import Loader from "src/components/loader";
import { useSelector, useDispatch } from "react-redux";
import Carousel from "src/components/carousel";
import { demoStudent } from "src/constant/carousel-breakpoints";
import { bindActionCreators } from "redux";
import { TeacherDemos, IUpdateDemoStatusRequest, Package, Subject } from "src/types/demos";
import * as actions from "src/store/actions";
import { debounce } from "lodash";

import Modal from "src/components/modal";
import moment from "moment-timezone";
import ChildrenCard from "./components/childrenCard";
import PackageCard from "./components/packageCard";
import { RELOAD, PARENT_CHILDRENS } from "src/store/action-types/demo";
import { getStudentCount } from "src/utils";
import timeSlotsArr from "src/utils/timeSlots";
import NotificationPopup from "./components/notificationPopup";

const { Option } = Select;

interface InitialParams {
  limit: number;
  date?: string;
  keyword?: string;
}

const childDetail: IData[] = [
  {
    id: "0",
    title: "Name",
    value: "",
  },
  {
    id: "1",
    title: "Phone",
    value: "",
  },
  {
    id: "2",
    title: "Package",
    value: "",
  },
  {
    id: "3",
    title: "Location",
    value: "",
  },
];

const packageDetail: IData[] = [
  {
    id: "0",
    title: "Title",
    value: "",
  },
  {
    id: "1",
    title: "Program",
    value: "",
  },
  {
    id: "2",
    title: "Price",
    value: "",
  },
  {
    id: "3",
    title: "Int. Price",
    value: "",
  },
  {
    id: "4",
    title: "Total Students",
    value: "",
  },
  {
    id: "5",
    title: "Subjects",
    value: "",
  },
];

const initialParams: InitialParams = {
  limit: 50,
};

interface ISlotTimings {
  slot_id: number;
  start: string;
  end: string;
}

interface ISlotDate {
  date: string;
  days: string;
  id: number;
  timings: ISlotTimings[];
}

const Demos = () => {
  const dispatch = useDispatch();
  const action = bindActionCreators(actions, dispatch);
  const [showModal, setShowModal] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [scheduleModal, setScheduleModal] = useState<boolean>(false);
  const [filterDate, setFilterDate] = useState<string>("");
  const [stage, setStage] = useState(0);
  const [childSelect, setChildSelect] = useState<string>("");
  const handleCloseModal = () => {
    setShowModal(false);
    setScheduleModal(false);
  };
  const [time, setTime] = useState<number>();
  const [date, setDate] = useState<ISlotDate>();
  const [details, setDetails] = useState<IData[]>([]);
  const [isShowNotification, setIsShowNotification] = useState<boolean>(false);
  const [selectedDemo, setSelectedDemo] = useState<TeacherDemos | null>(null);
  const [scheduledDemos, setScheduledDemos] = useState<TeacherDemos[]>([]);
  const [attendedDemos, setAttendedDemos] = useState<TeacherDemos[]>([]);
  const [registeredDemos, setRegisteredDemos] = useState<TeacherDemos[]>([]);
  const [selectedPackage, setSelectedPackage] = useState<Package>();
  const [text, setText] = useState<string>("");
  const [showAttendedModal, setShowAttendedModal] = useState<boolean>(false);
  const [slotDates, setSlotDates] = useState<ISlotDate[]>([]);
  const [slotTiming, setSlotTiming] = useState<ISlotTimings[]>([]);
  const {
    teacherDemos,
    teacherDemoLoading,
    parentChildren,
    teacherPackages,
    demoSummary,
    reload,
    enrolDemoLoading,
    demoRescheduledLoading,
  } = useSelector((state: RootState) => state.demo);

  useEffect(() => {
    action.getDemoSummary();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reload]);

  useEffect(() => {
    setDemos();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teacherDemos]);

  useEffect(() => {
    if (reload && reload === "demoReload") {
      dispatch({ type: RELOAD, payload: "" });
      setShowAttendedModal(false);
    }

    if (reload && reload === "demoEnroll") {
      dispatch({ type: RELOAD, payload: "" });
      resetEnrol();
    }

    if (reload && reload === "demoRescheduled") {
      dispatch({ type: RELOAD, payload: "" });
      setIsShowNotification(true);
      setShowConfirmModal(false);
      setScheduleModal(false);

      setTimeout(() => {
        setIsShowNotification(false);
      }, 10000);
    }

    const obj = {
      ...initialParams,
    };

    if (filterDate) {
      obj.date = filterDate;
    }

    if (text) {
      obj.keyword = text;
    }

    const debouncing = debounce(() => {
      if (filterDate || text) {
        getDemos(obj);
      } else {
        getDemos({
          ...obj,
          // date: moment().format("MMMM YYYY"),
        });
      }
    }, 1000);

    debouncing();

    return () => {
      debouncing.cancel();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, filterDate, reload]);

  const setDemos = useCallback(() => {
    if (teacherDemos && teacherDemos.length) {
      const mergedArray: any[] = [];
      const scheduleDemo = teacherDemos.filter(i => i.dealstage === "scheduled");
      const attendDemo = teacherDemos.filter(i => i.dealstage === "attended");
      const registerDemo = teacherDemos.filter(i => i.dealstage === "registered");
      const reScheduledDemo = teacherDemos.filter(i => i.dealstage === "rescheduled");

      Array.prototype.push.apply(mergedArray, scheduleDemo);
      Array.prototype.push.apply(mergedArray, reScheduledDemo);

      setScheduledDemos(mergedArray);
      setAttendedDemos(attendDemo);
      setRegisteredDemos(registerDemo);
    } else {
      setScheduledDemos([]);
      setAttendedDemos([]);
      setRegisteredDemos([]);
    }
  }, [teacherDemos]);

  useEffect(() => {
    if (stage === 0) {
      if (selectedDemo) {
        const setChild = childDetail.map(i => {
          return {
            ...i,
            value: setChildData(i.title, selectedDemo),
          };
        });

        setDetails(setChild);
      }
    }
  }, [parentChildren, selectedDemo, stage]);

  useEffect(() => {
    if (selectedPackage) {
      const setPackage = packageDetail.map(i => {
        return {
          ...i,
          value: setPackageData(i.title, selectedPackage),
        };
      });

      setDetails(setPackage);
    }
  }, [selectedPackage]);

  const resetEnrol = () => {
    handleCloseModal();
    setChildSelect("");
    setStage(0);
    setSelectedDemo(null);
    setSelectedPackage(undefined);
    dispatch({ type: PARENT_CHILDRENS, payload: [] });
  };

  const getDemos = (params?: object) => {
    action.getTeacherDemos({
      ...initialParams,
      ...params,
    });
  };

  const setPackageData = (key: string, packageData: Package) => {
    switch (key) {
      case "Title":
        return packageData.title;

      case "Program":
        return packageData.program.name;

      case "Price":
        return `PKR ${packageData.amount} / month`;

      case "Int. Price":
        return `USD ${packageData.int_amount} / month`;

      case "Total Students":
        return getStudentCount(packageData.time_slot).toString();

      case "Subjects":
        return packageData.subjects.map((i: Subject) => i.subject).join(", ");

      default:
        return "";
    }
  };

  const setChildData = (key: string, demoData: TeacherDemos) => {
    switch (key) {
      case "Name":
        return demoData?.parent?.name;

      case "Phone":
        return demoData?.parent?.phone || "";

      case "Package":
        return demoData?.package?.title || "";

      case "Location":
        return demoData?.parent?.address || demoData?.time_zone;

      default:
        return "";
    }
  };

  const updateStatus = (data: IUpdateDemoStatusRequest) => {
    action.updateDemoStatus(data);
  };

  const handleAttended = () => {
    if (selectedDemo) {
      updateStatus({
        dealstage: "attended",
        demo_date: selectedDemo.demo_date,
        demo_id: selectedDemo.id.toString(),
        demo_time: selectedDemo.demo_time,
      });
    }
  };

  const handleReschedule = () => {
    if (selectedDemo && time && date && date.date) {
      const data = {
        slot_id: time,
        date: date?.date,
      };

      action.reScheduledDemo(selectedDemo.id, data);
    }
  };

  const handleRegisterDemo = (data: TeacherDemos) => {
    setSelectedDemo(data);
    setShowModal(true);

    action.getChildrens(data.parent.id);
    action.getTeacherPackages();
  };

  const setSlotDate = (packageData: Package) => {
    if (packageData && packageData.time_slot && packageData.time_slot.length) {
      const timeSlots = timeSlotsArr(packageData.time_slot) as ISlotDate[];
      setSlotDates(timeSlots);
    }
  };

  const menuOptions: MenuItemType[] = [
    {
      id: 0,
      label: "Reschedule",
      onClick: (data: TeacherDemos) => {
        setSelectedDemo(data);
        setScheduleModal(true);
        setSlotDate(data.package);
      },
    },
    {
      id: 1,
      label: "Attended",
      onClick: (data: TeacherDemos) => {
        setSelectedDemo(data);
        setShowAttendedModal(true);
      },
    },
    {
      id: 2,
      label: "Register",
      onClick: handleRegisterDemo,
    },
  ];

  const getTitle = useMemo(
    () => `You have Rescheduled ${selectedDemo?.teacher.name} ${selectedDemo?.package.title} Demo Class to`,
    [selectedDemo?.package.title, selectedDemo?.teacher.name],
  );

  const handleNext = () => {
    if (stage === 0) {
      if (childSelect) {
        if (selectedDemo && selectedDemo.package) {
          const setPackage = packageDetail.map(i => {
            return {
              ...i,
              value: setPackageData(i.title, selectedDemo.package),
            };
          });

          setDetails(setPackage);
          setSelectedPackage(selectedDemo.package);
        }

        setStage(1);
      } else {
        message.error("Please select child!");
      }
    } else if (stage === 1) {
      if (selectedPackage && selectedDemo) {
        const data = {
          demo_id: selectedDemo.id,
          package_id: selectedPackage.id,
          slot_id: selectedDemo.slot_id,
          student_id: childSelect,
        };
        action.enrolDemo(data);
      } else {
        message.error("Please select package!");
      }
    }
  };

  const handlePrevious = () => {
    setStage(0);
  };

  const onChangeDate: DatePickerProps["onChange"] = (date, dateString) => {
    const dateStr = date?.format("MMMM YYYY");

    if (dateStr) {
      setFilterDate(dateStr);
    } else {
      setFilterDate("");
    }
  };

  const handleTextChange = (e: string) => {
    setText(e);
  };

  const handleSlotDate = (value: number) => {
    const selectedDate = slotDates[value];

    if (selectedDate) {
      setSlotTiming(selectedDate.timings);
      setTime(undefined);
      setDate(selectedDate);
    }
  };

  const setTiming = (value: number) => {
    setTime(value);
  };

  const handleReScheduleModal = () => {
    if (date && time) {
      setShowConfirmModal(true);
    } else {
      message.error("Please select date and time!");
    }
  };

  const getDate = useCallback(() => {
    if (date && time) {
      const slot = date.timings.find(i => i.slot_id === time);
      return `${moment(`${date.date} ${slot?.start}`).format("DD MMMM YYYY, hh:mm a")} - ${moment(
        `${date.date} ${slot?.end}`,
      ).format(" hh:mm a")}`;
    }
  }, [date, time]);

  const getDemoDate = useMemo(() => {
    if (date && date.date) {
      const jsDate = new Date(date.date);
      const demoDate = moment(jsDate).format("DD MMMM YYYY");
      return demoDate;
    }

    return "";
  }, [date]);

  return (
    <div>
      {teacherDemoLoading && <Loader fullPage text={"Loading Demos..."} />}

      <Header />

      <div className="container py-35">
        {isShowNotification && (
          <NotificationPopup
            title={selectedDemo?.package.title}
            date={getDemoDate}
            time={time}
            slots={slotTiming}
            name={selectedDemo?.teacher?.name}
          />
        )}

        <Text title={"Demos"} font={"SEMIBOLD"} size={"XL"} color={"HEADING"} />

        <Row gutter={[20, 0]}>
          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                <img src={presentionChart} className={styles.total_packages_icon} alt="" />
                <div className="ml-12">
                  <Text title={demoSummary?.total.toString() || "0"} font="SEMIBOLD" size="XXL2" />
                  <Text title="Total Demos" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>

          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                <img src={calendar} className={styles.total_packages_icon} alt="" />
                <div className="ml-12">
                  <Text title={demoSummary?.scheduled || "0"} font="SEMIBOLD" size="XXL2" />
                  <Text title="Scheduled" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>

          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                <div className={styles.calendar}>
                  <img src={calendar} className={styles.total_packages_icon} alt="" />

                  <div className={styles.checkMark}>{calendarCheck}</div>
                </div>

                <div className="ml-12">
                  <Text title={demoSummary?.attended || "0"} font="SEMIBOLD" size="XXL2" />
                  <Text title="Attended" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>

          <Col xxl={6} xl={6} lg={6} md={12} sm={12} xs={24}>
            <div className="white_box px-20 py-15 mt-20">
              <div className="d-row">
                <div className={styles.calendar}>
                  <img src={presentionChartGrey} className={styles.total_packages_icon} alt="" />

                  <div className={styles.checkMark}>{warning}</div>
                </div>

                <div className="ml-12">
                  <Text title={demoSummary?.inactive || "0"} font="SEMIBOLD" size="XXL2" />
                  <Text title="Inactive Demos" font="LIGHTER" size="M2" className="mt-5" />
                </div>
              </div>
            </div>
          </Col>
        </Row>

        <div className="white_box px-20 py-15 mt-20">
          <Row className={styles.search} gutter={[10, 10]}>
            <Col xxl={4} xl={4} lg={5} md={12} sm={12} xs={24}>
              <DatePicker defaultPickerValue={dayjs()} format={"MMMM YYYY"} onChange={onChangeDate} picker="month" />
            </Col>

            <Col xxl={8} xl={8} lg={8} md={12} sm={12} xs={24}>
              <TextInput
                className={styles.textInput}
                onChange={handleTextChange}
                suffix={search}
                placeholder={"Search by ID, Name, Mobile"}
              />
            </Col>
          </Row>

          <Row gutter={[20, 20]}>
            <Col xxl={8} xl={8} lg={8} md={12} sm={24} xs={24}>
              {<Chip title={"SCHEDULED"} />}

              {scheduledDemos.map(item =>
                item.package && item.parent ? <Card key={item.id} data={item} menuOptions={menuOptions} /> : null,
              )}
            </Col>
            <Col xxl={8} xl={8} lg={8} md={12} sm={24} xs={24}>
              {<Chip title={"ATTENDED"} customStyles={styles.attended} />}

              {attendedDemos.map(item =>
                item.package && item.parent ? (
                  <Card key={item.id} data={item} menuOptions={menuOptions.slice(2)} />
                ) : null,
              )}
            </Col>
            <Col xxl={8} xl={8} lg={8} md={12} sm={24} xs={24}>
              {<Chip title={"REGISTERED"} customStyles={styles.registered} />}

              {registeredDemos.map(item => (item.package && item.parent ? <Card key={item.id} data={item} /> : null))}
            </Col>
          </Row>
        </div>
      </div>

      <Modal width={1100} title={"Enroll student"} onCancel={resetEnrol} open={showModal} showFooter={false}>
        <Row gutter={[20, 20]}>
          <Col xxl={14} xl={14} lg={14} md={14} sm={24} xs={24}>
            <div className={styles.steps}>
              <div className={styles.subSteps}>
                <Steps
                  size="small"
                  current={stage}
                  items={[
                    {
                      title: "Select Children",
                    },
                    {
                      title: "Select Package",
                    },
                  ]}
                />
              </div>
            </div>

            {stage === 0 && (
              <>
                {parentChildren && parentChildren.length > 0 ? (
                  <div className={styles.demoStudents}>
                    <Carousel responsive={demoStudent}>
                      {parentChildren.map(item => (
                        <ChildrenCard
                          data={item}
                          key={item.id}
                          selected={childSelect}
                          handleChildSelect={setChildSelect}
                        />
                      ))}
                    </Carousel>
                  </div>
                ) : null}
              </>
            )}

            {stage === 1 && (
              <>
                {teacherPackages && teacherPackages.length > 0 ? (
                  <div className={styles.demoStudents}>
                    <Carousel responsive={demoStudent}>
                      {teacherPackages.map(item => (
                        <PackageCard
                          selected={selectedPackage}
                          handleSelect={setSelectedPackage}
                          data={item}
                          key={item.id}
                        />
                      ))}
                    </Carousel>
                  </div>
                ) : null}
              </>
            )}
          </Col>

          <Col xxl={10} xl={10} lg={10} md={10} sm={24} xs={24}>
            <div className={["p-20", styles.parentInfo].join(" ")}>
              <Text
                title={stage === 0 ? "Parent Information" : "Package Information"}
                font={"SEMIBOLD"}
                color={"BLACK"}
              />

              <Row className={"mt-20"} gutter={[10, 20]}>
                {details.map(i => {
                  return (
                    <Fragment key={i.id}>
                      <Col xxl={10} xl={10} lg={10} md={10} sm={10} xs={10}>
                        <Text title={i.title} size={"S"} font={"LIGHTER"} color={"GREY03"} />
                      </Col>
                      <Col xxl={14} xl={14} lg={14} md={14} sm={14} xs={14}>
                        <Text title={i.value} size={"S"} font={"SEMIBOLD"} color={"BLACK"} />
                      </Col>
                    </Fragment>
                  );
                })}
              </Row>
            </div>
          </Col>
        </Row>
        <div className={styles.hrow} />
        <Row gutter={[20, 20]}>
          <Col xxl={18} xl={18} lg={18} md={18} sm={16} xs={24}>
            <Button type="secondary">{"Request Parent to Add Child"}</Button>
          </Col>

          <Col xxl={6} xl={6} lg={6} md={6} sm={8} xs={24}>
            <Row justify={"end"}>
              <Space>
                <Button
                  onClick={handlePrevious}
                  className={stage === 0 ? styles.disableBtn : ""}
                  disabled={stage === 0}
                  type="secondary">
                  {"Previous"}
                </Button>

                <Button loading={enrolDemoLoading} onClick={handleNext} type="tertiary">
                  {stage === 1 ? "Enroll" : "Next"}
                </Button>
              </Space>
            </Row>
          </Col>
        </Row>
      </Modal>

      <Modal
        title={"Reschedule Demo Class"}
        okButtonText={"Reschedule"}
        onCancel={handleCloseModal}
        onOk={handleReScheduleModal}
        open={scheduleModal}>
        <Row gutter={[10, 0]}>
          <Col span={24}>
            <div className={styles.rescheduleTitle}>{"Date"}</div>
          </Col>

          <Col span={24}>
            <Select placeholder={"Select Date"} style={{ width: 250 }} onChange={handleSlotDate}>
              {slotDates &&
                slotDates.length > 0 &&
                slotDates.map((i: any, index: number) => (
                  <Option key={index} value={index}>
                    {`${moment(i?.date || "").format("dddd")} ${moment(i?.date || "").format("DD-MM-YYYY")}`}
                  </Option>
                ))}
            </Select>
          </Col>
        </Row>

        <Row className="mt-20" gutter={[10, 0]}>
          <Col span={24}>
            <div className={styles.rescheduleTitle}>{"Time"}</div>
          </Col>

          <Col span={24}>
            <Select
              value={time}
              placeholder={"Select Time"}
              disabled={slotTiming && slotTiming.length === 0}
              style={{ width: 200 }}
              defaultValue={time}
              onChange={setTiming}>
              {slotTiming &&
                slotTiming.length > 0 &&
                slotTiming.map((i, index) => (
                  <Option key={index} value={i.slot_id}>{`${moment(`2023-05-01 ${i.start}`).format(
                    "hh:mm a",
                  )} -  ${moment(`2023-05-01 ${i.end}`).format("hh:mm a")}`}</Option>
                ))}
            </Select>
          </Col>
        </Row>
      </Modal>

      {showConfirmModal && (
        <Modal
          open={showConfirmModal}
          onOk={handleReschedule}
          okButtonLoading={demoRescheduledLoading}
          onCancel={() => setShowConfirmModal(false)}
          showCancelButton
          title={"Reschedule Demo Class"}>
          <Row gutter={[10, 0]}>
            <Col span={24}>{getTitle}</Col>
            <Col span={24} className={styles.timing}>
              {getDate()}
            </Col>
            <Col span={24}>{"Please Confirm?"}</Col>
          </Row>
        </Modal>
      )}

      {showAttendedModal && (
        <Modal
          open={showAttendedModal}
          onOk={handleAttended}
          okButtonLoading={teacherDemoLoading}
          onCancel={() => setShowAttendedModal(false)}
          showCancelButton
          title={"Mark as Attended?"}>
          <Row gutter={[10, 0]}>
            <Col span={24}>{"Are you sure you want to mark this demo to attended?"}</Col>
          </Row>
        </Modal>
      )}
    </div>
  );
};

export default Demos;
