/* eslint-disable react-hooks/exhaustive-deps */
import React, { Fragment, useCallback, useEffect, useState } from "react";
import Text from "src/components/text";
import { Badge, Pagination } from "antd";
import Header from "src/components/header";
import { Col, Row, Space, Tabs } from "antd";
import Button from "src/components/button";
import PackageCard from "src/components/package-card";
import TextInput from "src/components/input";
import { SearchOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import { MenuItemType, Package, PackagesStateType } from "@type/index";
import SelectInput from "src/components/select-input";
import filter_grey from "src/assets/svgs/filter_grey.svg";
import { useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import * as actions from "src/store/actions";
import { packageFilterOptions } from "src/constant";
import { RootState } from "@store/reducers";
import Loader from "src/components/loader";
import { packageServices } from "src/services";

const Packages = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const action = bindActionCreators(actions, dispatch);
  const [filterType, setFilterType] = useState<string>("All");
  const [searchTitle, setSearchTitle] = useState<string>("");
  const [filterApplied, setFilterApplied] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("active");
  const [loading, setLoading] = useState<boolean>(false);
  const { packagesData }: PackagesStateType = useSelector((state: RootState) => state.package);
  const { currentPage, loadingPackages, packages, perPage, total } = packagesData;
  const initialOptions: Record<string, string | number> = {
    page: 1,
    limit: 10,
    level: "All",
  };

  const fetchData = useCallback(() => {
    action.fetchPackages({ ...initialOptions, package_type: "active" });
  }, [initialOptions]);

  useEffect(() => {
    fetchData();
  }, []);

  const paginationHandler = (page: number, pageSize: number) => {
    window.scrollTo(0, 0);
    const queryObj = {
      ...initialOptions,
    };
    if (pageSize) {
      queryObj.page = Number(page);
      queryObj.limit = Number(pageSize);
    }
    if (searchTitle) {
      queryObj.title = searchTitle;
    }
    if (filterType) {
      queryObj.level = filterType;
    }
    searchHandler(queryObj, true);
  };

  const searchHandler = (params: Record<string, string | number>, fromPagination?: boolean) => {
    const queryObj = { ...initialOptions, ...params, package_type: activeTab };
    action.fetchPackages(queryObj);
    if (!fromPagination) {
      setFilterApplied(true);
    }
  };

  const clearFilter = () => {
    setFilterType("");
    setSearchTitle("");
    setFilterApplied(false);
    action.fetchPackages({ ...initialOptions, package_type: activeTab });
  };

  const updatePackageStatus = (id: number) => {
    setLoading(true);
    packageServices
      .updatePackageStatus(id, activeTab)
      .then(() => {
        action.fetchPackages({ ...initialOptions, package_type: activeTab });
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  const deletePackage = (id: number) => {
    setLoading(true);
    packageServices
      .deletePackage(id)
      .then(() => {
        action.fetchPackages({ ...initialOptions, package_type: activeTab });
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  return (
    <div>
      <Header />
      {(loadingPackages || loading) && <Loader fullPage />}
      <div className="container py-35">
        <div className="d-row justify-between flex-wrap">
          <Text className={"mr-20 mb-20"} size="XL" font="SEMIBOLD">
            Packages
          </Text>
          <Space className="flex-wrap mb-20" size={"middle"}>
            {filterApplied && (
              <Button type="tertiary" onClick={clearFilter}>
                Clear
              </Button>
            )}
            <TextInput
              placeholder="Search"
              suffix={<SearchOutlined />}
              allowClear
              style={{ width: 270 }}
              value={searchTitle}
              onChange={(value: any) => {
                setSearchTitle(value);
                if (!value) {
                  const tempObj: Record<string, string> = {};
                  if (filterType) {
                    tempObj.level = filterType;
                  }
                  searchHandler(tempObj);
                }
              }}
              onPressEnter={(e: any) => {
                if (e?.target?.value) {
                  const tempObj: Record<string, string> = { title: e?.target?.value };
                  if (filterType) {
                    tempObj.level = filterType;
                  }
                  searchHandler(tempObj);
                }
              }}
            />
            <Badge count={0} color={"#D01E79"}>
              <SelectInput
                suffixIcon={<img src={filter_grey} />}
                placeholder={"Select Package Level"}
                onChange={(value: any) => {
                  setFilterType(value);
                  const tempObj: Record<string, string> = { level: value };
                  if (searchTitle) {
                    tempObj.title = searchTitle;
                  }
                  searchHandler(tempObj);
                }}
                options={packageFilterOptions}
                value={`Filter by ${filterType}`}
                customStyles={{ width: 210 }}
              />
            </Badge>
            <Button type="tertiary" onClick={() => navigate("/packages/create-package")}>
              Create Package
            </Button>
          </Space>
        </div>
        <Tabs
          onChange={value => {
            action.fetchPackages({ ...initialOptions, package_type: value });
            setActiveTab(value);
          }}
          items={[
            {
              key: "active",
              label: "Active",
              children: (
                <Fragment>
                  <Row gutter={[0, 20]}>
                    {packages?.length === 0 ? (
                      <Text color="GREY" font="LIGHTER" size="S">
                        No result!
                      </Text>
                    ) : (
                      <Fragment>
                        {packages?.map((item: Package) => {
                          const activeMenuItems: MenuItemType[] = [];
                          if (!item?.active_enrollments_count) {
                            activeMenuItems.push({
                              id: 1,
                              label: "Archive",
                              onClick: () => updatePackageStatus(item?.id),
                            });
                          }
                          if (!item?.enrollments_count) {
                            activeMenuItems.push({
                              id: 2,
                              label: "Delete",
                              onClick: () => deletePackage(item?.id),
                            });
                          }
                          return (
                            <Col xxl={6} xl={8} lg={8} md={12} sm={12} xs={24} key={item?.id}>
                              <PackageCard menuOptions={activeMenuItems} item={item} />
                            </Col>
                          );
                        })}
                        <Col span={24}>
                          <Pagination
                            className="d-row justify-center mt-20 mb-60 pagination-card"
                            total={total}
                            current={currentPage}
                            hideOnSinglePage={true}
                            pageSize={perPage}
                            onChange={paginationHandler}
                          />
                        </Col>
                      </Fragment>
                    )}
                  </Row>
                </Fragment>
              ),
            },
            {
              key: "archive",
              label: "Archived",
              children: (
                <Fragment>
                  <Row gutter={[0, 20]}>
                    {packages?.length === 0 ? (
                      <Text color="GREY" font="LIGHTER" size="S">
                        No result!
                      </Text>
                    ) : (
                      <Fragment>
                        {packages?.map((item: Package) => {
                          const archivedMenuItems: MenuItemType[] = [
                            {
                              id: 1,
                              label: "Active",
                              onClick: () => updatePackageStatus(item?.id),
                            },
                          ];
                          if (!item?.enrollments_count) {
                            archivedMenuItems.push({
                              id: 2,
                              label: "Delete",
                              onClick: () => deletePackage(item?.id),
                            });
                          }
                          return (
                            <Col xxl={6} xl={8} lg={8} md={12} sm={12} xs={24} key={item?.id}>
                              <PackageCard menuOptions={archivedMenuItems} item={item} />
                            </Col>
                          );
                        })}
                        <Col span={24}>
                          <Pagination
                            className="d-row justify-center mt-20 mb-60 pagination-card"
                            total={total}
                            current={currentPage}
                            hideOnSinglePage={true}
                            pageSize={perPage}
                            onChange={paginationHandler}
                          />
                        </Col>
                      </Fragment>
                    )}
                  </Row>
                </Fragment>
              ),
            },
          ]}
        />
      </div>
    </div>
  );
};

export default Packages;
