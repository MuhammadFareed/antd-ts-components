import React, { FC, useState } from "react";
import styles from "./styles.module.css";
import login_image from "src/assets/svgs/login.svg";
import { Form } from "antd";
import TextInput from "src/components/input";
import logo from "src/assets/images/logo.png";
import { useNavigate } from "react-router-dom";
import Button from "src/components/button";
import { Formik, FormikHelpers } from "formik";
import { forgotPasswordFormSchema, loginFormSchema } from "src/constant/schema";
import { authServices } from "src/services";
import { ForgotPasswordFormData, LoggedInUser, LoginFormData } from "@type/index";
import { useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import * as actions from "src/store/actions";
import Modal from "src/components/modal";

const Login: FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const action = bindActionCreators(actions, dispatch);
  const [showModal, setShowModal] = useState<boolean>(false);

  const initialValues: LoginFormData = {
    email: "",
    password: "",
  };

  const loginHandler = (values: LoginFormData, { setSubmitting }: FormikHelpers<LoginFormData>) => {
    authServices
      .login(values)
      .then((user: LoggedInUser) => {
        action.setLoggedInUser(user);
        setSubmitting(false);
        navigate("/");
      })
      .catch(() => setSubmitting(false));
  };

  const forgotPasswordHandler = (
    values: ForgotPasswordFormData,
    { setSubmitting }: FormikHelpers<ForgotPasswordFormData>,
  ) => {
    authServices
      .forgotPassword(values)
      .then(() => {
        setSubmitting(false);
        setShowModal(false);
      })
      .catch(() => setSubmitting(false));
  };

  return (
    <div className={styles.login_page}>
      <div className={"forgot_password"}>
        {showModal && (
          <Formik
            initialValues={{ email: "" }}
            validationSchema={forgotPasswordFormSchema}
            onSubmit={forgotPasswordHandler}>
            {({ values, errors, setFieldValue, handleSubmit, isSubmitting }) => (
              <Modal
                destroyOnClose
                maskClosable={false}
                title={"Reset Password"}
                open={showModal}
                okButtonLoading={isSubmitting}
                okButtonText={"Submit"}
                onOk={handleSubmit}
                onCancel={() => setShowModal(false)}>
                <Form>
                  <p>Please type your registered email, we will send a new password on that email.</p>
                  <Form.Item>
                    <p className={styles.label}>Email</p>
                    <TextInput
                      allowClear
                      type={"email"}
                      value={values?.email}
                      placeholder={"Enter email"}
                      onChange={value => setFieldValue("email", value)}
                      error={errors.email}
                    />
                  </Form.Item>
                </Form>
              </Modal>
            )}
          </Formik>
        )}
      </div>
      <div className={styles.left_div}>
        <img src={login_image} alt="" />
      </div>
      <div className={styles.right_div}>
        <div className={styles.right_inner_container}>
          <div className="d-flex justify-center">
            <img src={logo} alt="logo" className={styles.logo} />
          </div>
          <Formik initialValues={initialValues} validationSchema={loginFormSchema} onSubmit={loginHandler}>
            {({ values, errors, handleChange, handleSubmit, isSubmitting }) => (
              <Form>
                <Form.Item validateStatus={errors?.email && errors?.email.length > 0 ? "error" : "success"}>
                  <p className={styles.label}>Email ID</p>
                  <TextInput
                    allowClear
                    type={"email"}
                    value={values?.email}
                    placeholder={"Enter email"}
                    onChange={handleChange("email")}
                    error={errors?.email}
                  />
                </Form.Item>
                <Form.Item validateStatus={errors?.password && errors?.password.length > 0 ? "error" : "success"}>
                  <p className={styles.label}>Password</p>
                  <TextInput
                    secure
                    allowClear
                    value={values.password}
                    placeholder={"Enter password"}
                    onChange={handleChange("password")}
                    error={errors?.password}
                  />
                </Form.Item>
                <div className="justify-center">
                  <a className={styles.forgot_password} onClick={() => setShowModal(true)}>
                    Forgot Password?
                  </a>
                </div>
                <div className="justify-center">
                  <Button isForm loading={isSubmitting} onClick={handleSubmit} className="w-100 mt-42" type="tertiary">
                    Login
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default Login;
