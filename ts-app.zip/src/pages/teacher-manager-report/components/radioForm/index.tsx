import React from "react";

import { Col, Row } from "antd";
import RadioGroupButton from "src/components/radio-group-button";
import Text from "src/components/text";
import { IRadioData } from "@type/teacher-manager";
import type { RadioChangeEvent } from "antd";
import styles from "../../styles.module.css";

interface IRadioForm {
  data: IRadioData[];
  onHandleChange?: (e: RadioChangeEvent, i: number) => void;
}

const RadioForm: React.FC<IRadioForm> = ({ data = [], onHandleChange }) => {
  return (
    <Row gutter={[0, 20]}>
      {data.map((item: IRadioData, index: number) => (
        <Col key={`${item.title}-${index}`} span={24}>
          <div className={["d-row", styles.evaluationForm].join(" ")}>
            <div className={["w-100 mr-100", styles.title].join(" ")}>
              <Text title={item.title} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
            </div>

            <div className="w-100 justify-end">
              <RadioGroupButton
                direction={"horizontal"}
                onChange={e => {
                  if (typeof onHandleChange === "function") {
                    onHandleChange(e, index);
                  }
                }}
                value={item.selectedValue}
                options={item.options}
              />
            </div>
          </div>
        </Col>
      ))}
    </Row>
  );
};

export default React.memo(RadioForm);
