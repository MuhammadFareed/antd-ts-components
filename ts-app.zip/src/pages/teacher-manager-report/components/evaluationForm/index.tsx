import React, { useCallback } from "react";
import { Col, Row } from "antd";
import { theme } from "src/constant/theme";
import Text from "src/components/text";

import styles from "../../styles.module.css";
import { RadioGroupOption } from "src/types";
import { IRadioData } from "src/types/teacher-manager";
import { SubCategory, IFormType } from "src/types/teacher-manager";
import TextInput from "src/components/input";
import RadioForm from "../radioForm";
import CheckboxForm from "../checkboxForm";

const bgColor = theme.GREY02;

interface IFormComponent {
  background?: string;
  formValues: any[];
  isDisabled: boolean;
  setFormValues: React.Dispatch<React.SetStateAction<any[]>>;
  data: SubCategory<RadioGroupOption | IRadioData>;
}

const Form: React.FC<IFormComponent> = ({ data, setFormValues, formValues, isDisabled }) => {
  const handleData = useCallback(
    (value: string | string[], cId: number, sId: number, qId: number) => {
      const savedData = [...formValues];

      const categoryIndex = savedData.findIndex(i => i.id === cId);

      if (categoryIndex !== -1) {
        const subCatategoryIndex = savedData[categoryIndex].sub_categories.findIndex(
          (i: { id: number }) => i.id === sId,
        );
        if (subCatategoryIndex !== -1) {
          if (data.type === IFormType.RATING) {
            savedData[categoryIndex].sub_categories[subCatategoryIndex].questions[qId].selectedValue = value;
          } else {
            if (typeof value !== "string" && data.limit) {
              if (value.length <= data.limit) {
                savedData[categoryIndex].sub_categories[subCatategoryIndex].selectedValues = value;
              }
            } else {
              savedData[categoryIndex].sub_categories[subCatategoryIndex].selectedValues = value;
            }
          }
        }
      }

      setFormValues(savedData);
    },
    [data.limit, data.type, formValues, setFormValues],
  );

  const handleTextInput = useCallback(
    (e: any) => {
      const savedData = [...formValues];
      const categoryIndex = savedData.findIndex(i => i.id === data.eval_category_id);

      if (categoryIndex !== -1) {
        const subCatategoryIndex = savedData[categoryIndex].sub_categories.findIndex(
          (i: { id: number }) => i.id === data.id,
        );

        if (subCatategoryIndex !== -1) {
          savedData[categoryIndex].sub_categories[subCatategoryIndex].comment = e;
          setFormValues(savedData);
        }
      }
    },
    [data.eval_category_id, data.id, formValues, setFormValues],
  );

  const renderOptions = useCallback(() => {
    switch (data.type) {
      case IFormType.RATING:
        return (
          <RadioForm
            data={data.questions as IRadioData[]}
            onHandleChange={(e, index) => {
              if (!isDisabled) {
                handleData(e.target.value, data.eval_category_id, data.id, index);
              }
            }}
          />
        );

      default:
        return (
          <CheckboxForm
            selectedValues={data.selectedValues}
            onHandleChange={e => {
              if (!isDisabled) {
                const value = e as string[];
                const findInd = data.questions.findIndex(i => i.id === Number(value));
                handleData(value, data.eval_category_id, data.id, findInd);
              }
            }}
            options={data.questions as RadioGroupOption[]}
          />
        );
    }
  }, [data.eval_category_id, data.id, data.questions, data.selectedValues, data.type, handleData, isDisabled]);

  const getWordCount = useCallback((str: string) => {
    str = str.trim();

    if (str === "") {
      return 0;
    }
    // Split the string into an array of words
    const words = str.split(/\s+/);

    // Return the number of words
    return words.length;
  }, []);

  return (
    <div className={["p-24", styles.mainContainer].join(" ")} style={{ backgroundColor: bgColor }}>
      <Row gutter={[0, 15]} align={"bottom"} className={"mb-24"}>
        <Text title={data.title} color={"HEADING"} font={"NORMAL"} size={"M"} className={"mr-20"} />

        {data.has_error && <Text title={"*This is required"} color={"RED"} font={"LIGHTER"} size={"S"} />}
      </Row>

      {renderOptions()}

      {data.has_comment > 0 && (
        <>
          <Row className={"mt-20"}>
            <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
              <Text title={"Comments"} className={"mb-10"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
              <TextInput
                disabled={isDisabled}
                limit={data.commentCount}
                value={data.comment}
                onChange={handleTextInput}
                multiline
              />
            </Col>
          </Row>

          {data.commentCount && (
            <Row justify={"end"}>
              <Text
                title={`${getWordCount(data.comment)}/${data.commentCount}`}
                className={"mt-10"}
                size={"S"}
                font={"LIGHTER"}
                color={"BLACK02"}
              />
            </Row>
          )}
        </>
      )}
    </div>
  );
};

export default React.memo(Form);
