import React from "react";

import { Row } from "antd";
import { RadioGroupOption } from "@type/index";

import { CheckboxValueType } from "antd/es/checkbox/Group";
import CheckboxGroupButton from "src/components/checkbox-group-button";

interface ICheckBoxForm {
  options: RadioGroupOption[];
  selectedValues?: string[];
  onHandleChange?: (e: CheckboxValueType[]) => void;
}

const CheckBoxForm: React.FC<ICheckBoxForm> = ({ options, selectedValues, onHandleChange }) => {
  return (
    <Row gutter={[0, 20]}>
      {options.length > 0 && (
        <CheckboxGroupButton
          direction={"vertical"}
          value={selectedValues}
          onChange={onHandleChange}
          options={options}
        />
      )}
    </Row>
  );
};

export default React.memo(CheckBoxForm);
