import React, { useCallback, useEffect, useLayoutEffect, useState, useMemo } from "react";
import { Col, message, Row, Space } from "antd";
import { getCommentCount, getLimit, openLinkInNewTab } from "src/utils";
import Button from "src/components/button";
import Header from "src/components/header";
import Text from "src/components/text";
import styles from "./styles.module.css";
import { theme } from "src/constant/theme";
import badge from "src/assets/svgs/badge";
import Form from "./components/evaluationForm";
import anonymous from "src/assets/images/anonymous.jpeg";
import { options } from "src/constant/report-data";
import { getNotificationData } from "src/utils/index";
import bell from "src/assets/notificationSvgs/bell.svg";
import {
  TeacherManager,
  Settings,
  IEvaluationResponse,
  Question,
  IFormType,
  IFormValues,
  ViewReport,
  IRadioData,
} from "src/types/teacher-manager";

import { dotAndLineMainDomain } from "src/constant";
import { useLocation, useNavigate } from "react-router-dom";
import { createEvaluationReport, getTeacherEvaluationDetails, getTeacherEvaluationReport } from "src/store/actions";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@store/reducers";
import { bindActionCreators } from "redux";
import Modal from "src/components/modal";
import moment from "moment-timezone";
import { NOTIFICATION_DATA } from "src/store/action-types/notification";

import * as actions from "src/store/actions";

interface IState {
  reportId: number;
  teacher: TeacherManager;
}

const bgColorDemo = { backgroundColor: theme.PINK02 };
const bgColorAcquisition = { backgroundColor: theme.YELLOW03 };

const TeacherManagerReport: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isEditDisabled, setIsEditDisabled] = useState(false);
  const [teacherDetails, setTeacherDetails] = useState<TeacherManager>();
  const [settings, setSettings] = useState<Settings>();
  const action = bindActionCreators(actions, dispatch);
  const { evaluationReportForm } = useSelector((state: RootState) => state.teacherManager);
  const [formData, setFormData] = useState<IEvaluationResponse[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [confirmModal, setConfirmModal] = useState<boolean>(false);
  const location = useLocation();

  const getOptions = useCallback((type: IFormType, questions: Question[]) => {
    switch (type) {
      case IFormType.RATING:
        return questions.map(i => ({
          id: i.id,
          title: i.title,
          selectedValue: `${i.id}-NA`,
          options: options.map(j => ({
            ...j,
            value: `${i.id}-${j.value}`,
          })),
        }));

      default:
        return questions.map(k => ({
          id: k.id,
          label: k.title,
          value: k.id.toString(),
        }));
    }
  }, []);

  useEffect(() => {
    getReport();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useLayoutEffect(() => {
    if (location.state) {
      const state = location.state as IState;

      if (evaluationReportForm) {
        const data = evaluationReportForm.map(i => ({
          id: i.id,
          title: i.title,
          sub_categories: i.sub_categories.map(j => ({
            ...j,
            comment: "",
            has_error: false,
            commentCount: getCommentCount(j.id),
            selectedValues: [] as string[],
            limit: j.type === IFormType.CHECKBOX ? getLimit(j.id) : 0,
            questions: getOptions(j.type, j.questions) as IRadioData[],
          })),
        }));

        if (state.reportId) {
          const reportId = state.reportId;
          setIsEditDisabled(true);

          getTeacherEvaluationReport(reportId).then(response => {
            if (response) {
              const resp = response as unknown as ViewReport;
              if (resp && resp.data && resp.data.details && resp.data.details.length) {
                resp.data.details.map(detail => {
                  const cId = detail?.category_id;
                  const sId = detail?.sub_category_id;
                  const qId = detail?.question_id;
                  const vId = Number(detail.rating);
                  const categoryIndex = data.findIndex(i => i.id === cId);

                  if (categoryIndex !== -1) {
                    const subCatategoryIndex = data[categoryIndex].sub_categories.findIndex(
                      (i: { id: number }) => i.id === sId,
                    );
                    if (subCatategoryIndex !== -1) {
                      data[categoryIndex].sub_categories[subCatategoryIndex].comment = detail.comment || "";
                      if (detail.type === IFormType.RATING) {
                        const questionId = data[categoryIndex].sub_categories[subCatategoryIndex].questions.findIndex(
                          i => i.id === qId,
                        );

                        data[categoryIndex].sub_categories[subCatategoryIndex].questions[
                          questionId
                        ].selectedValue = `${qId}-${options[vId].value}`;
                      } else {
                        data[categoryIndex].sub_categories[subCatategoryIndex].selectedValues.push(
                          detail?.question_id?.toString(),
                        );
                      }
                    }
                  }
                });

                setFormData(data);
              }
            }
          });
        } else {
          setFormData(data);
        }

        if (state.teacher) {
          setTeacherDetails(state.teacher);
          getTeacherEvaluationDetails(state.teacher.id).then(response => {
            setSettings(response as Settings);
          });
        }
      }
    }
  }, [evaluationReportForm, getOptions, location.state]);

  const getReport = () => {
    action.getTeacherEvaluationForm();
  };

  const getValues = useCallback(() => {
    const formValues: IFormValues[] = [];
    const errors: number[] = [];

    formData.map(i => {
      i.sub_categories.map(j => {
        let count = 0;
        if (j.type === IFormType.RATING) {
          j.questions.map((k, index) => {
            if (k.selectedValue) {
              formValues.push({
                categoryId: i.id,
                subCategoryId: j.id,
                questionId: k.id,
                comment: j.comment || "",
                value: k.selectedValue ? parseInt(k.selectedValue.split("-")[1]) : "",
                type: j.type,
              });
            } else {
              count++;
            }

            if (index === j.questions.length - 1) {
              if (count) {
                if (j.questions.length) {
                  errors.push(j.id);
                }
              }
            }
          });
        } else {
          if (j.selectedValues.length) {
            j.selectedValues.map(k => {
              formValues.push({
                categoryId: i.id,
                subCategoryId: j.id,
                questionId: Number(k),
                comment: j.comment || "",
                value: k,
                type: j.type,
              });
            });
          } else {
            if (j.questions.length) {
              errors.push(j.id);
            }
          }
        }
      });
    });

    return { formValues, errors };
  }, [formData]);

  const renderContent = (text: string) => <div className="mt-20">{text}</div>;

  const reportUpdateNotification = useMemo(
    () =>
      getNotificationData({
        image: bell,
        content: () => renderContent(`The report for ${teacherDetails?.name} teacher partner has been submitted.`),
        title: "Report Update:",
        successText: "Okay",
        disableCancel: true,
      }),
    [teacherDetails?.name],
  );

  const sendData = (isSendEmail: boolean) => {
    if (settings && teacherDetails) {
      setIsLoading(true);

      createEvaluationReport({
        settings,
        evalReportDetails: getValues().formValues,
        report_date: moment().format("YYYY-MM-DD"),
        teacher_id: teacherDetails.id,
        isSendEmail: !!isSendEmail,
      })
        .then(() => {
          setIsLoading(false);

          navigate(-1);
          dispatch({ type: NOTIFICATION_DATA, payload: reportUpdateNotification });
        })
        .catch(() => {
          setIsLoading(false);
        });
    }
  };

  const handleSubmit = () => {
    const { errors, formValues } = getValues();

    if (errors && errors.length) {
      const form = formData.map(i => {
        return {
          ...i,
          sub_categories: i.sub_categories.map(j => {
            if (errors.some(k => k === j.id)) {
              return {
                ...j,
                has_error: true,
              };
            }

            return {
              ...j,
              has_error: false,
            };
          }),
        };
      });

      message.error("Please select required fields");
      setFormData(form);
    } else {
      const shouldSendEmail = formValues.some(i => i.subCategoryId === 5);

      if (shouldSendEmail) {
        setConfirmModal(true);
      } else {
        sendData(false);
      }
    }
  };

  return (
    <div>
      <Modal
        open={confirmModal}
        onOk={() => sendData(true)}
        okButtonLoading={isLoading}
        onCancel={() => {
          sendData(false);
          setConfirmModal(false);
        }}
        handleModalCancel={() => setConfirmModal(false)}
        showCancelButton
        okButtonText="Send"
        cancelButtonText="Submit without send"
        title={"Send Email"}>
        {"Do you want to send nurturing plan to the teacher?"}
      </Modal>
      <Header />

      <div className="container py-35">
        <Text
          title={isEditDisabled ? "View Report" : "Create Report"}
          font={"SEMIBOLD"}
          size={"XL"}
          color={"HEADING"}
        />

        <div className={"white_box p-24 my-20"}>
          <Row>
            <Col xxl={16} xl={16} lg={16} md={24} sm={24} xs={24}>
              <div className="d-flex">
                <div className={styles.profile_image_container}>
                  <img src={teacherDetails?.picture || anonymous} alt="DP" className={styles.dp} />
                </div>

                <div className="d-column justify-center">
                  <Row>
                    <Text className="mb-8 mr-10" title={teacherDetails?.name} bold size="XL" />
                    {teacherDetails?.teacher.isSuper ? badge : null}
                  </Row>
                  <Space>
                    <Row>
                      <Text
                        title={teacherDetails?.teacher.subjects?.map(i => i).join(", ")}
                        size={"S"}
                        customStyles={{ marginBottom: "3px" }}
                        font={"LIGHTER"}
                        color={"BLACK"}
                      />
                    </Row>
                  </Space>
                </div>
              </div>
            </Col>

            <Col xxl={8} xl={8} lg={8} md={24} sm={24} xs={24} className={"justify-end align-center"}>
              <Button onClick={() => openLinkInNewTab(`${dotAndLineMainDomain}/teachers/${teacherDetails?.id}`)}>
                {"View Public Profile"}
              </Button>
            </Col>
          </Row>
        </div>

        <div className={"white_box p-24 my-20"}>
          <Text title="Demo Preferences" color="HEADING" font="NORMAL" size="M" className="mb-24" />

          <Row gutter={[20, 20]}>
            <Col xxl={8} xl={8} lg={12} md={24} sm={24} xs={24}>
              <div className={["p-20", styles.acquisition].join(" ")} style={bgColorDemo}>
                <Text title={"Express"} font={"NORMAL"} color={"HEADING"} />

                <Row gutter={[10, 10]} className="mt-30">
                  <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={12}>
                    <Text title={"Status"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text title={settings?.demo_express_status} size={"S"} font={"SEMIBOLD"} color={"BLACK02"} />
                  </Col>

                  <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={12}>
                    <Text title={"Grade Count"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.demo_express_grade.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>
                </Row>
              </div>
            </Col>

            <Col xxl={8} xl={8} lg={12} md={24} sm={24} xs={24}>
              <div className={["p-20", styles.acquisition].join(" ")} style={bgColorDemo}>
                <Text title={"Premium"} font={"NORMAL"} color={"HEADING"} />

                <Row gutter={[10, 10]} className="mt-30">
                  <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={12}>
                    <Text title={"Status"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text title={settings?.demo_premium_status} size={"S"} font={"SEMIBOLD"} color={"BLACK02"} />
                  </Col>

                  <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={12}>
                    <Text title={"Grade Count"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.demo_premium_grade.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>
                </Row>
              </div>
            </Col>
          </Row>
        </div>

        <div className={"white_box p-24 my-20"}>
          <Text title="Student acquisition and retention" color="HEADING" font="NORMAL" size="M" className="mb-24" />

          <Row gutter={[20, 20]}>
            <Col xxl={8} xl={8} lg={12} md={24} sm={24} xs={24}>
              <div className={["p-20", styles.acquisition].join(" ")} style={bgColorAcquisition}>
                <Text title={"TP student count"} font={"NORMAL"} color={"HEADING"} />
                <Text title={"(subscription and monthly)"} font={"NORMAL"} color={"HEADING"} />

                <Row gutter={[10, 10]} className="mt-30">
                  <Col xxl={8} xl={8} lg={8} md={8} sm={8} xs={8}>
                    <Text title={"Active"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.student_active.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>

                  <Col xxl={8} xl={8} lg={8} md={8} sm={8} xs={8}>
                    <Text title={"Dropout"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.student_dropout.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>

                  <Col xxl={8} xl={8} lg={8} md={8} sm={8} xs={10}>
                    <Text title={"Signups"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.student_signup.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>
                </Row>
              </div>
            </Col>

            <Col xxl={8} xl={8} lg={12} md={24} sm={24} xs={24}>
              <div className={["p-20", styles.acquisition].join(" ")} style={bgColorAcquisition}>
                <Text title={"TP monthly"} font={"NORMAL"} color={"HEADING"} />
                <Text title={"demo conversions"} font={"NORMAL"} color={"HEADING"} />

                <Row gutter={[10, 10]} className="mt-30">
                  <Col xxl={8} xl={8} lg={8} md={8} sm={8} xs={12}>
                    <Text title={"Scheduled"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.demo_schedule.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>

                  <Col xxl={8} xl={8} lg={8} md={8} sm={8} xs={14}>
                    <Text title={"Attended"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.demo_attended.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>

                  <Col xxl={8} xl={8} lg={8} md={8} sm={8} xs={14}>
                    <Text title={"Registered"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text
                      title={settings?.student_registered.toString() || "0"}
                      size={"S"}
                      font={"SEMIBOLD"}
                      color={"BLACK02"}
                    />
                  </Col>
                </Row>
              </div>
            </Col>

            <Col xxl={8} xl={8} lg={12} md={24} sm={24} xs={24}>
              <div className={["p-20", styles.acquisition].join(" ")} style={bgColorAcquisition}>
                <Text title={"TP student"} font={"NORMAL"} color={"HEADING"} />
                <Text title={"retention"} font={"NORMAL"} color={"HEADING"} />

                <Row gutter={[10, 10]} className="mt-30">
                  <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={12}>
                    <Text title={"Basic Retention"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text title={`${settings?.basic_retention || 0}%`} size={"S"} font={"SEMIBOLD"} color={"BLACK02"} />
                  </Col>

                  <Col xxl={12} xl={12} lg={12} md={12} sm={12} xs={12}>
                    <Text title={"Score Retention"} lHeight={"M"} size={"S"} font={"LIGHTER"} color={"BLACK02"} />
                    <Text title={`${settings?.score_retention || 0}%`} size={"S"} font={"SEMIBOLD"} color={"BLACK02"} />
                  </Col>
                </Row>
              </div>
            </Col>
          </Row>
        </div>

        {formData.map(form => (
          <div className={"white_box p-24 my-20"}>
            <Text title={form.title} color="HEADING" font="NORMAL" size="M" className="mb-24" />

            <Row gutter={[10, 20]}>
              {form.sub_categories.map(subCategory => (
                <Col span={24}>
                  <Form
                    data={subCategory}
                    isDisabled={isEditDisabled}
                    setFormValues={setFormData}
                    formValues={formData}
                  />
                </Col>
              ))}
            </Row>
          </div>
        ))}

        {!isEditDisabled && (
          <div className={styles.button}>
            <Button onClick={handleSubmit} loading={isLoading} type="tertiary">
              {"Submit"}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherManagerReport;
