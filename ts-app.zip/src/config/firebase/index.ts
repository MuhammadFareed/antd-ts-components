// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getMessaging, getToken, onMessage, isSupported } from "firebase/messaging";
import { storeFCMToken } from "src/services/payments";

const { REACT_APP_WEB_PUSH_KEY } = process.env;
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

const webKey = REACT_APP_WEB_PUSH_KEY;

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAqhVveKgOisDipvFM3NOLT2xUi9Kj_1cE",
  authDomain: "teacher-app-dotnline.firebaseapp.com",
  projectId: "teacher-app-dotnline",
  storageBucket: "teacher-app-dotnline.appspot.com",
  messagingSenderId: "825405393324",
  appId: "1:825405393324:web:7f95bb67efe72adc61d209",
  measurementId: "G-1D38K4B4PL",
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);

export const onMessageListener = () =>
  new Promise(resolve => {
    const messaging = getMessaging(firebaseApp);
    onMessage(messaging, payload => {
      resolve(payload);
    });
  });

export const getFcmToken = async () => {
  const messaging = getMessaging(firebaseApp);
  return await getToken(messaging, {
    vapidKey: webKey,
  });
};

export const requestPermission = async () => {
  const supported = await isSupported();

  if (supported) {
    Notification.requestPermission()
      .then(permission => {
        if (permission === "granted") {
          getFcmToken().then(token => {
            if (token) {
              storeFCMToken(token);
            }
          });
        } else {
          console.warn("Notification permission denied.");
        }
      })
      .catch(error => {
        console.error("Error requesting notification permission:", error);
      });
  }
};

export { firebaseApp, onMessage };
