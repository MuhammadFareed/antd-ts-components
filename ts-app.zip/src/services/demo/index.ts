import { getRequest, postRequest } from "src/config/networks";
import apiEndpoints from "src/config/api-endpoints";
import { IEnrolDemo, IUpdateDemoStatusRequest, IRescheduledDemo } from "@type/demos";
// import axiosInstance from "src/config/axiosInstance";

export const getDemos = async (params: string) => {
  try {
    return await getRequest(`${apiEndpoints.GET_TEACHER_DEMOS}?${params}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const updateDemoStatus = async (data: IUpdateDemoStatusRequest) => {
  try {
    return await postRequest(apiEndpoints.UPDATE_DEMO_STATUS, data, true);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getChildrens = async (parentId: number) => {
  try {
    return await getRequest(`${apiEndpoints.GET_CHILDREN}/${parentId}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getTeacherPackages = async () => {
  try {
    return await getRequest(`${apiEndpoints.GET_TEACHER_PACKAGES}?limit=100&is_approved=1`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getDemoSummary = async () => {
  try {
    return await getRequest(`${apiEndpoints.GET_DEMO_SUMMARY}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const enrolDemo = async (data: IEnrolDemo) => {
  try {
    return await postRequest(`${apiEndpoints.ENROL_DEMO}`, data, true);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const rescheduledDemo = async (demoId: number, data: IRescheduledDemo) => {
  try {
    return await postRequest(`${apiEndpoints.RESCHEDULED_DEMO}/${demoId}`, data, true);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getSchedule = async () => {
  try {
    return await getRequest(`${apiEndpoints.TEACHER_SCHEDULE}`);
  } catch (e) {
    return Promise.reject(e);
  }
};
