import { getRequest, postRequest } from "src/config/networks";
import apiEndpoints from "src/config/api-endpoints";
import { convertObjToQueryString } from "src/utils";
import { UploadReceiptData } from "@type/payments";

export const getInvoiceSummary = async () => {
  try {
    return await getRequest(apiEndpoints.GET_INVOICE_SUMMARY);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getPayments = async (params?: object) => {
  try {
    const query = convertObjToQueryString(params || {});
    return await getRequest(`${apiEndpoints.GET_INVOICE}?${query}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const uploadReceipt = async (data: UploadReceiptData) => {
  try {
    const formData = new FormData();

    formData.append("invoice_id", data.invoice_id);
    formData.append("receipt", data.receipt as never);

    return await postRequest(`${apiEndpoints.UPLOAD_RECEIPT}`, formData, true, {
      "Content-Type": "multipart-formdata",
    });
  } catch (e) {
    return Promise.reject(e);
  }
};

export const storeFCMToken = async (token: string) => {
  try {
    return await postRequest(`${apiEndpoints.UPDATE_TOKEN}`, { token });
  } catch (e) {
    return Promise.reject(e);
  }
};
