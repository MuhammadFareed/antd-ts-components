export * as authServices from "./auth";
export * as profileServices from "./profile";
export * as generalServices from "./general";
export * as packageServices from "./package";
export * as demoServices from "./demo";
export * as paymentServices from "./payments";
export * as teacherManagerServices from "./teacher-manager";
export * as learningServices from "./learning";
