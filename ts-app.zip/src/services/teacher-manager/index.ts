import { getRequest, postRequest } from "src/config/networks";
import apiEndpoints from "src/config/api-endpoints";
import { convertObjToQueryString } from "src/utils";
import { IReportData } from "src/types/teacher-manager";
import moment from "moment-timezone";

export const getTeacherManager = async (params?: object) => {
  try {
    const query = convertObjToQueryString(params || {});
    return await getRequest(`${apiEndpoints.GET_TEACHER_MANAGER}?${query}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getEvaluationReportForm = async () => {
  try {
    return await getRequest(`${apiEndpoints.GET_TEACHER_EVALUATION_REPORT}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getTeacherEvaluation = async (teacherId: number, page: number) => {
  try {
    return await getRequest(`${apiEndpoints.GET_TEACHER_EVALUATION_REPORT}/${teacherId}?page=${page}&limit=5`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getTeacherEvaluationDetails = async (teacherId?: number) => {
  try {
    const date = moment().format("YYYY-MM-DD");
    return await getRequest(
      `${apiEndpoints.GET_EVALUATION_REPORT_DETAILS}?teacher_id=${teacherId}&report_date=${date}`,
    );
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getEvaluationReport = async (reportId: number) => {
  try {
    return await getRequest(`${apiEndpoints.VIEW_EVALUATION_REPORT}/${reportId}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const createReport = async (data: IReportData) => {
  try {
    return await postRequest(`${apiEndpoints.CREATE_EVALUATION_REPORT}`, data);
  } catch (e) {
    return Promise.reject(e);
  }
};
