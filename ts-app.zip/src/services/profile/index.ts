import { store } from "src/store";
import {
  AxiosResponseData,
  BankDetails,
  BankFormData,
  ChangePasswordFormData,
  Profile,
  ProfileFormData,
  ProgressTrackerData,
  WhatsNewData,
} from "@type/index";
import { message } from "antd";
import { AxiosResponse } from "axios";
import { cloneDeep } from "lodash";
import apiEndpoints from "src/config/api-endpoints";
import { getRequest, postRequest } from "src/config/networks";
import { axiosErrorHandler, convertObjToQueryString } from "src/utils";

export const getProfile = (teacherId?: number) => {
  return new Promise<Profile>((resolve, reject) => {
    (async () => {
      try {
        const endpoint = `${apiEndpoints.GET_PROFILE}/${teacherId}`;
        const response: AxiosResponse = await getRequest(endpoint);
        const profile: Profile = cloneDeep(response.data.data);
        resolve(profile);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const changePassword = (values: ChangePasswordFormData) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const tempData = {
          old_password: values.oldPassword,
          password: values?.newPassword,
          confirm_password: values?.confirmPassword,
        };
        const response: AxiosResponse = await postRequest(apiEndpoints.CHANGE_PASSWORD, tempData);
        const data: AxiosResponseData = response.data;
        if (data?.status === "success" && data?.message) {
          message.success(data?.message);
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const getProgressTracker = () => {
  return new Promise<ProgressTrackerData>((resolve, reject) => {
    (async () => {
      try {
        const response: AxiosResponse = await getRequest(apiEndpoints.GET_PROGRESS_TRACKER);
        const data: ProgressTrackerData = cloneDeep(response.data.data);
        resolve(data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const getBankDetails = () => {
  return new Promise<BankDetails>((resolve, reject) => {
    (async () => {
      try {
        const response: AxiosResponse = await getRequest(apiEndpoints.GET_BANK_DETAILS);
        const data: BankDetails = cloneDeep(response.data.data);
        resolve(data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const getWhatsNewData = () => {
  return new Promise<WhatsNewData[]>((resolve, reject) => {
    (async () => {
      try {
        const obj = { per_page: 50 };
        const queryString = convertObjToQueryString(obj);
        const endpoint = `${apiEndpoints.GET_ALL_WHATS_NEW}?${queryString}`;
        const response: AxiosResponse = await getRequest(endpoint);
        const whatsNewData: WhatsNewData[] = response?.data?.data?.data?.map((item: any) => {
          return {
            id: item?.id,
            teacher_id: item?.teacher_id,
            title: item?.title,
            description: item?.description,
            image: item?.image,
          };
        });
        resolve(whatsNewData);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const updateBankDetails = (values: BankFormData, teacherId?: number) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      const payload = {
        teacher_id: teacherId,
        bank_name: values?.bankName,
        account_title: values?.accountTitle,
        account_number: values?.accountNumber,
        account_iban: values?.iban,
        swift_code: values?.swiftCode,
      };
      try {
        const { data }: AxiosResponse = await postRequest(apiEndpoints.STORE_BANK_DETAILS, payload);
        if (data?.statusCode === Number(200)) {
          message.success(data?.message);
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const updateProfile = (values: ProfileFormData) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const params: any = {
          dob: values?.dob,
          phone: values?.phone,
          subjects: values?.subjects,
          address: values?.address,
          cnic: values?.cnic,
          bio: values?.bio,
          level: values?.academicLevel,
          discipline: values?.qualification,
          tagline: values?.tagLine,
          country: values?.country,
          city: values?.city,
          area: values?.area,
          years_of_experience: values?.experience,
        };

        const formData = new FormData();
        Object.keys(params).forEach((key: string) => {
          const element = params[key];
          if (element) {
            if (Array.isArray(element)) {
              for (let i = 0; i < element?.length; i++) {
                formData.append(`${key}[${i}]`, element[i]);
              }
            } else {
              formData.append(key, element);
            }
          }
        });
        formData.append("profilePhoto", values?.profilePhoto);
        formData.append("demo_video", values.demoVideo);
        const userId = store?.getState()?.auth?.user?.user?.id;
        const endpoint = `${apiEndpoints.UPDATE_USER_BY_ID}/${userId}`;
        const headers = { "Content-Type": "multipart/form-data" };
        const response: AxiosResponse = await postRequest(endpoint, formData, true, headers);
        const data: AxiosResponseData = response.data;
        if (data?.statusCode === Number(200)) {
          message.success("Profile updated successfully!");
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};
