import {
  BaselineFormData,
  CertificateValues,
  CourseTopic,
  CreatePackageFormData,
  EnrollmentsData,
  LearningOutcome,
  Package,
  PackagesData,
  ProgressReportForm,
  TimeSlot,
  TransferRequest,
  UpdateEnrollStatusForm,
} from "@type/index";
import { message } from "antd";
import { AxiosResponse } from "axios";
import { cloneDeep } from "lodash";
import moment from "moment-timezone";
import apiEndpoints from "src/config/api-endpoints";
import { getRequest, postRequest } from "src/config/networks";
import { dateFormat } from "src/constant";
import { convertObjToQueryString } from "src/utils";
import { axiosErrorHandler } from "src/utils";

export const createPackage = (values: CreatePackageFormData, edit?: boolean, packageId?: string) => {
  return new Promise<string>((resolve, reject) => {
    (async () => {
      const isCourse = Number(values?.program) === 3;
      // const isOnline = values?.packageMode === "online";
      try {
        const params: any = {
          program_id: values?.program,
          subjects: values?.subjects,
          package_mode: values?.packageMode,
          start_date: values?.startDate,
          // is_recurring: values?.recurring,
          end_date: values?.endDate,
          enrollment_mode: values?.enrolmentMode,
          grades: values?.grades,
          min_age: values?.minAge,
          max_age: values?.maxAge,
          access_mode: values?.accessMode,
          title: values?.packageTitle,
          teacher_intro: values?.teacherIntro,
          description: values?.description,
          time_zone: values?.timeZone,
          zoom_link: values?.zoomLink,
          amount: values?.localMonthlyFee,
          int_amount: values?.internationalMonthlyFee,
          type: isCourse ? "course" : "subject",
          days: [],
          timeslot: [],
          start_time: [],
          end_time: [],
          demo_status: [],
          seats: [],
        };
        if (isCourse) {
          params.course = values?.subjects;
          delete params["subjects"];
        } else {
          delete params["end_date"];
        }
        if (edit) {
          delete params["zoom_link"];
          delete params["days"];
          delete params["timeslot"];
          delete params["start_time"];
          delete params["end_time"];
          delete params["demo_status"];
          delete params["seats"];
        } else {
          values?.timeSlots?.forEach((item: TimeSlot) => {
            params.days.push(item?.days);
            params.timeslot.push(item?.timeSlot);
            params.start_time.push(item?.startTime);
            params.end_time.push(item?.endTime);
            params.demo_status.push(item?.openForDemo);
            params.seats.push(item?.totalSeats);
          });
        }
        // if (isOnline) {
        //   delete params["zoom_link"];
        // }
        const formData = new FormData();
        Object.keys(params).forEach((key: string) => {
          const element = params[key];
          if (element) {
            if (Array.isArray(element)) {
              for (let i = 0; i < element?.length; i++) {
                if (Array.isArray(element[i])) {
                  for (let j = 0; j < element[i]?.length; j++) {
                    formData.append(`${key}[${i}][${j}]`, element[i][j]);
                  }
                } else {
                  formData.append(`${key}[${i}]`, element[i]);
                }
              }
            } else if (typeof element === "object" && Object.keys(element)?.length === 0) {
              formData.append(key, "");
            } else {
              formData.append(key, element);
            }
          }
        });
        formData.append("image", values?.packageCoverImage);
        formData.append("course_outline_pdf", values?.courseOutlinePDF);
        values?.topics.forEach((el: CourseTopic, index: number) => {
          formData.append(`about_the_course[${index}][topic_name]`, el.topicName);
          formData.append(`about_the_course[${index}][topic_description]`, el.topicDescription);
        });
        values?.learningOutcomes.forEach((el: LearningOutcome, index: number) => {
          formData.append(`learning_outcome[${index}]`, el.value);
        });
        const headers = { "Content-Type": "multipart/form-data" };
        const endpoint = edit ? `${apiEndpoints.UPDATE_PACKAGE}/${packageId}` : apiEndpoints.CREATE_PACKAGE;
        try {
          const { data }: AxiosResponse = await postRequest(endpoint, formData, true, headers);
          resolve(`/packages/${data?.data?.id}`);
        } catch (e) {
          axiosErrorHandler(e);
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const getPackages = (queryObj: Record<string, string | number>) => {
  return new Promise<PackagesData>((resolve, reject) => {
    (async () => {
      try {
        const queryParams = convertObjToQueryString(queryObj);
        const endpoint = `${apiEndpoints.GET_PACKAGES}?${queryParams}`;
        const { data }: AxiosResponse = await getRequest(endpoint);
        if (data?.data?.data) {
          const payloadObj: PackagesData = {
            packages: cloneDeep(data?.data?.data),
            currentPage: data?.data?.meta?.current_page,
            perPage: data?.data?.meta?.per_page,
            total: data?.data?.meta?.total,
            loadingPackages: false,
          };
          resolve(payloadObj);
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const fetchPackageDetails = (packageId?: string) => {
  return new Promise<Package>((resolve, reject) => {
    (async () => {
      try {
        const endpoint = `${apiEndpoints.GET_PACKAGE}/${packageId}`;
        const { data }: AxiosResponse = await getRequest(endpoint);
        resolve(data?.data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const fetchEnrollments = (packageId?: string) => {
  return new Promise<EnrollmentsData>((resolve, reject) => {
    (async () => {
      try {
        const endpoint = `${apiEndpoints.GET_ENROLLMENTS}/${packageId}`;
        const { data }: AxiosResponse = await getRequest(endpoint);
        resolve(data?.data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const createBaselineForm = (values: BaselineFormData) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const params = {
          teacherId: values?.teacherId,
          studentId: values?.studentId,
          board: values?.board === "Other" ? values?.otherBoard : values?.board,
          have_joined: values?.haveJoined,
          behavioural_goals: values?.behaviouralGoals,
          milestones: values?.milestones,
          personality: values?.personality,
          interest: values?.interest,
          teaching_style: values?.teachingStyle,
          class_time: values?.classTime,
          grade: values?.grade,
          academic_goal: values?.academicGoal,
          exam_pattern: values?.examPattern,
          area_of_interest: values?.areaOfInterest,
        };
        const { data }: AxiosResponse = await postRequest(apiEndpoints.CREATE_BASELINE_FORM, params);
        if (data?.status === "success") {
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const sendProgressReport = (values: ProgressReportForm, isPrimary: boolean) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        let params = {};
        if (isPrimary) {
          params = {
            teacher_id: values?.teacherId,
            student_id: values?.studentId,
            enroll_id: values?.enrollId,
            grade: values?.grade,
            attendance: values?.attendence,
            attendance_total: values?.attendenceTotal,
            strengths: values?.strengths,
            challenges: values?.challenges,
            behavioural_brief: values?.behavioralBrief,
            monthly_assessment: values?.monthlyAssessment,
            score: values?.score,
            score_total: values?.scoreTotal,
          };
        } else {
          params = {
            teacher_id: values?.teacherId,
            student_id: values?.studentId,
            enroll_id: values?.enrollId,
            grade: values?.grade,
            attendance: values?.attendence,
            attendance_total: values?.attendenceTotal,
            milestone: values?.milestone,
            knowledge: values?.knowledge,
            time_management: values?.timeManagement,
            challenges: values?.challenges,
            monthly_assessment: values?.monthlyAssessment,
            score: values?.score,
            score_total: values?.scoreTotal,
          };
        }
        const { data }: AxiosResponse = await postRequest(apiEndpoints.SEND_PROGRESS_REPORT, params);
        if (data?.stauts === "success") {
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const updateEnrollStatus = (values: UpdateEnrollStatusForm, enrollId: number) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const params: any = {
          status: values?.status,
          date: values?.date,
          reason: values?.reason,
        };
        if (values?.status === "break") {
          params.break_start = values?.startDate;
          params.break_end = values?.endDate;
        }
        const endpoint = `${apiEndpoints.UPDATE_ENROLL_STATUS}/${enrollId}`;
        const { data }: AxiosResponse = await postRequest(endpoint, params);
        if (data?.status === "success" && data?.message) {
          message.success(data?.message);
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const fetchTopPackages = () => {
  return new Promise<Package[]>((resolve, reject) => {
    (async () => {
      try {
        const { data }: AxiosResponse = await getRequest(apiEndpoints.GET_TOP_PACKAGES_OF_LAST_MONTH);
        resolve(data?.data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const updatePackageStatus = (packageId: number, type: string) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const endpoint = `${apiEndpoints.UPDATE_PACKAGE_STATUS}/${packageId}`;
        const { data }: AxiosResponse = await postRequest(endpoint, { package_type: type });
        if (data && data?.message) {
          message.success(data?.message);
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const deletePackage = (packageId: number) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const endpoint = `${apiEndpoints.DELETE_PACKAGE}/${packageId}`;
        const { data }: AxiosResponse = await postRequest(endpoint);
        if (data && data?.message) {
          message.success(data?.message);
        }
        resolve();
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const getTeacherPackages = async (teacherId?: number) => {
  try {
    return await getRequest(`${apiEndpoints.GET_TEACHER_PACKAGES_ID}/${teacherId}`);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getTeachers = async (name?: string) => {
  try {
    const teacherName = name ? `?name=${name}` : "";
    const { data } = await getRequest(`${apiEndpoints.GET_TEACHERS}${teacherName}`);
    return data as never;
  } catch (e) {
    return Promise.reject(e);
  }
};

export const sendCertificate = (values: CertificateValues, certificateFile: File) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const params: any = {
          date: moment()?.format(dateFormat),
          teacher_id: values?.teacherId,
          student_id: values?.studentId,
          enroll_id: values?.enrollId,
          student_name: values?.studentName,
          for: values?.for,
          certificate_type: values?.certificateType,
          master_level: values?.masterLevel,
        };
        const formData = new FormData();
        Object.keys(params).forEach((key: string) => {
          formData.append(key, params[key]);
        });
        formData.append("certificate", certificateFile);
        const headers = { "Content-Type": "multipart/form-data" };
        const { data }: AxiosResponse = await postRequest(apiEndpoints.CREATE_CERTIFICATE, formData, true, headers);
        if (data && data?.status === "success") {
          resolve();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const postTransferRequest = async (requestData: TransferRequest) => {
  try {
    return await postRequest(`${apiEndpoints.EVALUATION_REPORT}`, requestData);
  } catch (e) {
    return Promise.reject(e);
  }
};

export const getEnrolmentById = async (id: string) => {
  try {
    return await getRequest(`${apiEndpoints.GET_ENROLMENT_BY_ID}/${id}`);
  } catch (e) {
    return Promise.reject(e);
  }
};
