import { LearningResources, PremiumResources } from "@type/index";
import { AxiosResponse } from "axios";
import apiEndpoints from "src/config/api-endpoints";
import { getRequest } from "src/config/networks";
import { axiosErrorHandler, convertObjToQueryString } from "src/utils";

export const getPremiumResources = (queryObj: Record<string, string | number> = {}) => {
  return new Promise<PremiumResources>((resolve, reject) => {
    (async () => {
      try {
        const queryParams = convertObjToQueryString(queryObj);
        const endpoint = `${apiEndpoints.GET_PREMIUM_RESOURCES}?${queryParams}`;
        const { data }: AxiosResponse = await getRequest(endpoint);
        resolve(data?.data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const getLearningResources = () => {
  return new Promise<LearningResources>((resolve, reject) => {
    (async () => {
      try {
        const { data }: AxiosResponse = await getRequest(apiEndpoints.GET_LEARNING_RESOURCES);
        const learningResouces: LearningResources = {
          codingResources: data?.data?.coding,
          expressResources: data?.data?.expressResources,
          expressResourceSubjects: data?.data?.expressResourcesSubjects,
          outlineAssessments: data?.data?.outlineAssessment,
          outlineAssessmentSubjects: data?.data?.outlineAssessmentsubjects,
          premiumResourceSubjects: data?.data?.premiumResourcesSubjects,
          trainingPhases: data?.data?.trainingPhases,
        };
        resolve(learningResouces);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};
