import { AxiosLoginData, AxiosResponseData, ForgotPasswordFormData, LoggedInUser, LoginFormData } from "@type/index";
import { message } from "antd";
import { AxiosResponse } from "axios";
import { cloneDeep } from "lodash";
import apiEndpoints from "src/config/api-endpoints";
import { postRequest } from "src/config/networks";
import { axiosErrorHandler } from "src/utils";

export const login = (values: LoginFormData) => {
  return new Promise<LoggedInUser>((resolve, reject) => {
    (async () => {
      try {
        const tempData = {
          role: "teacher",
          email: values?.email,
          password: values?.password,
        };
        const withAuth = false;
        const response: AxiosResponse = await postRequest(apiEndpoints.LOGIN, tempData, withAuth);
        const data: AxiosLoginData = response.data;
        if (data?.status === "success" && data?.message && data?.data) {
          message.success(`Logged in as ${data?.data?.user?.name} successfully.`);
          const userData: LoggedInUser = cloneDeep(data?.data);
          resolve(userData);
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const logout = () => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const response: AxiosResponse = await postRequest(apiEndpoints.LOG_OUT);
        const data: AxiosResponseData = response.data;
        if (data?.status === "success") {
          message.success(data?.message);
          resolve();
        } else {
          message.error("Something went wrong. Please try again.");
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const forgotPassword = (values: ForgotPasswordFormData) => {
  return new Promise<void>((resolve, reject) => {
    (async () => {
      try {
        const params = {
          email: values?.email,
        };
        const withAuth = false;
        const { data }: AxiosResponse = await postRequest(apiEndpoints.FORGOT_PASSWORD, params, withAuth);
        if (data?.status === "success") {
          message.success(data?.message);
          resolve();
        } else {
          reject();
        }
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};
