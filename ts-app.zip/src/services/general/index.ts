import { CountryData, CreatePackageSubjects, DomainParameters } from "@type/index";
import { AxiosResponse } from "axios";
import { cloneDeep } from "lodash";
import apiEndpoints from "src/config/api-endpoints";
import { getRequest } from "src/config/networks";
import { axiosErrorHandler } from "src/utils";

export const fetchCountries = () => {
  return new Promise<CountryData[]>((resolve, reject) => {
    (async () => {
      try {
        const response: AxiosResponse = await getRequest(apiEndpoints.GET_COUNTRIES);
        const countries: CountryData[] = cloneDeep(response.data.data);
        resolve(countries);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const fetchAllDomainParameters = () => {
  return new Promise<DomainParameters>((resolve, reject) => {
    (async () => {
      try {
        const response: AxiosResponse = await getRequest(apiEndpoints.GET_ALL_DOMAIN_PARAMETERS);
        const data: DomainParameters = cloneDeep(response?.data?.data);
        resolve(data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};

export const fetchAllSubjects = () => {
  return new Promise<CreatePackageSubjects>((resolve, reject) => {
    (async () => {
      try {
        const response: AxiosResponse = await getRequest(apiEndpoints.GET_ALL_SUBJECTS);
        const data: CreatePackageSubjects = cloneDeep(response?.data?.data);
        resolve(data);
      } catch (error) {
        axiosErrorHandler(error);
        reject();
      }
    })();
  });
};
