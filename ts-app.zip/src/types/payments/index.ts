import { UploadFile } from "antd";

export interface IInvoice {
  id: number;
  transaction_id: string;
  payment_method: string;
  conversion_rate: number;
  student_id: number;
  amount: number;
  discount: number;
  invoice_date: string;
  receipt: null;
  due_date: string;
  paid_at: null;
  share_transfer_at: null;
  link: string;
  payment_status: string;
  status: number;
  created_at: string;
  updated_at: string;
  email_reminder_status: number;
  courier_service_type: null;
  courier_service_status: null;
  consumer_no: null;
  delivery_charges: null;
  request_delivery_date: null;
  deleted_at: null;
  currency: string;
  card_id: null;
  penalty: null;
  comment: null;
  payment_link: string;
  payment_receipt: string;
  payments: Payment[];
  student: Student;
}

export interface UploadReceiptData {
  invoice_id: string;
  receipt: UploadFile<any>;
}

export interface Payment {
  id: number;
  student_enroll_id: number;
  student_id: number;
  base_fee: number;
  amount: number;
  teacher_discount: number;
  dnl_discount: number;
  teacher_share: number;
  dnl_share: number;
  no_of_days: number;
  payment_date: string;
  payment_status: string;
  payment_type: string;
  is_half: number;
  created_by: number;
  invoice_id: number;
  emailSend: number;
  collected_at: null;
  created_at: string;
  updated_at: string;
  deleted_at: null;
  pivot: PaymentPivot;
  enroll: Enroll;
}

export interface Enroll {
  id: number;
  student_id: number;
  teacher_id: number;
  program_id: number;
  teacher_package_id: number;
  slot_id: number;
  student_type: string;
  registration_date: string;
  joining_date: string;
  dropout_date: null;
  dropout_reason: null;
  subscription: string;
  fee_version: string;
  pricing_type: string;
  promo_code_id: null;
  discount: number;
  isSubsidised: number;
  learningPack: number;
  program_type: string;
  non_paying: number;
  en_lesson_id: number;
  en_level_id: number;
  math_level_id: number;
  grade_id: number;
  last_paid: null;
  gen_date: string;
  due_date: string;
  alumni_date: string;
  cpay_date: null;
  break_start: null;
  break_end: null;
  deal_id: number;
  deleted_at: null;
  created_at: string;
  updated_at: string;
  source: string;
  lead_source_id: null;
  payment_type: string;
  referral_code_id: null;
  old_enroll_id: null;
  package: Package;
}

export interface Package {
  id: number;
  title: string;
  description: null;
  program_id: number;
  amount: number;
  teacher_id: number;
  type: string;
  package_mode: string;
  status: number;
  course_id: null;
  deleted_at: null;
  created_at: string;
  updated_at: string;
  min_age: number;
  max_age: number;
  enrollment_mode: string;
  image: string;
  int_amount: number;
  start_date: string;
  access_mode: string;
  is_approved: number;
  about_the_course: string;
  learning_outcome: string;
  teacher_intro: string;
  course_outline_pdf: null;
  package_type: string;
  subjects: Subject[];
  teacher: PackageTeacher;
  time_slots: TimeSlot[];
  program: Program;
  course: null;
  grades: Grade[];
}

export interface Grade {
  id: number;
  title: string;
  created_at: string;
  updated_at: null;
  sort_order: number;
  age_range: string;
  level: string;
  pivot: GradePivot;
}

export interface GradePivot {
  package_id: number;
  grade_id: number;
}

export interface Program {
  id: number;
  name: string;
  status: number;
  created_at: string;
  updated_at: string;
  has_category: number;
}

export interface Subject {
  id: number;
  subject: string;
  status: number;
  program_id: number;
  created_at: string;
  updated_at: string;
  level: string;
  pivot: SubjectPivot;
}

export interface SubjectPivot {
  package_id: number;
  subject_id: number;
  created_at: string;
  updated_at: string;
}

export interface PackageTeacher {
  id: number;
  name: string;
  email: string;
  picture: string;
  fcm_token: null;
  status: number;
  isBlocked: number;
  last_activity: string;
  last_login: string;
  last_login_admin: string;
  login_count_admin: number;
  created_at: string;
  updated_at: string;
  user_type: string;
  is_test: number;
  area_manager: number;
  created_by: null;
  updated_by: null;
  designation: null;
  last_name: string;
  student_grades: null;
  login_type: string;
  uuid: null;
  house_floor: null;
  building: null;
  address: null;
  on_boarding: null;
  area: null;
  city: null;
  country: null;
  postal_code: null;
  stripe_id: null;
  card_brand: null;
  card_last_four: null;
  trial_ends_at: null;
  source: null;
  teacher: TeacherTeacher;
}

export interface TeacherTeacher {
  id: number;
  rating: null;
  area: string;
  city: string;
  country: string;
  bio: string;
  tagline: string;
  user_id: number;
  area_manager_id: number;
  subject_id: null;
  captain_id: number;
  referred_by: null;
  tier: string;
  higherGrades: number;
  isExpress: number;
  isOnline: number;
  isOffline: number;
  isSuper: number;
  assignDemos: number;
  internationalDemos: number;
  tpStatus: string;
  created_at: string;
  updated_at: string;
  recruitedDate: null;
  trainingCompletionDate: null;
  lastDate: string;
  leavingReason: string;
  dob: string;
  demo_video: string;
  long_term_plans: null;
  computer_litearcy: number;
  communication_skills: number;
  years_of_experience: number;
  latest_degree: string;
  assigned_per: number;
  scheduled_per: number;
  registered_per: number;
  avg_per: number;
  retention_basic_score: number;
  retention_score: number;
  retention_status: string;
  conversion: string;
  isDemoSettingsSet: number;
  isApptScheduleSet: number;
  isNewTP: number;
  active_student_count: number;
  international_student_count: number;
  qualification_level_id: number;
  qualification_id: number;
  social_skills: number;
  confidence_skills: number;
  creative_skills: number;
  emotional_skills: number;
  avg_month_conversion: number;
  subjects: string[];
  is_graduated: number;
  new_share_percent: number;
}

export interface TimeSlot {
  id: number;
  teacher_package_id: number;
  time_slot: string;
  start_time: string;
  end_time: string;
  hours_per_week: number;
  days: string;
  demo_status: number;
  seats: number;
  zoom_link: string;
  status: number;
  created_at: string;
  updated_at: string;
  time_zone: string;
  deleted_at: null;
  enrollCount: number;
}

export interface PaymentPivot {
  invoice_id: number;
  payment_id: number;
  created_at: string;
  updated_at: string;
}

export interface Student {
  id: number;
  old_id: null;
  name: string;
  dob: string;
  school: string;
  board: string;
  level: string;
  gender: string;
  mobile: string;
  landline: null;
  city: string;
  country: string;
  source_of_registration: string;
  emergency_contact_name: null;
  emergency_contact_number: null;
  address: string;
  parent_id: number;
  is_test: number;
  image: null;
  status: string;
  payment_mode: string;
  invoice_date: null;
  created_by: null;
  updated_by: null;
  created_at: string;
  updated_at: string;
  avatar: null;
  parent: Parent;
}

export interface Parent {
  id: number;
  name: string;
  email: string;
  picture: null;
  fcm_token: null;
  status: number;
  isBlocked: number;
  last_activity: null;
  last_login: null;
  last_login_admin: string;
  login_count_admin: number;
  created_at: string;
  updated_at: string;
  user_type: string;
  is_test: number;
  area_manager: number;
  created_by: number;
  updated_by: null;
  designation: string;
  last_name: null;
  student_grades: null;
  login_type: string;
  uuid: string;
  house_floor: null;
  building: null;
  address: null;
  on_boarding: null;
  area: null;
  city: string;
  country: string;
  postal_code: null;
  stripe_id: null;
  card_brand: null;
  card_last_four: null;
  trial_ends_at: null;
  source: null;
  teacher: ParentTeacher;
}

export interface ParentTeacher {
  user_id: number;
  new_share_percent: number;
}

export interface IInvoiceSummary {
  total_invoices: number;
  total_paid: string;
  total_unpaid: string;
  total_earnings_pkr: number;
  total_earnings_usd: number;
  pending: string;
}
