import { Package, Program, Slot } from "@type/demos";
import { Student } from "@type/payments";
import { ReactNode } from "react";
import { ProfileReview, RadioGroupOption } from "..";

export type TeacherTier = "1" | "2";
export enum IToggle {
  ON = 1,
  OFF = 0,
}
export enum IFormType {
  CHECKBOX = "checkbox",
  RATING = "rating",
  INSERTABLE = "insert_able",
}

export interface IReportData {
  settings: Settings;
  teacher_id: number;
  report_date: string;
  evalReportDetails: IFormValues[];
  isSendEmail: boolean;
}

export interface Report {
  details: ReportDetail[];
  ratings: string;
  settings: Settings;
}

export interface ViewReport {
  data: Report;
}

export interface ReportDetail {
  id: number;
  eval_report_id: number;
  category_id: number;
  sub_category_id: number;
  question_id: number;
  comment: null | string;
  rating: number | null;
  type: string;
  created_at: null;
  updated_at: null;
  deleted_at: null;
  evaluation_category: EvaluationCategory;
  evaluation_sub_category: EvaluationSubCategory;
  question: Question;
}

export interface EvaluationSubCategory {
  id: number;
  title: string;
  eval_category_id: number;
  type: string;
  has_comment: number;
  status: number;
  created_at: string;
  updated_at: string;
}

export interface TeacherManager {
  id: number;
  name: string;
  email: string;
  picture: string;
  area_manager_name: string;
  fcm_token: null;
  status: number;
  phone: string;
  active_students: number;
  isBlocked: number;
  last_activity: string;
  last_login: string;
  last_login_admin: string;
  login_count_admin: number;
  created_at: string;
  updated_at: string;
  user_type: string;
  is_test: number;
  area_manager: number;
  created_by: null;
  updated_by: null;
  designation: null;
  last_name: string;
  student_grades: null;
  login_type: string;
  uuid: null;
  house_floor: null;
  building: null;
  address: null;
  on_boarding: null;
  area: null;
  city: null;
  country: null;
  postal_code: null;
  stripe_id: null;
  card_brand: null;
  card_last_four: null;
  trial_ends_at: null;
  source: null;
  reviews: ProfileReview[];
  teacher: Teacher;
}

export interface Teacher {
  id: number;
  rating: null;
  area: string;
  city: string;
  country: string;
  bio: string;
  tagline: string;
  user_id: number;
  area_manager_id: number;
  subject_id: number;
  captain_id: number;
  referred_by: null;
  tier: string;
  higherGrades: number;
  isExpress: number;
  isOnline: number;
  isOffline: number;
  isSuper: number;
  assignDemos: number;
  internationalDemos: number;
  tpStatus: string;
  created_at: string;
  updated_at: string;
  recruitedDate: string;
  trainingCompletionDate: string;
  lastDate: null;
  leavingReason: null;
  dob: string;
  demo_video: string;
  long_term_plans: null;
  computer_litearcy: number;
  communication_skills: number;
  years_of_experience: number;
  latest_degree: null;
  assigned_per: number;
  scheduled_per: number;
  registered_per: number;
  avg_per: number;
  retention_basic_score: number;
  retention_score: number;
  retention_status: string;
  conversion: string;
  isDemoSettingsSet: number;
  isApptScheduleSet: number;
  isNewTP: number;
  active_student_count: number;
  international_student_count: number;
  qualification_level_id: number;
  qualification_id: number;
  social_skills: number;
  confidence_skills: number;
  creative_skills: number;
  emotional_skills: number;
  avg_month_conversion: number;
  subjects: string[];
  is_graduated: number;
  new_share_percent: number;
}

export interface EvaluationReportForm {
  id: number;
  title: string;
  status: IToggle;
  created_at: string;
  updated_at: string;
  sub_categories: SubCategory<Question>[];
}

export interface IEvaluationResponse {
  id: number;
  title: string;
  sub_categories: SubCategory<RadioGroupOption | IRadioData>[];
}

export interface SubCategory<T> {
  id: number;
  title: string;
  eval_category_id: number;
  type: IFormType;
  has_comment: IToggle;
  has_error: boolean;
  commentCount: number;
  limit: number;
  status: IToggle;
  comment: string;
  created_at: string;
  updated_at: string;
  selectedValues: string[];
  questions: T[];
}

export interface ITeacher {
  id: number;
  name: string;
  email: string;
  phone: string;
  picture: string;
  address: string;
  city: string;
  country: string;
  area: string;
  dob: string;
  area_manager: AreaManager;
  tier: string;
  super_tutor: number;
  teacher_status: string;
  recruited_date: string;
  training_completion_date: string;
  bio: string;
  tagline: string;
  demo_video: null | string;
  latest_degree: null | string;
  avg_per: number;
  subjects: string[];
  ratings: string;
  qualification: Qualification | null;
  qualification_level: Qualification;
  is_new: number;
  joining_date: string;
  assignDemos: number;
  links: Links;
}

export interface IEnrolment {
  status: string;
  statusCode: number;
  message: string;
  data: Data;
}

export interface Data {
  id: number;
  student_id: number;
  teacher: AreaManager;
  program: Program;
  package: Package;
  slot: Slot;
  student: Student;
  student_type: string;
  registration_date: string;
  joining_date: string;
  gen_date: string;
  subscription: string;
  pricing_type: string;
  program_type: string;
  payment: null;
  demo: null;
  progress_reports: any[];
  base_line_forms: any[];
  certificates: any[];
}

export interface AreaManager {
  id: number;
  name: string;
  email: string;
  picture: string;
  address: null;
  house_floor: null;
  latest_degree: string;
  city: null;
  area: null;
  phone: string;
  postal_code: null;
  created_at: string;
}

export interface Links {
  self: string;
}

export interface Qualification {
  id: number;
  name: string;
  status: number;
  deleted_at: null;
  created_at: null;
  updated_at: null;
}

export interface IFormValues {
  categoryId: number;
  subCategoryId: number;
  questionId: string | number | undefined;
  comment: string;
  value: string | number;
  type: IFormType;
}

export interface IRadioData {
  id: number;
  title: string;
  selectedValue: string;
  options: RadioGroupOption[];
}

export interface Question {
  id: number;
  title: string;
  eval_sub_category_id: number;
  is_additional: number;
  status: IToggle;
  created_at: string;
  updated_at: string;
}

export interface IQuestion {
  id?: number | string;
  label?: ReactNode;
  value?: string;
  withSelect?: boolean;
  disabled?: boolean;
}

export interface EvaluationReport {
  id: number;
  teacher_id: number;
  created_by: number;
  report_date: string;
  comment: string;
  status: number;
  created_at: string;
  updated_at: string;
}

export interface IEvalReportPagination {
  current_page: number;
  data: EvaluationReport[];
  first_page_url: string;
  from: null;
  last_page: number;
  last_page_url: string;
  next_page_url: string;
  path: string;
  per_page: number;
  prev_page_url: null;
  to: number;
  total: number;
}

export interface EvaluationReportDetails {
  details: Detail[];
  ratings: string;
  settings: Settings;
}

export interface Detail {
  id: number;
  eval_report_id: number;
  category_id: number;
  sub_category_id: number;
  question_id: number | null;
  comment: string;
  rating: number;
  type: IFormType;
  created_at: string;
  updated_at: string;
  deleted_at: null;
  evaluation_category: EvaluationCategory;
  evaluation_sub_category: SubCategory<Question>;
  question: Question | null;
}

export interface EvaluationCategory {
  id: number;
  title: string;
  status: number;
  created_at: string;
  updated_at: string;
}

export interface Settings {
  takingDemo: string;
  demo_express_status: string;
  demo_express_grade: number;
  demo_premium_status: string;
  demo_premium_grade: number;
  student_active: number;
  student_dropout: number;
  student_signup: number;
  demo_schedule: number;
  demo_attended: number;
  student_registered: number;
  basic_retention: number;
  basic_bg: string;
  score_retention: number;
  score_bg: string;
  teacher_name: string;
}
