import { ReactNode } from "react";

export type NotificationType = "success" | "error" | "info";

export type Notifications =
  | "new_demo"
  | "new_badge"
  | "new_review"
  | "invoice_issued"
  | "comission_tranferred"
  | "demo_unattended"
  | "training_module"
  | "payment_received"
  | "package_comment"
  | "baseline_update";

export type INotificationData = {
  image?: any;
  cancelText?: string;
  handleCancel?: () => void;
  handleSuccess?: () => void;
  type?: NotificationType;
  title?: string;
  disableCancel?: boolean;
  show?: boolean;
  successText?: string;
  content: (e?: string) => ReactNode;
  disableClose?: boolean;
};

export interface Payload {
  from: string;
  messageId: string;
  notification: Notification;
  data: Data;
  fcmOptions: FcmOptions;
}

export interface Data {
  notification_type: Notifications;
}

export interface FcmOptions {
  link: string;
}

export interface Notification {
  title: string;
  body: string;
  icon: string;
}
