import { PackageTimeSlot } from "..";

export type IDealStage = "scheduled" | "attended" | "registered" | "rescheduled";

export type IStatus = "open" | "closed";
export type IDemoMode = "online" | "teacher_home" | "student_home";

export interface IEnrolDemo {
  package_id: number;
  slot_id: number;
  demo_id: number;
  student_id: string;
}

export interface IRescheduledDemo {
  slot_id: number;
  date: string;
}

export enum IPickerType {
  TIME = "time",
  DATE = "date",
}

export interface IUpdateDemoStatusRequest {
  dealstage: IDealStage;
  demo_id: string;
  comments?: string;
  demo_date: string;
  demo_time: string;
}

export interface IDemoSummary {
  total: number;
  scheduled: string;
  registered: string;
  attended: string;
  inactive: string;
  dealstage: string;
}

export interface IEnrolments {
  id: number;
  package: EnrolPackage;
  slot_id: number;
}

export interface EnrolPackage {
  id: number;
  title: string;
  description: string;
  time_slots: PackageTimeSlot[];
}

export type TeacherDemos = {
  id: number;
  name: null;
  dealstage: IDealStage;
  not_scheduled_reason: null;
  demo_date: string;
  demo_time: string;
  confirmed: number;
  meeting_link: string;
  attendee_meeting_link: string;
  demo_attended_date: null;
  demo_mode: IDemoMode;
  subject: null;
  comments: null;
  note: string;
  agent_comments: null;
  status: IStatus;
  lead_id: number;
  agent_id: number;
  teacher_id: number;
  scheduled_by: number;
  created_at: Date;
  updated_at: Date;
  priority: string;
  deleted_at: null;
  package_id: number;
  slot_id: number;
  time_zone: string;
  gmt: string;
  for: string;
  student_name: null;
  student_age: null;
  grade: null;
  register_at: null;
  student_transfer_request_id: null;
  parent_id: number;
  parent: Agent;
  teacher: Agent;
  agent: Agent;
  package: Package;
  slot: PackageTimeSlot;
  is_discount: boolean;
};

export interface ITeacherSchedule {
  schedule_demo: number;
  upcomming_demo: TeacherDemos[];
  upcomming_classes: IEnrolments[];
}

export type Agent = {
  id: number;
  name: string;
  email: string;
  picture: null | string;
  address: null;
  house_floor: null;
  latest_degree: null | string;
  city: null;
  area: null;
  phone: string;
  postal_code: null;
  created_at: Date | null;
};

export interface Subject {
  id: string;
  subject: string;
}

export type Package = {
  id: number;
  title: string;
  description: string;
  amount: number;
  int_amount: number;
  program: Program;
  teacher: PackageTeacher;
  type: string;
  package_mode: string;
  enrollment_mode: string;
  status: number;
  min_age: number;
  max_age: number;
  course: Course;
  subjects: Subject[];
  time_slot: PackageTimeSlot[];
  is_booked: number;
  grades: Grade[];
  demos_count: number;
  demo: Demo;
  image: string;
  is_new: number;
  links: Links;
};

export type Course = {
  id: number;
  title: string;
  base_fee: number;
  subscription: number;
  tpShare1: number;
  tpShare2: number;
  self_marketing_share: number;
  pricing_type: string;
  months_valid: number;
  status: number;
  created_at: Date;
  updated_at: Date;
  program: null;
  international_fee: number;
};

export type Demo = {
  id: number;
  name: null;
  dealstage: string;
  not_scheduled_reason: null;
  demo_date: Date;
  demo_time: string;
  confirmed: number;
  meeting_link: string;
  demo_attended_date: null;
  demo_mode: string;
  subject: null;
  comments: null;
  note: string;
  agent_comments: null;
  status: string;
  lead_id: number;
  agent_id: number;
  teacher_id: number;
  scheduled_by: number;
  created_at: Date;
  updated_at: Date;
  priority: string;
  deleted_at: null;
  package_id: number;
  slot_id: number;
  time_zone: string;
  gmt: string;
  for: string;
  student_name: null;
  student_age: null;
  grade: null;
  register_at: null;
  student_transfer_request_id: null;
  parent_id: number;
  attendee_meeting_link: string;
  teacher: DemoTeacher;
  lead: Lead;
  students: any[];
};

export type Lead = {
  id: number;
  name: string;
  phone: string;
  email: string;
  area: string;
  city: string;
  country: string;
  grade: string;
  lead_type: string;
  comments: string;
  advert: string;
  status: string;
  lead_note: string;
  blocked_comments: null;
  email_sent: number;
  for_markteting: number;
  sms_sent: number;
  agent_id: number;
  deal_id: null;
  blocked_by: null;
  created_by: number;
  created_at: Date;
  updated_at: Date;
  priority: string;
  metadata: null;
  source: null;
  subjects: any[];
};

export type DemoTeacher = {
  id: number;
  name: string;
  email: string;
  picture: string;
  fcm_token: null;
  status: number;
  isBlocked: number;
  last_activity: Date;
  last_login: Date;
  last_login_admin: Date;
  login_count_admin: number;
  created_at: Date;
  updated_at: Date;
  user_type: string;
  is_test: number;
  area_manager: number;
  created_by: null;
  updated_by: null;
  designation: null;
  last_name: string;
  student_grades: null;
  login_type: string;
  uuid: null;
  house_floor: null;
  building: null;
  address: null;
  on_boarding: null;
  area: null;
  city: null;
  country: null;
  postal_code: null;
  stripe_id: null;
  card_brand: null;
  card_last_four: null;
  trial_ends_at: null;
  source: null;
  teacher: TeacherTeacher;
};

export type TeacherTeacher = {
  id: number;
  rating: null;
  area: string;
  city: string;
  country: string;
  bio: string;
  tagline: string;
  user_id: number;
  area_manager_id: number;
  subject_id: number;
  captain_id: number;
  referred_by: null;
  tier: string;
  higherGrades: number;
  isExpress: number;
  isOnline: number;
  isOffline: number;
  isSuper: number;
  assignDemos: number;
  internationalDemos: number;
  tpStatus: string;
  created_at: Date;
  updated_at: Date;
  recruitedDate: null;
  trainingCompletionDate: null;
  lastDate: Date;
  leavingReason: string;
  dob: Date;
  demo_video: string;
  long_term_plans: null;
  computer_litearcy: number;
  communication_skills: number;
  years_of_experience: number;
  latest_degree: string;
  assigned_per: number;
  scheduled_per: number;
  registered_per: number;
  avg_per: number;
  retention_basic_score: number;
  retention_score: number;
  retention_status: string;
  conversion: string;
  isDemoSettingsSet: number;
  isApptScheduleSet: number;
  isNewTP: number;
  active_student_count: number;
  international_student_count: number;
  qualification_level_id: number;
  qualification_id: number;
  social_skills: number;
  confidence_skills: number;
  creative_skills: number;
  emotional_skills: number;
  avg_month_conversion: number;
  subjects: string;
  is_graduated: number;
  new_share_percent: number;
};

export type Grade = {
  id: number;
  title: string;
  created_at: Date;
  updated_at: null;
  sort_order: number;
  age_range: string;
  level: string;
  pivot: Pivot;
};

export type Pivot = {
  package_id: number;
  grade_id: number;
};

export type Links = {
  self: string;
};

export type Program = {
  id: number;
  name: string;
  status: number;
};

export type PackageTeacher = {
  id: number;
  name: string;
  email: string;
  phone: string;
  picture: string;
  address: string;
  city: string;
  country: string;
  area: string;
  dob: Date;
  area_manager: Agent;
  tier: string;
  super_tutor: number;
  teacher_status: string;
  recruited_date: null;
  training_completion_date: null;
  bio: string;
  tagline: string;
  demo_video: string;
  latest_degree: string;
  avg_per: number;
  subjects: string;
  ratings: string;
  qualification: Qualification;
  qualification_level: Qualification;
  is_new: number;
  joining_date: null;
  assignDemos: number;
  links: Links;
};

export type Slot = {
  id: number;
  teacher_package_id?: number;
  time_slot: string;
  start_time: string;
  end_time: string;
  hours_per_week: number;
  days: string;
  demo_status: number;
  seats: number;
  zoom_link: string;
  status?: number;
  created_at: Date;
  updated_at: Date;
  time_zone: string;
  deleted_at?: null;
  enrollCount?: number;
};

export type Children = {
  id: number;
  old_id: number;
  name: string;
  dob: string;
  school: string;
  board: string;
  level: null;
  gender: string;
  mobile: string;
  landline: null;
  city: string;
  country: string;
  source_of_registration: string;
  emergency_contact_name: string;
  emergency_contact_number: string;
  address: string;
  parent_id: number;
  is_test: number;
  image: string;
  status: string;
  payment_mode: string;
  invoice_date: string;
  created_by: number;
  updated_by: number;
  created_at: string;
  updated_at: string;
  avatar: string;
};

export interface Packages {
  id: number;
  title: string;
  description: string;
  learning_outcome: string;
  about_the_course: null;
  amount: number;
  int_amount: number;
  program: Program;
  teacher: Teacher;
  type: string;
  package_mode: string;
  enrollment_mode: string;
  status: number;
  min_age: number;
  max_age: number;
  course: null;
  subjects: any[];
  time_slot: TimeSlot[];
  is_booked: number;
  grades: Grade[];
  demos_count: number;
  demo: null;
  image: string;
  is_new: number;
  access_mode: string;
  links: Links;
}

export interface Teacher {
  id: number;
  name: string;
  email: string;
  phone: string;
  picture: string;
  address: string;
  city: string;
  country: string;
  area: string;
  dob: string;
  area_manager: AreaManager;
  tier: string;
  super_tutor: number;
  teacher_status: string;
  recruited_date: null;
  training_completion_date: null;
  bio: string;
  tagline: string;
  demo_video: string;
  latest_degree: string;
  avg_per: number;
  subjects: string[];
  ratings: string;
  qualification: Qualification;
  qualification_level: Qualification;
  is_new: number;
  joining_date: null;
  assignDemos: number;
  links: Links;
}

export interface AreaManager {
  id: number;
  name: string;
  email: string;
  picture: string;
  address: null;
  house_floor: null;
  latest_degree: string;
  city: null;
  area: null;
  phone: string;
  postal_code: null;
  created_at: string;
}

export interface Qualification {
  id: number;
  name: string;
  status: number;
  deleted_at: null;
  created_at: null;
  updated_at: null;
}

export interface TimeSlot {
  id: number;
  teacher_package_id: number;
  time_slot: string;
  start_time: string;
  end_time: string;
  hours_per_week: number;
  days: string;
  demo_status: number;
  seats: number;
  zoom_link: string;
  status: number;
  created_at: string;
  updated_at: string;
  time_zone: string;
  deleted_at: null;
  enrollCount: number;
}
