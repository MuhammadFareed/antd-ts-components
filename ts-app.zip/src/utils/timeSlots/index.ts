/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import moment from "moment-timezone";
let finalArr: unknown[] = [];

const getNextDay = function (dayName: string, skip = 0) {
  const date = new Date();
  const now = date.getDay();
  const days = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const day = days.indexOf(dayName.toLowerCase());

  let diff = day - now;
  diff = diff < 1 ? 7 + diff : diff;

  diff = diff + skip;
  const nextDayTimestamp = date.getTime() + 1000 * 60 * 60 * 24 * diff;

  return new Date(nextDayTimestamp);
};
const generateSlots = (filter: object[]) => {
  const timeSlotArr = [];

  timeSlotArr.push(
    ...[
      ...filter.map((a: object) => {
        return { ...a, sortIndex: 0 };
      }),
      ...filter.map((a: object) => {
        return { ...a, sortIndex: 1 };
      }),
    ],
  );

  finalArr = timeSlotArr.map((slots: any) => {
    return {
      ...slots,
      date: getNextDay(slots.days, 7 * slots.sortIndex),
    };
  });
};

const getTimeSlots = (slotsArr: unknown[]) => {
  const getToday: string = moment().format("ddd");
  const filter = slotsArr.map((slots: any) => {
    return slots.days.split(",").map((day: any) => {
      return {
        ...slots,
        days: day,
        start_time: slots.start_time,
        end_time: slots.end_time,
      };
    });
  });

  const merged = [].concat.apply([], [...filter]);

  merged.sort((a: { days: string }, b: { days: string }) => {
    const day1 = a.days.toLowerCase();
    const day2 = b.days.toLowerCase();

    return sorter()[day1] - sorter()[day2];
  });

  let match = 0;
  merged.map((item: { days: string }, index: number) => {
    if (item.days === getToday.toLowerCase() && match === 0) {
      match = 1;
      generateSlots(merged);
    }

    if (index === merged.length - 1 && !match) {
      let id = 0;
      merged.map((item: { days: string }) => {
        const dd = getDiff(item.days);

        if (dd > 0 && id === 0) {
          id++;
          generateSlots(merged);
        }
      });
    }
  });
  return finalArr;
};

const getDiff = (dayName: string) => {
  const date = new Date();
  const now = date.getDay();
  const days = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const day = days.indexOf(dayName.toLowerCase());

  const diff = day - now;
  return diff < 1 ? 7 + diff : diff;
};

const sorter = () => {
  const day_of_week = new Date().getDay();
  const list = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const sorted_list = list.slice(day_of_week + 1).concat(list.slice(0, day_of_week + 1));
  const obj: any = {};

  sorted_list.map((item, index) => {
    obj[item] = index + 1;
  });

  return obj;
};

const timeSlotsArr = (time_slot: unknown[]) => {
  const timeSlots = getTimeSlots(time_slot);
  const sortedData = timeSlots.sort((a: any, b: any) => moment(a.date).diff(moment(b.date)));

  // Group the data by date and days
  const groupedData: any = {};
  sortedData.forEach((item: any) => {
    const date = moment(item.date).format("YYYY-MM-DD");
    if (!groupedData[date]) {
      groupedData[date] = { id: Object.keys(groupedData).length, date, days: item.days, timings: [] };
    }
    groupedData[date].timings.push({
      slot_id: item.id,
      start: item.start_time,
      end: item.end_time,
    });
  });

  // Convert groupedData object to an array
  return Object.values(groupedData);
};

export default timeSlotsArr;
