/* eslint-disable indent */
import { EnrollPackage, Grade, Package, PackageTimeSlot } from "@type/index";
import { message } from "antd";
import moment from "moment-timezone";
import { MEDIA_BASE_URL } from "src/config/api-constants";
import { avatarList, dateFormat } from "src/constant";
import { store } from "src/store/index";
import noImage from "src/assets/images/anonymous.jpeg";
import { IInvoice } from "@type/payments";
import { INotificationData } from "src/types/notification";

export const openLinkInNewTab = (urlToOpen: string, newTab = true) => {
  if (urlToOpen) {
    window.open(urlToOpen, newTab ? "_blank" : "_self", "noreferrer");
  } else {
    message.error("Link not found!");
  }
};

export const getSixDigitRandomId = () => {
  return String(Math.floor(100000 + Math.random() * 900000));
};

export const getRandomString = (): string => {
  return Math.random().toString(36).slice(2);
};

export const capitilizeFirstLetter = (text?: string) => {
  if (text && typeof text === "string") {
    return text?.charAt(0)?.toUpperCase() + text?.slice(1)?.toLowerCase();
  }
};

export const capitilizeBreadcrumb = (text: string) => {
  if (text && typeof text === "string") {
    return text
      ?.split("-")
      .map(e => capitilizeFirstLetter(e))
      .join(" ");
  }
};

export const getPenaltyAmount = (detail: IInvoice) => {
  const currency = detail.currency;

  if (detail && detail.penalty) {
    const penaltyAmount = Number(detail.penalty) + Number(detail.amount);
    return `${currency} ${penaltyAmount}`;
  } else {
    if (detail && detail.amount) {
      if (currency === "PKR") {
        return `${currency} ${detail.amount + 500}`;
      } else {
        return `${currency} ${detail.amount + 4}`;
      }
    }
  }

  return `${currency} 0`;
};

export const axiosErrorHandler = (error: any) => {
  if (error && error?.response && error?.response?.data) {
    const errorMessages = error?.response?.data?.errors
      ? error?.response?.data?.errors
      : error?.response?.data?.message
      ? error?.response?.data?.message
      : {};
    const objectKeys = Object.keys(errorMessages);
    if (objectKeys?.length > 0) {
      if (error?.response?.data?.errors) {
        return message.error(error?.response?.data?.errors[objectKeys[0]][0]);
      } else if (error?.response?.data?.message) {
        if (typeof error?.response?.data?.message === "string") {
          return message.error(error?.response?.data?.message);
        } else {
          return message.error(error?.response?.data?.message[objectKeys[0]][0]);
        }
      }
    }
  }
  message.error(error?.message);
};

export const checkIsAuth = () => {
  return store?.getState()?.auth?.isAuth;
};

export const checkIsLocalUser = () => {
  const country = store?.getState()?.profile?.userProfile?.teacher?.country;
  return country && country === "Pakistan" ? true : false;
};

export function getCurrentWeekOfMonth(): number {
  const currentDate = moment();
  const timeZone = moment.tz.guess();
  const firstDayOfMonth = currentDate.clone().startOf("month").tz(timeZone);
  const dayOfWeekFirstDayOfMonth = firstDayOfMonth.day();
  const dayOfMonth = currentDate.date();
  let weekOfMonth = Math.ceil((dayOfMonth + (dayOfWeekFirstDayOfMonth >= 6 ? 0 : dayOfWeekFirstDayOfMonth)) / 7);
  if (weekOfMonth === 5 && dayOfMonth <= 28) {
    weekOfMonth = 4;
  }
  return weekOfMonth;
}

export const convertObjToQueryString = (obj: Record<string, any>): string => {
  return Object.entries(obj)
    .map(([key, value]) => {
      if (Array.isArray(value)) {
        return value.map(item => `${encodeURIComponent(key)}[]=${encodeURIComponent(item.toString())}`).join("&");
      }
      return `${encodeURIComponent(key)}=${encodeURIComponent(value.toString())}`;
    })
    .join("&");
};

const getAmountFromCurrency = (currency: "PKR" | "USD", amount: number, intAmount: number) => {
  if (currency === "PKR") {
    return `${currency} ${amount?.toLocaleString()}`;
  } else {
    return `${currency} ${intAmount?.toLocaleString()}`;
  }
};

export const getPackageAmount = (item: Package | EnrollPackage, currency: "PKR" | "USD") => {
  if (item?.program.name === "Short Course") {
    if (item?.type === "course" && item?.course && item?.course.pricing_type === "fixed") {
      return `${currency} ${currency === "PKR" ? item?.course.base_fee : item?.course.international_fee} / month`;
    } else {
      return `${getAmountFromCurrency(currency, item?.amount, item?.int_amount)} / month`;
    }
  }
  //  else if (item?.program.name === "Premium") {
  //   const price = currency === "PKR" ? "PKR 5,000" : "USD 32";
  //   return `Starting from ${price} / month`;
  // }
  else {
    return `${getAmountFromCurrency(currency, item?.amount, item?.int_amount)} / month`;
  }
};

const toRanges = (values: string[], separator = "\u2013") => {
  return values
    .reduce((acc: Array<string[]>, cur: any, idx: number, src: any) => {
      if (idx > 0 && cur - src[idx - 1] === 1) acc[acc.length - 1][1] = cur;
      else acc.push([cur]);
      return acc;
    }, [])
    .map(range => range.join(separator));
};

export const getGrades = (item: Package | EnrollPackage) => {
  if (item?.grades) {
    const sortedGrades = item?.grades?.map((grade: Grade) => {
      if (grade.title.indexOf("Grade ") === -1) {
        return grade.title;
      } else {
        return grade.title.slice(grade.title.indexOf("Grade ") + 6);
      }
    });
    return toRanges(sortedGrades).join(", ");
  }
};

export const getConvertedTime = (timeSlot: PackageTimeSlot, isForFreeClass?: boolean) => {
  if (timeSlot) {
    const inputTz = timeSlot.time_zone || "Asia/karachi";
    const originTimeStart = isForFreeClass ? timeSlot?.start_time : `2022-10-01 ${timeSlot?.start_time}`;
    const originTimeEnd = isForFreeClass ? timeSlot?.end_time : `2022-10-01 ${timeSlot?.end_time}`;
    const timeStart = moment.tz(originTimeStart, inputTz);
    const timeEnd = moment.tz(originTimeEnd, inputTz);
    const localtz = moment.tz.guess();
    const start = timeStart.clone().tz(localtz).format("hh:mm A");
    const end = timeEnd.clone().tz(localtz).format("hh:mm A");
    return `${start} - ${end} (${localtz})`;
  }
  return "";
};

export const getFormData = (data: Record<string, any>) => {
  const formData = new FormData();
  Object.keys(data).forEach((key: string) => {
    const element = data[key];
    if (element) {
      if (Array.isArray(element)) {
        for (let i = 0; i < element?.length; i++) {
          formData.append(`${key}[${i}]`, element[i]);
        }
      } else {
        formData.append(key, element);
      }
    }
  });
  return formData;
};

export const getStudentImage = (avatar: any, image: any): any => {
  if (avatar) {
    return avatarList[avatar]?.image;
  } else if (image) {
    return `${MEDIA_BASE_URL}${image}`;
  } else {
    return noImage;
  }
};

export const getStudentCount = (time_slots: PackageTimeSlot[]) => {
  if (time_slots && time_slots.length) {
    return time_slots.reduce((acc: number, cur: PackageTimeSlot) => acc + cur.enrollCount, 0);
  } else {
    return 0;
  }
};

export const hasHtmlTags = (str: string): boolean => {
  const htmlTagsRegex = /<[^>]+>/g;
  return htmlTagsRegex.test(str);
};

export const isProgressReportSubmited = (str: string): boolean => {
  if (str) {
    const currentDate = moment()?.date();
    const submittedMonth = +str?.split("-")[1];
    const currentMonth = moment()?.month() + 1;
    const prevMonth = moment()?.subtract(1, "months")?.month() + 1;
    if ((currentDate >= 20 && submittedMonth === currentMonth) || (currentDate < 20 && submittedMonth === prevMonth)) {
      return true;
    }
  }
  return false;
};

export const wordCount = (str: string): number => {
  return str?.split(" ")?.length;
};

const categories = [
  {
    id: 1,
    title: "Presentation",
    wordCount: 100,
  },
  {
    id: 2,
    title: "TP Demeanor (Attitude, behaviour and tone)",
    wordCount: 100,
  },
  {
    id: 3,
    title: "Effectiveness of Lesson Delivery",
    wordCount: 100,
  },
  {
    id: 9,
    title: "Student Engagement",
    wordCount: 100,
  },
  {
    id: 10,
    title: "Assessment",
    wordCount: 100,
  },
  {
    id: 11,
    title: "Parent Engagement (TP shares Monthly Progress Report of all active students)",
    wordCount: 100,
  },
  {
    id: 12,
    title: "Proactiveness and Responsiveness",
    wordCount: 100,
  },
  {
    id: 4,
    title: "Pick 2 indicators from Class Management Category for positive feedback",
    wordCount: 250,
  },
  {
    id: 5,
    title: "Pick 2 indicators from Class Management Category as her Areas of improvement",
    wordCount: 250,
  },
  {
    id: 6,
    title: "TP’s goal(s) for the next month",
    wordCount: 100,
  },
  {
    id: 7,
    title: "As her Manager, how will you help her achieve her monthly goal?",
    wordCount: 250,
  },
  {
    id: 8,
    title: "Is the TP ready to graduate?",
    wordCount: 100,
  },
  {
    id: 14,
    title: "Is the TP unresponsive?",
    wordCount: 200,
  },
  {
    id: 15,
    title: "Has the TP resigned or want to resign?",
    wordCount: 100,
  },
];

export const getCommentCount = (id: number) => {
  return categories.find(i => i.id === id)?.wordCount || 100;
};

export const getLimit = (id: number) => {
  switch (id) {
    case 4:
      return 2;

    case 5:
      return 2;

    case 8:
      return 1;

    case 11:
      return 1;

    case 14:
      return 1;

    case 15:
      return 1;

    default:
      return 0;
  }
};

export const convertToLocalDate = (utcTimestamp?: Date): string => {
  if (utcTimestamp) {
    return moment?.utc(utcTimestamp)?.local()?.format(dateFormat);
  }
  return "";
};

export function capitalizeDays(days: string) {
  return days
    .split(",")
    .map(function (day: string) {
      return day.trim().charAt(0).toUpperCase() + day.trim().slice(1);
    })
    .join(", ");
}

const getContent = () => "";

export const getNotificationData = ({
  title,
  image,
  cancelText,
  disableCancel,
  successText,
  type,
  content,
  handleSuccess,
  handleCancel,
  disableClose,
}: INotificationData) => {
  const obj = {
    cancelText: "Cancel",
    disableCancel: !!disableCancel,
    type: type ? type : "info",
    content: content || getContent,
    handleSuccess: () => {},
    handleCancel: () => {},
    disableClose: false,
  } as INotificationData;

  if (title) {
    obj.title = title;
  }

  if (image) {
    obj.image = image;
  }

  if (cancelText) {
    obj.cancelText = cancelText;
  }

  if (successText) {
    obj.successText = successText;
  }

  if (typeof handleSuccess === "function") {
    obj.handleSuccess = handleSuccess;
  }

  if (typeof handleCancel === "function") {
    obj.handleCancel = handleCancel;
  }

  if (disableClose) {
    obj.disableClose = true;
  }

  return obj;
};
