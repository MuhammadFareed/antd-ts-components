import React from "react";
import { getNotificationData } from "src/utils";
import badge from "src/assets/notificationSvgs/badge.svg";
import calendar from "src/assets/notificationSvgs/calendar.svg";
import review from "src/assets/notificationSvgs/review.svg";
import bellColor from "src/assets/notificationSvgs/bellColor.svg";
import coin from "src/assets/notificationSvgs/coin.svg";
import bell from "src/assets/notificationSvgs/bell.svg";
import success from "src/assets/notificationSvgs/success.svg";
import doc from "src/assets/notificationSvgs/doc.svg";
import alert from "src/assets/notificationSvgs/alert.svg";
import blast from "src/assets/notificationSvgs/blast.svg";
import { Notifications } from "@type/notification";
import { NOTIFICATION_DATA } from "src/store/action-types/notification";

export const renderContent = (text?: string) => <div className="mt-20">{text}</div>;

export const badgeUpdate = (url: string) =>
  getNotificationData({
    content: () => renderContent("You've received a new badge for your outstanding work."),
    disableCancel: true,
    image: badge,
    title: "Teacher spotlight!",
    successText: "View",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const scheduledDemo = (url: string) =>
  getNotificationData({
    content: () => renderContent("A new demo is scheduled for you."),
    disableCancel: true,
    image: calendar,
    title: "Mark your calendar.",
    successText: "View",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const reviewAlert = (url: string) =>
  getNotificationData({
    content: () => renderContent("A parent has shared their feedback about your teaching."),
    disableCancel: true,
    image: review,
    title: "New review alert!",
    successText: "View",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const invoiceIssue = getNotificationData({
  content: () =>
    renderContent("Invoices have been issued for your students. Please review and notify parents/guardians."),
  disableCancel: true,
  image: bellColor,
  title: "Important Notification",
  successText: "Okay",
});

export const commissionTransfer = (url: string) =>
  getNotificationData({
    content: () => renderContent("Commission Transfer Alert: Commission has been transferred to you."),
    disableCancel: true,
    image: coin,
    title: "Congratulations!",
    successText: "View Payment Info",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const commentUpdate = (url: string) =>
  getNotificationData({
    content: () => renderContent("The Package Approval Team has provided feedback. Please review."),
    disableCancel: true,
    image: bell,
    title: "Packages Comment Update",
    successText: "View More",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const paymentReceived = (text: string, url: string) =>
  getNotificationData({
    content: () => renderContent(text),
    disableCancel: true,
    image: success,
    title: "Payment Received!",
    successText: "View Details",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const baselineUpdate = (text: string, url: string) =>
  getNotificationData({
    content: () => renderContent(text),
    image: doc,
    title: "Update Baseline Forms",
    cancelText: "Not now",
    successText: "Update",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const demoUnAttended = (text: string, url: string) =>
  getNotificationData({
    content: () => renderContent(text),
    disableCancel: true,
    image: alert,
    title: "Demo Still Unattended",
    successText: "View Demos",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const newModule = (url: string) =>
  getNotificationData({
    content: () => renderContent("Get ready to enhance your skills with our latest training module."),
    disableCancel: true,
    image: blast,
    title: "New Module Available",
    successText: "View New Module",
    handleSuccess: () => {
      window.location.href = url;
    },
  });

export const showNotification = (notificationType: Notifications, text: string, url: string) => {
  switch (notificationType) {
    case "new_demo":
      return { type: NOTIFICATION_DATA, payload: scheduledDemo(url) };

    case "baseline_update":
      return { type: NOTIFICATION_DATA, payload: baselineUpdate(text, url) };

    case "comission_tranferred":
      return { type: NOTIFICATION_DATA, payload: commissionTransfer(url) };

    case "demo_unattended":
      return { type: NOTIFICATION_DATA, payload: demoUnAttended(text, url) };

    case "invoice_issued":
      return { type: NOTIFICATION_DATA, payload: invoiceIssue };

    case "new_badge":
      return { type: NOTIFICATION_DATA, payload: badgeUpdate(url) };

    case "new_review":
      return { type: NOTIFICATION_DATA, payload: reviewAlert(url) };

    case "package_comment":
      return { type: NOTIFICATION_DATA, payload: commentUpdate(url) };

    case "payment_received":
      return { type: NOTIFICATION_DATA, payload: paymentReceived(text, url) };

    case "training_module":
      return { type: NOTIFICATION_DATA, payload: newModule(url) };

    default:
      return { type: NOTIFICATION_DATA, payload: null };
  }
};
