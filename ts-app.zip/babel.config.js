module.exports = {
  presets: [
    "module:metro-react-native-babel-preset",
    ["@babel/preset-env", { targets: { node: "current" } }],
    "@babel/preset-typescript",
  ],
  plugins: [
    [
      require.resolve("babel-plugin-module-resolver"),
      {
        cwd: "babelrc",
        extensions: [".ts", ".tsx", ".js"],
        alias: {
          "@pages": "./src/pages",
          "@components": "./src/components",
          "@global": "./src/global",
          "@store": "./src/store",
        },
      },
    ],
    "jest-hoist",
  ],
};
