/* eslint-disable no-undef */
importScripts("https://www.gstatic.com/firebasejs/10.3.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.3.1/firebase-messaging-compat.js");

// Initialize the Firebase app in the service worker by passing the generated config
var firebaseConfig = {
  apiKey: "AIzaSyAqhVveKgOisDipvFM3NOLT2xUi9Kj_1cE",
  authDomain: "teacher-app-dotnline.firebaseapp.com",
  projectId: "teacher-app-dotnline",
  storageBucket: "teacher-app-dotnline.appspot.com",
  messagingSenderId: "825405393324",
  appId: "1:825405393324:web:7f95bb67efe72adc61d209",
  measurementId: "G-1D38K4B4PL",
};

firebase.initializeApp(firebaseConfig);

// Retrieve firebase messaging
let messaging = null;
if (firebase.messaging.isSupported()) {
  messaging = firebase.messaging();
}

if (messaging) {
  messaging.onBackgroundMessage(function (payload) {
    console.log("Received background message ", payload);

    const notificationTitle = payload.notification.title;
    const notificationOptions = {
      body: payload.notification.body,
      ...payload.notification.data,
    };

    self.registration.showNotification(notificationTitle, notificationOptions);
  });
}
